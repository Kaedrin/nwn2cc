Crafted Ammo and Enchanted Bows v1.2

Version 1.2 requires MotB.

This allows for Arrows, Bolts, and Bullets, Throwing Axes, Shurikens, and Darts to be crafted out of various metal materials and for ranged weapons to be enchanted with Enhance, Damage Bonuses, and other enchants.

Ammo can now be crafted from these materials: Adamantine, Cold Iron, Darksteel, Iron (normal ammo), Mithral, and Alchemical Silver.  This allows ranged weapons to bypass the Damage Reduction that many creatures have.  Arrows and Bolts take 1 ingot, 1 wooden plank, and 1 ammo mold to create a stack of arrows or bolts.  Bullets take 1 ingot and 1 ammo mold to create a stack of bullets.

Thrown Weapons can now be crafted from these materials: Adamantine, Cold Iron, Darksteel, Iron (normal ammo), Mithral, and Alchemical Silver.  This allows thrown weapons to bypass the Damage Reduction that many creatures have.  It takes 1 ingot, 1 wooden plank, and 1 throwing mold to create a stack of throwing axes.  It takes 1 ingot and 1 throwing mold to create a stack of darts or shurikens.

Ranged Weapons can now be enchanted with the following properties (their recipes are the same as for melee weapons):  Damage Bonus (all flavors), Enhance Bonus (all flavors), Keen, Holy Avenger, and Visual Effect.  

Module developers and PW's can add these to their world by adding the molds and ammo/thrown blueprints to a merchant.

Crafting ammo takes the following Craft Weapon skill values:

Normal Arrows, Bolts, Bullets, Darts, Throwing Axes, Shurikens: 2
Cold Iron, Alchemical Silver: 7
Darksteel, Mithral: 12
Adamantine: 17

Darksteel adds 1 electrical damage.  Adamantine adds 2 magical damage.

****************************

Installation: Copy the contents of the zip to your "My Documents\Neverwinter Nights 2\Override" folder.

****************************

To craft using this version of the Fletching Pack:

Arrow: use Longbow mold, 1 ingot, 1 wooden plank
Bolt: Heavy Crossbow mold, 1 ingot, 1 wooden plank
Bullet: Shortbow mold, 1 ingot
Shuriken: Light Crossbow mold, 1 ingot
Dart: Spear mold, 1 ingot
Throwing Axe: Battle Axe mold, 1 ingot, 1 wooden plank

OR

You can use the console to add ammo:

1.  Bring up the debug mode by hitting ~
2.  Enter "DebugMode 1" without the quotes. 
3.  Enter "GiveItem n2_crft_mold_arrow 2" without the quotes.  
This will create a stack of 2 arrow molds.  You can use 1-10 for the number of molds or 1-99 for ammo.

Replace n2_crft_mold_arrow with these to create the other ammo molds:

n2_crft_mold_bolt
n2_crft_mold_bullet
n2_crft_mold_taxe
n2_crft_mold_shuriken
n2_crft_mold_dart

These are the tags for the new ammo and thrown weapons and can be created in the same manner

Arrows:
cmi_ammo_adamant_arrow
cmi_ammo_cldiron_arrow
cmi_ammo_drksteel_arrow
cmi_ammo_mithral_arrow
cmi_ammo_silver_arrow

Bolts:
cmi_ammo_adamant_bolt
cmi_ammo_cldiron_bolt
cmi_ammo_drksteel_bolt
cmi_ammo_mithral_bolt
cmi_ammo_silver_bolt

Bullets:
cmi_ammo_adamant_bullet
cmi_ammo_cldiron_bullet
cmi_ammo_drksteel_bullet
cmi_ammo_mithral_bullet
cmi_ammo_silver_bullet

Throwing Axe:
cmi_thrown_adamant_taxe
cmi_thrown_cldiron_taxe
cmi_thrown_drksteel_taxe
cmi_thrown_mithral_taxe
cmi_thrown_silver_taxe

Darts:
cmi_thrown_adamant_dart
cmi_thrown_cldiron_dart
cmi_thrown_drksteel_dart
cmi_thrown_mithral_dart
cmi_thrown_silver_dart

Shurikens:
cmi_thrown_adamant_shuriken
cmi_thrown_cldiron_shuriken
cmi_thrown_drksteel_shuriken
cmi_thrown_mithral_shuriken
cmi_thrown_silver_shuriken



