Neverwinter Nights 2 Talk Table File Editor

  NWN2TLKEdit Version 0.22
  
  by simiy


* This is a tool for modifying tlk file included in NWN2.
* TLK file is the 'Talk Table' file used by Bioware aurora game engine.
* NWN2 uses UTF-8 character set.
* If you want to edit TLK file of NWN1, execute NWN1TLKEdit.cmd.
* If you want to edit TLK file of Infinity Engine, execute TLK1TLKEdit.cmd.
* You can build source in Microsoft Visual Studio .NET 2003 (VC++ 7.1) environment.
* Using this tool and source code is free.

* This tool was written for Korean Translation of NWN2. (http://www.rpgclan.net)

* ATTENTION *
  NWN2 tlk have non-Unicode chars(ex, extend ascii char), therefore you avoid fully export and import.
  Some contents are not represented to ascii text, so you do use this tool or NWN2Toolset to edit that.
  
  ex) 'u' character of "faerun"

- Features.

 1. List and view full contents of tlk.
 2. Search by 'StrRef(Unique number for string)' or text.
 3. Modify tlk string.
 4. Save tlk file.
 5. Brief tlk information.
 6. Batch run with '*.txt' file for updating.
 7. Extract string contents to '*.txt' file.
 8. Redefine the rule for batch text file.
 9. Comparing tlk files.
 
- Limitation to run this tool.

 1. It is possible Windows 2000 or highter Windows O/S.
 2. Ruleset.ini file must be located in same directory.
    It's also possible to specify other ruleset file, like startup argument -c "Ruleset filename".

- Usage

 1. All tasks are performed by loading tlk file.
    Updating the file is applied by saving that file.

 2. Find a string item by StrRef (or StringRef), or text contents.

  String Ref definition> Valid StrRefs can have values of up to 0x00FFFFFF, or 16777215.
    Any higher values will have the upper 1 byte masked off and set to 0,
    so 0x01000001 (or 16777217), for example, will be treated as StrRef 1.
    Under certain conditions, the upper 1 byte of a StrRef may have special meaning.

 3. To modify a item, at first select the item and modify the text of bottom edit control.
    To modify sound resource, double click item, or right click item and use 'Edit SndRes' menu.

 4. For batch updating several items, execute 'Import menu command' with batch text file.
    This commands take a moment, and it's end displaying results briefly.

 5. The rules of batch text file is defined in 'RuleSet.ini' file.


- Format of batch text file

 1. It is written as '*.txt' (text file).

 2. It is classified comment and content. Contents are string list for updating tlk.

 3. Comments is not applied to tlk, this usage is only that it decribes this text file.

    All Lines that start with '#//', is interpreted comment.

 4. Update-item is constructed with StrRef and a String.

    The form is "StrRef + Delimiter + String".
    StrRef is reference unique number.
    Delimiter is formed "one more space or tab + := +  one space".
    String is string to update tlk.

    Example) 
    -----------------------------------
    10  := fighter
    51  := cleric
    128 := wizard
    Wizard is ...
    
    Otherwise, sorcerers does not need preparing step...
    129 := sorcerer
    -----------------------------------

    * If StrRef is duplicated, last item is used to update tlk.
    * Only items decribed in file update tlk file.

 5. For specifying explicitly end of one item, enter two characters ;#.

    Example)
    -----------------------------------
    10  := fighter;#
    51  := cleric;#
    128 := wizard
    Wizard is ...
    
    Otherwise, sorcerers does not need preparing step...;#
    129 := sorcerer;#
    -----------------------------------

6. Ignored lines that was not interpreted by upper rules.

7. Rules can be changed, for changing rule, do modify "RuleSet.ini" file.

___EOF___
