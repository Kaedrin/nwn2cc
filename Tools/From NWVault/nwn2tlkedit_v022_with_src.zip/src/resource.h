//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by NWN2TLKEdit.rc
//
#define IDCANCEL2                       3
#define IDC_BTN_SEL_FILE                3
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_NWN2TLKEDIT_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDD_SELECT_LANG                 131
#define IDD_BATCH_CHOICE                134
#define IDD_INIT_SIZE                   135
#define IDD_SND_PROPERTY                136
#define IDB_ONE                         137
#define IDB_FULL                        138
#define IDB_BITMAP2                     139
#define IDB_EMPTY                       139
#define IDC_LIST_VIEW                   1000
#define IDC_EDIT_STRING                 1002
#define IDC_EDIT_SEARCH                 1005
#define IDC_BTN_SEARCH                  1006
#define IDC_T_STATUS                    1007
#define IDC_EDIT_SEL_ITEM               1008
#define IDC_COMBO_LANG                  1009
#define IDC_BTN_FIND_SND                1009
#define IDC_ABOUT_TITLE                 1010
#define IDC_R_ALL                       1011
#define IDC_R_SELECTED                  1012
#define IDC_R_RANGE                     1013
#define IDC_R_SEL_N_RANGE               1014
#define IDC_R_LIST_FILE                 1015
#define IDC_EDIT_INIT_SIZE              1015
#define IDC_EDIT_START                  1016
#define IDC_EDIT_SNDRES                 1016
#define IDC_EDIT_END                    1017
#define IDC_EDIT_VOLUME                 1017
#define IDC_EDIT_LIST_FILE              1018
#define IDC_EDIT_PITCH                  1018
#define IDC_EDIT_LENGTH                 1019
#define ID_MNU_ABOUT                    32774
#define ID_Menu                         32776
#define ID_MNU_EXIT                     32778
#define ID_MNU_SAVE                     32779
#define ID_MNU_SAVE_AS                  32781
#define ID_MNU_OPEN                     32782
#define ID_MNU_VIEWTLKSUMMARY           32786
#define ID_MNU_IMPORTBATCHTEXT          32787
#define ID_MNU_EXPORTBATCHTEXT          32788
#define ID_MNU_SEL_LANG                 32790
#define ID_MNU_SHOWHISTORY              32801
#define ID_MNU_SHOWREADME               32802
#define ID_MNU_FIND                     32804
#define ID_MNU_COMPARETLKFILE           32807
#define ID_TOOL_EXPORTDIFFSTRINGS       32808
#define ID_Menu32813                    32813
#define ID_MNU_EXPORT_MBCS              32817
#define ID_MNU_EXTRACT_DIFF_ADDED       32818
#define ID_MNU_EXTRACT_DIFF_DELETED     32819
#define ID_MNU_EXTRACT_DIFF_UPDATED     32820
#define ID_MNU_FIND_TEXT                32824
#define ID_MNU_INITTLK                  32826
#define ID_MNU_EDITSNDRES               32828

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32829
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
