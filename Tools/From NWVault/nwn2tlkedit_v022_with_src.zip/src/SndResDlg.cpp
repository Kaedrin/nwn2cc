// SndResDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NWN2TLKEdit.h"
#include "SndResDlg.h"
#include ".\sndresdlg.h"


// SndResDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CSndResDlg, CDialog)
CSndResDlg::CSndResDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSndResDlg::IDD, pParent)
{
	m_bModified = false;
	m_nStrRef = -1;
	m_pTlkElement = NULL;
}

CSndResDlg::~CSndResDlg()
{
}

void CSndResDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CSndResDlg, CDialog)
END_MESSAGE_MAP()


// SndResDlg �޽��� ó�����Դϴ�.

BOOL CSndResDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.

	CString strTitle;
	strTitle.Format(L"Edit Sound Resource of # [%08u]", m_nStrRef);
	SetWindowText(strTitle);

	((CEdit *)GetDlgItem(IDC_EDIT_SNDRES))->SetLimitText(16);
	((CEdit *)GetDlgItem(IDC_EDIT_VOLUME))->SetLimitText(10);
	((CEdit *)GetDlgItem(IDC_EDIT_PITCH))->SetLimitText(10);
	//((CEdit *)GetDlgItem(IDC_EDIT_LENGTH))->SetLimitText(16);
	if( m_pTlkElement )
	{
		if( m_pTlkElement->getVersion() == TLK30::TLK_VER_10 )	// 2007-01-14
		{
			((CEdit *)GetDlgItem(IDC_EDIT_SNDRES))->SetLimitText(8);
			GetDlgItem(IDC_EDIT_LENGTH)->EnableWindow(FALSE);
		}

		if( m_pTlkElement->isSndPresent() )
		{
			if( m_pTlkElement->GetSoundResRef(strTitle) > 0 )
				SetDlgItemText(IDC_EDIT_SNDRES, strTitle);
			SetDlgItemInt(IDC_EDIT_VOLUME, m_pTlkElement->DataVolumeVariance(), FALSE);
			SetDlgItemInt(IDC_EDIT_PITCH, m_pTlkElement->DataPitchVariance(), FALSE);
			if( m_pTlkElement->isSndLengthPresent() )
			{
				strTitle.Format(L"%f", m_pTlkElement->DataSoundLength());
				SetDlgItemText(IDC_EDIT_LENGTH, strTitle);
			}
			else
				SetDlgItemText(IDC_EDIT_LENGTH, L"0.0");
		}
		else
		{
			SetDlgItemText(IDC_EDIT_VOLUME, L"0");
			SetDlgItemText(IDC_EDIT_PITCH, L"0");
			SetDlgItemText(IDC_EDIT_LENGTH, L"0.0");
		}
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CSndResDlg::OnOK()
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

	CString rLength;
	GetDlgItemText(IDC_EDIT_LENGTH, rLength);
	TCHAR *ch;
	double nSndLength = _tcstod(rLength, &ch);
	if( *ch )
	{
		AfxMessageBox(L"Invalid Sound Length value");
		GetDlgItem(IDC_EDIT_LENGTH)->SetFocus();
		return;
	}

	if( m_pTlkElement )
	{
		CString rStr;
		GetDlgItemText(IDC_EDIT_SNDRES, rStr);

		if( m_pTlkElement->isSndPresent() )
		{
			CString rOrg;
			m_pTlkElement->GetSoundResRef(rOrg);

			if( rStr.Compare(rOrg) != 0 )
			{
				m_bModified = true;
				m_pTlkElement->SetSoundResRef(rStr, rStr.GetLength());
			}

			UINT n = GetDlgItemInt(IDC_EDIT_VOLUME, NULL, FALSE);
			if( m_pTlkElement->DataVolumeVariance() != n )
			{
				m_bModified = true;
			}
			m_pTlkElement->DataVolumeVariance() = n;

			n = GetDlgItemInt(IDC_EDIT_PITCH, NULL, FALSE);
			if( m_pTlkElement->DataPitchVariance() != n )
			{
				m_bModified = true;
			}
			m_pTlkElement->DataPitchVariance() = n;

			if( nSndLength != m_pTlkElement->DataSoundLength() )
			{
				m_bModified = true;
			}
			m_pTlkElement->SetSoundLength((float)nSndLength);
		}
		else
		{
			if( rStr.GetLength() > 0 )
			{
				m_bModified = true;
				m_pTlkElement->SetSoundResRef(rStr, rStr.GetLength());
				m_pTlkElement->DataVolumeVariance() =  GetDlgItemInt(IDC_EDIT_VOLUME, NULL, FALSE);
				m_pTlkElement->DataPitchVariance() =  GetDlgItemInt(IDC_EDIT_PITCH, NULL, FALSE);
				m_pTlkElement->SetSoundLength((float)nSndLength);
			}
		}
	}
	CDialog::OnOK();
}
