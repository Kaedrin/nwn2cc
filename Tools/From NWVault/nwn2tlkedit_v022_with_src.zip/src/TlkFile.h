#pragma once

/*
 1.1. Conventions
	Number is Big Endian Format => unsigned int, unsigned short, float
	- WORD, DWORD, FLOAT

 2.1. Fetching a String by StringRef

 2.2. StringRef definition

 StringRef  = DWORD
 Invalid	= 4294967295, or 0xFFFFFFFF, -1		= ""
 Valid		<= 0x00FFFFFF, or 16777215
	upper 2 bytes masked off and set to 0,
	so 0x01000001, or 16777217, for example, will be treated as StrRef 1.

 2.3. Specifying a Gender

 dialog.tlk == dialogf.tlk, but dialogf.tlk is Female dialog

 2.4. Alternate Talk Tables

 bit 0x01000000 of a StrRef specifies whether the StrRef should be fetched from the normal dialog.tlk or from the alternate tlk file
 If the bit is 0, the StrRef is fetched as normal from dialog.tlk.
 If the bit is 1, then the StrRef is fetched from the alternative talk table.
   but, not found -> fetched as normal from dialog.tlk
 
 3 TLK File Format
*/

namespace TLK30 {

// global variable for String Character set
// : CP_ACP or CP_UTF8 (default CP_UTF8)
extern UINT TLK_CODE_PAGE;

extern int toUTF8(LPCWSTR lpszIn, int nInBuf, char **pBuf, UINT nCodePage);
extern int toMBCS(LPCWSTR lpszIn, int nInBuf, char *pBuf);
extern int toUTF32(LPCSTR lpszIn, int nInBuf, CString &strOut, UINT nCodePage);
extern int toUTF32(LPCSTR lpszIn, int nInBuf, wchar_t *szOut, UINT nCodePage);

extern int ExtractDirectory(LPCTSTR lpszFilePath, CString &strOut);
extern bool FileExists(LPCTSTR szFilePath);

extern void TrimCRLF(char *buf);
extern void TrimRight(char *buf);
extern void TrimCRLF(wchar_t *buf);


class CNumbers
{
	enum _RANGE_TYPE {
		ALL		= 0,
		RANGED	= 1,
		HASHED	= 2
	};

	WORD		m_nType;
	UINT		m_nStart;
	UINT		m_nEnd;
	CMap<UINT, UINT, char, char> m_mapHash;
public:
	CNumbers()
	{
		m_nType = ALL;
		m_mapHash.InitHashTable(1000, FALSE);
	}
	~CNumbers() {}

	bool IsAll() const { return (m_nType == ALL); }

	void SetRange(UINT nStart, UINT nEnd)
	{
		m_nType |= RANGED;
		m_nStart = nStart;
		m_nEnd = nEnd;
	}
	void SetSelRange(UINT nStart, UINT nEnd)
	{
		m_nType |= HASHED;
		for(UINT i=nStart; i <= nEnd; i++)
		{
			m_mapHash.SetAt(i, 1);
		}
	}

	void SetSelValue(UINT nValue)
	{
		m_nType |= HASHED;
		m_mapHash.SetAt(nValue, 1);
	}

	void SetListFile(LPCTSTR lpszListFileName);
	
	bool Exists(UINT nValue) const
	{
		if( ! m_nType ) return true;
		if( (m_nType & RANGED) && (nValue >= m_nStart) && (nValue <= m_nEnd) ) return true;
		char nExists = 0;
		if( (m_nType & HASHED) && m_mapHash.Lookup(nValue, nExists) ) return true;
		return false;
	}


	int GetCount() const
	{
		if( ! m_nType ) return -1;
		int nCount = 0;
		if( (m_nType & RANGED) )
		{
			nCount += m_nEnd - m_nStart + 1;
		}
		char nExists = 0;
		if( m_nType & HASHED)
		{
			nCount += (int) m_mapHash.GetCount();

		}
		return false;
	}
};

enum TLK_VERSION {
	TLK_VER_10			= 10,
	TLK_VER_30			= 30
};

enum TLK_LANGUAGE {
	English				= 0,
	French				= 1,
	German				= 2,
	Italian				= 3,
	Spanish				= 4,
	Polish				= 5,
	Korean				= 128,
	ChineseTraditional	= 129,
	ChineseSimplified	= 130,
	Japanese			= 131
};

/*
 ----------------------------------------------------------------------------------
 Value					Type	Description
 ----------------------------------------------------------------------------------
 FileType				4 char	"TLK "
 FileVersion			4 char	"V3.0"
 LanguageID				DWORD	Language ID. See Table 3.2.2
 StringCount			DWORD	Number of strings in file
 StringEntriesOffset	DWORD	Offset from start of file to the String Entry Table
 */
class CTlkHeader
{
public:
	enum {
		E_NOT_TLK,
		E_VERSION
	};

protected:
	int nLastError;
	char * FileType;
	char * FileVersion;

public:
	unsigned int  LanguageID;
	unsigned int  StringCount;
	unsigned int  StringEntriesOffset;

	CTlkHeader()
	{
		nLastError = 0;
		StringCount = 0;
		StringEntriesOffset = 0;

		FileType = "TLK ";
	}

	int GetLastError () { return nLastError; }

	virtual TLK_VERSION getVersion() = 0;
	/**
	 * load and validation,
	 */
	virtual bool LoadStream(/* in */ const char *buf) = 0;
	virtual void MakeStream(/* out */ char *buf) = 0;

	virtual int getHeaderSize() const = 0;
	virtual int getElementSize() const = 0;

	
	TLK_LANGUAGE getLanguageId()
	{
		return (TLK_LANGUAGE)LanguageID;
	}
	LPCTSTR getLanguageString()
	{
		return getLanguageString(LanguageID);
	}
	static LPCTSTR getLanguageString(int nID)
	{
		switch(nID)
		{
		case English: return L"English";
		case French: return L"French";
		case German: return L"German";
		case Italian: return L"Italian";
		case Spanish: return L"Spanish";
		case Polish: return L"Polish";
		case Korean: return L"Korean";
		case ChineseTraditional: return L"Chinese Traditional";
		case ChineseSimplified: return L"Chinese Simplified";
		case Japanese: return L"Japanese";
		default:
			return L"Unknown";
		}
	}
};

class CTlk10Header : public CTlkHeader
{
public:
	CTlk10Header() : CTlkHeader()
	{
		LanguageID = 0;
		FileVersion = "V1  ";
	}
	TLK_VERSION getVersion() { return TLK_VER_10; }
	bool LoadStream(/* in */ const char *buf)
	{
		if( memcmp(buf, FileType, 4) != 0 )
		{
			nLastError = E_NOT_TLK;
			return false;
		}
		if( memcmp(buf+4, FileVersion, 4) != 0 )
		{
			nLastError = E_VERSION;
			return false;
		}
		LanguageID = 0; memcpy(&LanguageID, buf+8, 2);	// If Big Endian, this ok..
		memcpy(&StringCount, buf+10, 4);
		memcpy(&StringEntriesOffset, buf+14, 4);
		return true;
	}
	void MakeStream(/* out */ char *buf)
	{
		memcpy(buf, FileType, 4);
		memcpy(buf+4, FileVersion, 4);
		memcpy(buf+8, &LanguageID, 2);
		memcpy(buf+10, &StringCount, 4);
		memcpy(buf+14, &StringEntriesOffset, 4);
	}
	int getHeaderSize() const { return 18; }
	int getElementSize() const { return 26; }
};

class CTlk30Header : public CTlkHeader
{
public:
	CTlk30Header() : CTlkHeader()
	{
		LanguageID = 0;
		FileVersion = "V3.0";
	}
	TLK_VERSION getVersion() { return TLK_VER_30; }
	bool LoadStream(/* in */ const char *buf)
	{
		if( memcmp(buf, FileType, 4) != 0 )
		{
			nLastError = E_NOT_TLK;
			return false;
		}
		if( memcmp(buf+4, FileVersion, 4) != 0 )
		{
			nLastError = E_VERSION;
			return false;
		}
		memcpy(&LanguageID, buf+8, 4);
		memcpy(&StringCount, buf+12, 4);
		memcpy(&StringEntriesOffset, buf+16, 4);
		return true;
	}
	void MakeStream(/* out */ char *buf)
	{
		memcpy(buf, FileType, 4);
		memcpy(buf+4, FileVersion, 4);
		memcpy(buf+8, &LanguageID, 4);
		memcpy(buf+12, &StringCount, 4);
		memcpy(buf+16, &StringEntriesOffset, 4);
	}
	int getHeaderSize() const { return 20; }
	int getElementSize() const { return 40; }
};

/*
 ----------------------------------------------------------------------------------
 Value			Type	Description
 ----------------------------------------------------------------------------------
 Flags			DWORD	Flags about this StrRef.
 SoundResRef	16 char	ResRef of the wave file associated with this string. Unused characters are nulls.
 VolumeVariance	DWORD	not used
 PitchVariance	DWORD	not used
 OffsetToString	DWORD	Offset from StringEntriesOffset to the beginning of the StrRef's text.
 StringSize		DWORD	Number of bytes in the string. Null terminating characters are not stored, so this size does not include a null terminator.
 SoundLength	FLOAT	Duration in seconds of the associated wave file
 */
class CTlkElement
{
public:
	enum STRING_FLAGS {
		TEXT_PRESENT		= 0x0001,	// If unset, StrRef has no text. Return an empty string.
		SND_PRESENT			= 0x0002,	// If unset, SoundResRef is an empty string.
		SNDLENGTH_PRESENT	= 0x0004	// If unset, SoundLength is 0.0 seconds.
	};

public:

#pragma pack(push, 1)
	union _DATA
	{
		struct _TLK30 {
			// 4+16+4+4+4+4+4 = 40	=> * 0x00FFFFFF
			DWORD	Flags;
			char	SoundResRef[16];
			DWORD	VolumeVariance;
			DWORD	PitchVariance;
			DWORD	OffsetToString;		//-- Post Processing
			DWORD	StringSize;
			FLOAT	SoundLength;
		} TLK30;
		struct _TLK10 {
			// 2+8+4+4+4+4 = 26	=> * 0x00FFFFFF
			WORD	Flags;
			char	SoundResRef[8];
			DWORD	VolumeVariance;
			DWORD	PitchVariance;
			DWORD	OffsetToString;		//-- Post Processing
			DWORD	StringSize;
		} TLK10;
	} DATA;
#pragma pack(pop)

private:
	// DWORD	StrRef;
	char *lpszString;
	// ---

	int nLastError;

public:
	CTlkElement()
	{
		lpszString = NULL;
	}
	~CTlkElement()
	{
		if(lpszString) delete lpszString;
	}

	unsigned short & DataFlags() { return *((unsigned short*)&DATA); }
	unsigned short & DataFlags() const { return *((unsigned short*)&DATA); }
	virtual char * DataSoundRef() = 0;
	virtual const char * DataSoundRef() const = 0;
	virtual DWORD &DataVolumeVariance() = 0;
	virtual const DWORD &DataVolumeVariance() const = 0;
	virtual DWORD &DataPitchVariance() = 0;
	virtual const DWORD &DataPitchVariance() const = 0;
	virtual DWORD &DataOffsetToString() = 0;
	virtual const DWORD &DataOffsetToString() const = 0;
	virtual DWORD &DataStringSize() = 0;
	virtual const DWORD &DataStringSize() const = 0;
	FLOAT &DataSoundLength() { return DATA.TLK30.SoundLength; }
	const FLOAT &DataSoundLength() const { return DATA.TLK30.SoundLength; }

	virtual TLK_VERSION getVersion() const = 0;
	virtual int getSoundRefLen() const = 0;

	// -- load and validation
	virtual bool LoadElement(const char *buf) = 0;

	// -- required Post processing (Offset)
	virtual void MakeStream(char *buf) = 0;

	int LoadStrData(const char *buf)
	{
		if( ! isTextPresent() )
			return -1;
		lpszString = (char *)calloc(1, DataStringSize());
		if( ! lpszString )
			return 0;
		memcpy(lpszString, buf, DataStringSize());
		return true;
	}

	// ---------------------------------
	// Post Processing Method
	// ---------------------------------
	/**
	 * update Offset from nOffset, and return next Offset
	 */
	void _FixOffset(/* inout */DWORD & nOffset)
	{
		if ( isTextPresent() )
		{
			DataOffsetToString() = nOffset;
			nOffset += DataStringSize();
		}
	}
	// _________________________________


	BOOL isTextPresent() const		{ return (DataFlags() & TEXT_PRESENT); }
	bool isValidText()	 const		{ return (DataFlags() & TEXT_PRESENT) && (DataStringSize() > 0); }
	BOOL isSndPresent()	 const		{ return (DataFlags() & SND_PRESENT); }
	BOOL isSndLengthPresent() const	{ return (DataFlags() & SNDLENGTH_PRESENT); }

	LPCSTR GetStrData() { return lpszString; }
	int GetText(CString &rStr)
	{
		return toUTF32(lpszString, DataStringSize(), rStr, TLK_CODE_PAGE);
	}

	bool SetString(LPCWSTR szText, int nLen)
	{
		if( nLen <= 0 )
		{
			DataFlags() &= ~TEXT_PRESENT;
			DataStringSize() = 0;
			if(lpszString) delete lpszString;
			lpszString = NULL;
		}
		else
		{
			int nLen2 = toUTF8(szText, nLen, &lpszString, TLK_CODE_PAGE);
			if( nLen2 > 0 )
			{
				DataStringSize() = nLen2;
				DataFlags() |= TEXT_PRESENT;
			}
			else
				return false;
		}
		return true;
	}
	bool SetString(LPCWSTR szText)
	{
		return SetString(szText, (int)wcslen(szText));
	}

	bool CompareSummary( const CTlkElement *element, CString &rResult );
	int GetSoundResRef(CString &rStr)
	{
		if( *DataSoundRef() == 0 )
			return 0;
		else
			return toUTF32(DataSoundRef(), 16, rStr, CP_ACP);
	}
	bool SetSoundResRef(LPCWSTR szText, int nLen)
	{
		if( nLen <= 0 )
		{
			DataFlags() &= ~SND_PRESENT;
			memset(DataSoundRef(), 0, getSoundRefLen());
		}
		else
		{
			if( nLen > getSoundRefLen() ) nLen = getSoundRefLen();
			int nLen2 = toMBCS(szText, nLen, DataSoundRef());
			if( nLen2 > 0 )
				DataFlags() |= SND_PRESENT;
			else
				return false;
		}
		return true;
	}
	bool SetSoundLength(float nLength)
	{
		if( nLength == 0 )
		{
			DataFlags() &= ~SNDLENGTH_PRESENT;
			DataSoundLength() = 0;
		}
		else
		{
			DataFlags() |= SNDLENGTH_PRESENT;
			DataSoundLength() = nLength;
		}
		return true;
	}
	
};

class CTlk10Element : public CTlkElement
{
public:
	CTlk10Element() : CTlkElement()
	{
		DATA.TLK10.Flags = 0;
		DATA.TLK10.StringSize = 0; DATA.TLK10.SoundResRef[0] = 0;	// 2007-01-12, dummy initial
	}
	TLK_VERSION getVersion() const { return TLK_VER_10; }
	int getSoundRefLen() const { return 8; }

	char * DataSoundRef() { return DATA.TLK10.SoundResRef; }
	DWORD &DataVolumeVariance() { return DATA.TLK10.VolumeVariance; }
	DWORD &DataPitchVariance() { return DATA.TLK10.PitchVariance; }
	DWORD &DataOffsetToString() { return DATA.TLK10.OffsetToString; }
	DWORD &DataStringSize() { return DATA.TLK10.StringSize; }
	const char * DataSoundRef() const { return DATA.TLK10.SoundResRef; }
	const DWORD &DataVolumeVariance() const { return DATA.TLK10.VolumeVariance; }
	const DWORD &DataPitchVariance() const { return DATA.TLK10.PitchVariance; }
	const DWORD &DataOffsetToString() const { return DATA.TLK10.OffsetToString; }
	const DWORD &DataStringSize() const { return DATA.TLK10.StringSize; }

	bool LoadElement(const char *buf)
	{
		memcpy(&DATA.TLK10, buf, sizeof(DATA.TLK10));
		return true;
	}
	void MakeStream(char *buf)
	{
		memcpy(buf, &DATA.TLK10, sizeof(DATA.TLK10));
	}
};

class CTlk30Element : public CTlkElement
{
public:
	CTlk30Element() : CTlkElement()
	{
		DATA.TLK30.Flags = 0;
		DATA.TLK30.StringSize = 0; DATA.TLK30.SoundResRef[0] = 0;	// 2007-01-12, dummy initial
	}
	TLK_VERSION getVersion() const { return TLK_VER_30; }
	int getSoundRefLen() const { return 16; }

	char * DataSoundRef() { return DATA.TLK30.SoundResRef; }
	DWORD &DataVolumeVariance() { return DATA.TLK30.VolumeVariance; }
	DWORD &DataPitchVariance() { return DATA.TLK30.PitchVariance; }
	DWORD &DataOffsetToString() { return DATA.TLK30.OffsetToString; }
	DWORD &DataStringSize() { return DATA.TLK30.StringSize; }
	const char * DataSoundRef() const { return DATA.TLK30.SoundResRef; }
	const DWORD &DataVolumeVariance() const { return DATA.TLK30.VolumeVariance; }
	const DWORD &DataPitchVariance() const { return DATA.TLK30.PitchVariance; }
	const DWORD &DataOffsetToString() const { return DATA.TLK30.OffsetToString; }
	const DWORD &DataStringSize() const { return DATA.TLK30.StringSize; }

	bool LoadElement(const char *buf)
	{
		memcpy(&DATA.TLK30, buf, sizeof(DATA.TLK30));
		return true;
	}
	void MakeStream(char *buf)
	{
		memcpy(buf, &DATA.TLK30, sizeof(DATA.TLK30));
	}
};


/* 
 Start of File			; �� Header
 ...
 StringDataOffset		; �� String Data Table
 ...
 StringEntriesOffset	; �� String Entry Table
 ...
 */
class CTlkFile
{

	CString m_strTlkFileName;
	CTlkHeader *m_pTlkHeader;

	DWORD nValidStringCount;
	DWORD nMaxString;
	//
	// variable size table (0 ~ m_pTlkHeader->StringCount)
	//
	// table of CTlkElement Pointer
	CTlkElement ** pDataTable;

public:
	bool m_bModified;

public:
	CTlkFile()
	{
		m_pTlkHeader = new CTlk30Header();
		pDataTable = NULL;
		m_bModified = false;
		nValidStringCount = 0;
		nMaxString = 0;
	}
	virtual ~CTlkFile(void);
	
	bool SetVersion(TLK_VERSION nTlkVersion)
	{
		if( (m_pTlkHeader->getVersion() == nTlkVersion)	// same version
			|| (pDataTable != NULL)	// used
			)
			return false;

		delete m_pTlkHeader;

		switch(nTlkVersion)
		{
		case TLK_VER_10:
			m_pTlkHeader = new CTlk10Header();
			break;
		default:
			m_pTlkHeader = new CTlk30Header();
			break;
		}
		return true;
	}

	const CString &getFileName() { return m_strTlkFileName; }

	bool InitFile(DWORD nInitSize);
	bool LoadFile(LPCTSTR lpszFileName);
	bool SaveAsFile(LPCTSTR lpszFileName);
	bool SaveFile()
	{
		return SaveAsFile(m_strTlkFileName);
	}

	CTlkHeader * GetTlkHeader() { return m_pTlkHeader; }

	DWORD RefToIndex(DWORD nStrRef)
	{
		return (nStrRef & 0x00FFFFFF);
	}

	DWORD GetElementCount() { return m_pTlkHeader->StringCount; }
	// return NULL is Invalid Ref or Not Found
	CTlkElement * GetElement(DWORD nIdx)
	{
		if( (pDataTable == NULL) || (nIdx >= m_pTlkHeader->StringCount) )
			return NULL;
		return pDataTable[nIdx];
	}

	DWORD GetValidStringCount() { return nValidStringCount; }
	DWORD GetMaxStringSize() { return nMaxString; }

	bool Modified(bool bModified = true)
	{
		bool b = m_bModified;
		m_bModified = Modified;
		return b;
	}
	bool isModified() { return m_bModified; }

	CString GetSummary();
	void GenerateSummary(CString &strFileName);

	int CompareTlkFile(LPCTSTR lpszTlkFileName, CString &rResult);

	// Collect Multi Bytes Character (Ko,Jap,Ch ...) StrRefs
	int CollectMultiBytesCharStrRef(CNumbers &Numbers);

	// Different StrRefs
	// Numbers1 new
	// Numbers2 updated
	// Numbers3 deleted
	int CollectDiffStrRef(LPCTSTR lpszTlkFileName, CNumbers *Numbers1, CNumbers *Numbers2, CUIntArray *Deleted);

};

}	// namespace TLK30
