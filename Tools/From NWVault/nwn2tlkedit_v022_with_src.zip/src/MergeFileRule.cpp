#include "StdAfx.h"
#include "MergeFileRule.h"

#include "RegExp.h"

namespace TLK30 {

static void ReplaceEscapeChar(CString &rString)
{
	bool bEscape = false;
	TCHAR buf[4096];
	int j=0;
	for(int i=0; i<rString.GetLength(); i++)
	{
		if( bEscape )
		{
			if( rString[i] == L'\\' )
			{
				buf[j++] = L'\\';
			}
			else if( rString[i] == L't' )
			{
				buf[j++] = L'\t';
			}
			else
			{
				buf[j++] = L'\\';
				buf[j++] = rString[i];
			}
			bEscape = false;
		}
		else if( rString[i] == L'\\' )
		{
			bEscape = true;
		}
		else
		{
			buf[j++] = rString[i];
		}
	}
	if( bEscape )
	{
		buf[j++] = L'\\';
	}
	buf[j] = 0;
	if( j != rString.GetLength() )
		rString = buf;
}

bool CMergeFileRule::LoadRule(LPCTSTR lpszFileName)
{
	// 1. File Open
	FILE *f = _tfopen(lpszFileName, L"rt");
	if( f == NULL )
		return false;
	fclose(f);

	m_bComment = 0;
	m_bString  = 0;
	m_bStringStart = 0;
	m_bStringEnd = 0;

	CRegExp reComment;
	CRegExp reString;
	CRegExp reStringStart;
	CRegExp reStringEnd;

	// 2. Load Element
	TCHAR buf[1024];

	DWORD nResult = GetPrivateProfileString(L"ImportRule", L"Comment", L"^#//.*$", buf, 1024, lpszFileName);
	if(nResult)
	{
		int pos = 0;	for(; buf[pos] && _istspace(buf[pos]); pos++);
		int len = 0;	for(; buf[pos+len]; len++);	for(; (len > 0) && _istspace(buf[len-1]); len--);

		COMMENT.SetString(buf+pos, len);
		m_bComment = true;;
	}

	nResult = GetPrivateProfileString(L"ImportRule", L"String Isolate", L"", buf, 1024, lpszFileName);
	if(nResult)
	{
		int pos = 0;	for(; buf[pos] && _istspace(buf[pos]); pos++);
		int len = 0;	for(; buf[pos+len] && !((buf[pos+len]==L'$')&&(buf[pos+len-1]!=L'\\')); len++);
		if(buf[pos+len]!=L'$')
			goto ERROR_LOAD;
		STRING[0].SetString(buf+pos, ++len);
		STRING[1] = L"\\";
		pos += len;	for(; buf[pos] && _istspace(buf[pos]); pos++);
		STRING[1] += buf[pos];
		STRING[2] = L"\\";
		pos ++;	for(; buf[pos] && _istspace(buf[pos]); pos++);
		STRING[2] += buf[pos];
		m_bString = true;	
	}

	nResult = GetPrivateProfileString(L"ImportRule", L"String Start", L"^(\\d+)\\s+:=\\s+(.*)$ 1 2", buf, 1024, lpszFileName);
	if(nResult)
	{
		int pos = 0;	for(; buf[pos] && _istspace(buf[pos]); pos++);
		int len = 0;	for(; buf[pos+len] && !((buf[pos+len]==L'$')&&(buf[pos+len-1]!=L'\\')); len++);
		if(buf[pos+len]!=L'$')
			goto ERROR_LOAD;
		STRING_START[0].SetString(buf+pos, ++len);
		STRING_START[1] = L"\\";
		pos += len;	for(; buf[pos] && _istspace(buf[pos]); pos++);
		STRING_START[1] += buf[pos];
		STRING_START[2] = L"\\";
		pos ++;	for(; buf[pos] && _istspace(buf[pos]); pos++);
		STRING_START[2] += buf[pos];
		m_bStringStart = true;	
	}

	nResult = GetPrivateProfileString(L"ImportRule", L"String End", L"", buf, 1024, lpszFileName);
	if(nResult)
	{
		int pos = 0;	for(; buf[pos] && _istspace(buf[pos]); pos++);
		int len = 0;	for(; buf[pos+len] && !((buf[pos+len]==L'$')&&(buf[pos+len-1]!=L'\\')); len++);
		if(buf[pos+len]!=L'$')
			goto ERROR_LOAD;
		STRING_END[0].SetString(buf+pos, ++len);
		STRING_END[1] = L"\\";
		pos += len;	for(; buf[pos] && _istspace(buf[pos]); pos++);
		STRING_END[1] += buf[pos];
		m_bStringEnd = true;	
	}
			
	if( ! m_bStringStart )
		return false;

	GetPrivateProfileString(L"ExportRule", L"Comment", L"#//$Comment", buf, 1024, lpszFileName);
	m_sExpComment = buf;
	GetPrivateProfileString(L"ExportRule", L"String", L"$StrRef := $String", buf, 1024, lpszFileName);
	m_sExpString = buf;

	reComment.SetCaseSensitive(true);
	reString.SetCaseSensitive(true);
	reStringStart.SetCaseSensitive(true);
	reStringEnd.SetCaseSensitive(true);

	ReplaceEscapeChar(COMMENT);
	ReplaceEscapeChar(STRING[0]);
	ReplaceEscapeChar(STRING_START[0]);
	ReplaceEscapeChar(STRING_END[0]);


	if( ( m_bComment ) && ! reComment.RegComp( COMMENT ) ) return false;
	if( (m_bString) )
	{
		if( ! reString.RegComp( STRING[0] ) )
			return false;
		if( (STRING[1][1] < L'1') || (STRING[1][1] > L'9') )
			return false;
		if( (STRING[2][1] < L'1') || (STRING[2][1] > L'9') )
			return false;
	}
	if( m_bStringStart )
	{
		if( ! reStringStart.RegComp( STRING_START[0] ) )
			return false;
		if( (STRING_START[1][1] < L'1') || (STRING_START[1][1] > L'9') )
			return false;
		if( (STRING_START[2][1] < L'1') || (STRING_START[2][1] > L'9') )
			return false;
	}
	if( m_bStringEnd )
	{
		if( ! reStringEnd.RegComp( STRING_END[0] ) )
			return false;
		if( (STRING_END[1][1] < L'1') || (STRING_END[1][1] > L'9') )
			return false;
	}



	m_sExpComment.Replace(L"%", L"%%");
	if( m_sExpComment.Replace(L"$Comment", L"%s") != 1 )
		return false;
	m_sExpComment += L"\n";

	m_bExpStrRefFirst = m_sExpString.Find(L"$StrRef") < m_sExpString.Find(L"$String");

	m_sExpString.Replace(L"%", L"%%");

	if( (m_sExpString.Replace(L"$StrRef", L"%u") != 1) || (m_sExpString.Replace(L"$String", L"%s") != 1) )
		return false;
	
	m_sExpString += L"\n";
	return true;

ERROR_LOAD:
	return false;
}

void CMergeFileRule::updateTlkFile(CTlkFile &tlkFile, DWORD nStrRef, LPCTSTR sString)
{
	CTlkElement * pTlkElement = tlkFile.GetElement( tlkFile.RefToIndex(nStrRef) );
	if( pTlkElement == NULL )
		fprintf(m_of, "E: Not Found StrRef.\n Line#%d: %s\n", m_nStringStartLine, m_sStringStartLine);
	else
	{
		if( pTlkElement->SetString(sString) )
		{
			m_nUpdated ++;
		}
		else
			fprintf(m_of, "E: Update Failed.\n Line#%d: %s\n", m_nStringStartLine, m_sStringStartLine);
	}
}

int CMergeFileRule::MergeTlkFile(CTlkFile &tlkFile, LPCTSTR lpszUpdateFile, const CNumbers &range)
{
	if( tlkFile.GetElementCount() == 0 )	// Not loaded TLK File
		return -1;

	if( ! m_bStringStart )	// Not loaded Rule
		return -1;

	// Rule is validated at Loading Time
	// here, only compile & not validate
	CRegExp reComment;
	CRegExp reString;
	CRegExp reStringStart;
	CRegExp reStringEnd;

	reComment.SetCaseSensitive(true);
	reString.SetCaseSensitive(true);
	reStringStart.SetCaseSensitive(true);
	reStringEnd.SetCaseSensitive(true);

	if( m_bComment )		reComment.RegComp( COMMENT );
	if( m_bString )			reString.RegComp( STRING[0] );
	if( m_bStringStart )	reStringStart.RegComp( STRING_START[0] );
	if( m_bStringEnd )		reStringEnd.RegComp( STRING_END[0] );

	FILE * _if = _tfopen(lpszUpdateFile, L"rt");
	if( _if == NULL )
		return -1;

	GetTempPath(512, m_lpszOutput);
	_tcscat(m_lpszOutput, L"_TLK_TMP.TXT");

	m_of = _tfopen( m_lpszOutput, L"wt" );
	if( m_of == NULL )
	{
		fclose(_if);
		return -1;
	}

	m_nUpdated = 0;
	m_nStringStartLine = -1;
	m_sStringStartLine.Empty();

	bool bStart = false;
	DWORD nStrRef = -1;
	CString sString;

	char buf2[8192];	// one line, 8192 ok
	wchar_t buf[8192];	// one line, 8192 ok
	TCHAR *pTmp = NULL;
	int nLine = 0;
	while( fgets(buf2, 8192, _if) )
	{
		++ nLine;
		TrimCRLF(buf2);
		if( *buf2 == 0 )*buf = 0;
		else			toUTF32(buf2, (int)strlen(buf2), buf, CP_ACP);
		if( bStart )
		{
			if( m_bComment && (reComment.RegFind(buf) >= 0) )
			{
				if( range.Exists(nStrRef) )
					updateTlkFile(tlkFile, nStrRef, sString);
				bStart = false;
			}
			else if( m_bString && (reString.RegFind(buf) >= 0) )
			{
				if( range.Exists(nStrRef) )
					updateTlkFile(tlkFile, nStrRef, sString);
				bStart = false;

				pTmp = reString.GetReplaceString(STRING[1]);
				if( pTmp == NULL )
				{
					fprintf(m_of, "E: String Isolate Pattern Error in Param 1.\n Line#%d: %s\n", nLine, buf2);
					continue;
				}
				nStrRef = _tcstoul(pTmp, NULL, 10);
				delete [] pTmp;
				pTmp = reString.GetReplaceString(STRING[2]);
				if( pTmp == NULL )
				{
					fprintf(m_of, "E: String Isolate Pattern Error in Param 2.\n Line#%d: %s\n", nLine, buf2);
					continue;
				}
				m_nStringStartLine = nLine;
				m_sStringStartLine = buf2;
				if( range.Exists(nStrRef) )
					updateTlkFile(tlkFile, nStrRef, pTmp);
				delete [] pTmp;
			}
			else if( m_bStringStart && (reStringStart.RegFind(buf) >= 0) )
			{
				if( range.Exists(nStrRef) )
					updateTlkFile(tlkFile, nStrRef, sString);
				bStart = false;

				pTmp = reStringStart.GetReplaceString(STRING_START[1]);
				if( pTmp == NULL )
				{
					fprintf(m_of, "E: String Start Pattern Error in Param 1.\n Line#%d: %s\n", nLine, buf2);
					continue;
				}
				nStrRef = _tcstoul(pTmp, NULL, 10);
				delete [] pTmp;
				pTmp = reStringStart.GetReplaceString(STRING_START[2]);
				if( pTmp == NULL )
				{
					fprintf(m_of, "E: String Start Pattern Error in Param 2.\n Line#%d: %s\n", nLine, buf2);
					continue;
				}
				sString = pTmp;
				delete [] pTmp;
				bStart = true;
				m_nStringStartLine = nLine;
				m_sStringStartLine = buf2;
			}
			else if( m_bStringEnd && (reStringEnd.RegFind(buf) >= 0) )
			{
				pTmp = reStringEnd.GetReplaceString(STRING_END[1]);
				if( pTmp == NULL )
				{
					fprintf(m_of, "E: String End Pattern Error in Param 1.\n Line#%d: %s\n", nLine, buf2);
					continue;
				}
				sString += L'\n';
				sString += pTmp;
				delete [] pTmp;

				if( range.Exists(nStrRef) )
					updateTlkFile(tlkFile, nStrRef, sString);
				bStart = false;
			}
			else
			{
				sString += L'\n';
				sString += buf;
			}
		}
		else	// if bStart
		{
			if( m_bComment && (reComment.RegFind(buf) >= 0) )
			{
				continue;
			}
			else if( m_bString && (reString.RegFind(buf) >= 0) )
			{
				pTmp = reString.GetReplaceString(STRING[1]);
				if( pTmp == NULL )
				{
					fprintf(m_of, "E: String Isolate Pattern Error in Param 1.\n Line#%d: %s\n", nLine, buf2);
					continue;
				}
				nStrRef = _tcstoul(pTmp, NULL, 10);
				delete [] pTmp;
				pTmp = reString.GetReplaceString(STRING[2]);
				if( pTmp == NULL )
				{
					fprintf(m_of, "E: String Isolate Pattern Error in Param 2.\n Line#%d: %s\n", nLine, buf2);
					continue;
				}
				m_nStringStartLine = nLine;
				m_sStringStartLine = buf2;
				if( range.Exists(nStrRef) )
					updateTlkFile(tlkFile, nStrRef, pTmp);
				delete [] pTmp;
			}
			else if( m_bStringStart && (reStringStart.RegFind(buf) >= 0) )
			{
				pTmp = reStringStart.GetReplaceString(STRING_START[1]);
				if( pTmp == NULL )
				{
					fprintf(m_of, "E: String Start Pattern Error in Param 1.\n Line#%d: %s\n", nLine, buf2);
					continue;
				}
				nStrRef = _tcstoul(pTmp, NULL, 10);
				delete [] pTmp;
				pTmp = reStringStart.GetReplaceString(STRING_START[2]);
				if( pTmp == NULL )
				{
					fprintf(m_of, "E: String Start Pattern Error in Param 2.\n Line#%d: %s\n", nLine, buf2);
					continue;
				}
				sString = pTmp;
				delete [] pTmp;
				bStart = true;
				m_nStringStartLine = nLine;
				m_sStringStartLine = buf2;
			}
			else if( m_bStringEnd && (reStringEnd.RegFind(buf) >= 0) )
			{
				fprintf(m_of, "E: String End Pattern Error, Not Started.\n Line#%d: %s\n", nLine, buf2);
				continue;
			}
			else
			{
				fprintf(m_of, "I: Skip Line\n Line#%d: %s\n", nLine, buf2);
				continue;
			}
		}	// if bStart
	}	// while gets

	if( bStart )
	{
		if( range.Exists(nStrRef) )
			updateTlkFile(tlkFile, nStrRef, sString);
		bStart = false;
	}
	fclose(_if);

	fwprintf(m_of, L"\nUpdate Completed, [%d] String(s) Updated.\n", m_nUpdated);
	fclose(m_of);
	return m_nUpdated;
}

int CMergeFileRule::ExportTlkFile(CTlkFile &tlkFile, LPCTSTR lpszOutputFile, const CNumbers &range)
{
	if( tlkFile.GetElementCount() == 0 )	// Not loaded TLK File
		return -1;

	if( m_sExpString.IsEmpty() )	// Not loaded Rule
		return -1;

	FILE * _of = _tfopen(lpszOutputFile, L"wt");
	if( _of == NULL )
		return -1;

	FILE *_of2 = NULL;

	CString path = lpszOutputFile;
	int p = path.ReverseFind(L'.');
	if( p < 0 )
		path += L"_reflist.txt";
	else
		path.Insert(p, L"_reflist");

	if( ! range.IsAll() )
	{
		_of2 = _tfopen(path, L"wt");
		if( _of2 == NULL )
		{
			fclose(_of);
			return -1;
		}
	}

	m_nUpdated = 0;

	char buf[32768];

	CString sOutput;
	CString sTmp;

	SYSTEMTIME st;
	GetLocalTime(&st);

	sTmp.Format(L"Exported at %04d-%02d-%02d %02d:%02d:%02d // Simiy's Neverwinter Nights 2 TLK Editor __BEGIN",
		st.wYear, st.wMonth, st.wDay,
		st.wHour, st.wMinute, st.wSecond
		);
	sOutput.Format(m_sExpComment, sTmp);
	toMBCS(sOutput, sOutput.GetLength(), buf);
	fputs(buf, _of);

	sTmp.Format(L"File Path: '%s'", tlkFile.getFileName());
	sOutput.Format(m_sExpComment, sTmp);
	toMBCS(sOutput, sOutput.GetLength(), buf);
	fputs(buf, _of);

	sTmp.Format(L"Language: %s, Total Item = [%u/%u]",
		tlkFile.GetTlkHeader()->getLanguageString(),
		tlkFile.GetValidStringCount(),
		tlkFile.GetElementCount()
		);
	sOutput.Format(m_sExpComment, sTmp);
	toMBCS(sOutput, sOutput.GetLength(), buf);
	fputs(buf, _of);
	sOutput.Format(m_sExpComment, L"");
	toMBCS(sOutput, sOutput.GetLength(), buf);
	fputs(buf, _of);


	for(DWORD nStrRef=0; nStrRef < tlkFile.GetElementCount(); nStrRef++)
	{
		if( tlkFile.GetElement(nStrRef)->isValidText() )
		{
			if( range.Exists(nStrRef) )
			{
				if( tlkFile.GetElement(nStrRef)->GetText(sTmp) > 0 )
				{
					if( m_bExpStrRefFirst )
						sOutput.Format(m_sExpString, nStrRef, sTmp);
					else
						sOutput.Format(m_sExpString, sTmp, nStrRef);

					toMBCS(sOutput, sOutput.GetLength(), buf);
					fputs(buf, _of);
					m_nUpdated ++;

					if( _of2 )
						fprintf(_of2, "%u\n", nStrRef);	// strref list file
				}
			}
		}
	}

	sOutput.Format(m_sExpComment, L"");
	toMBCS(sOutput, sOutput.GetLength(), buf);
	fputs(buf, _of);
	sTmp.Format(L"[%d] String(s) Exported...", m_nUpdated);
	sOutput.Format(m_sExpComment, sTmp);
	toMBCS(sOutput, sOutput.GetLength(), buf);
	fputs(buf, _of);
	sOutput.Format(m_sExpComment, L"___END___");
	toMBCS(sOutput, sOutput.GetLength(), buf);
	fputs(buf, _of);

	fclose(_of);
	if( _of2 ) fclose(_of2);
	return m_nUpdated;
}

}	// namespace TLK30