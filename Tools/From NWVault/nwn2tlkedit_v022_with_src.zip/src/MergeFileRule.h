#pragma once

#include "TlkFile.h"

namespace TLK30 {

/** import & export */
class CMergeFileRule
{
	bool m_bComment;
	bool m_bString;
	bool m_bStringStart;
	bool m_bStringEnd;

	CString COMMENT;
	CString STRING[3];
	CString STRING_START[3];
	CString STRING_END[2];

	CString m_sExpComment;
	CString m_sExpString;
	bool m_bExpStrRefFirst;

private:
	int		m_nUpdated;
	FILE	*m_of;
	int		m_nStringStartLine;
	CStringA m_sStringStartLine;
	void updateTlkFile(CTlkFile &tlkFile, DWORD nStrRef, LPCTSTR sString);

	TCHAR	m_lpszOutput[512];
public:
	CMergeFileRule()
	{
		m_bComment		= false;
		m_bString		= false;
		m_bStringStart	= false;
		m_bStringEnd	= false;
	}
	virtual ~CMergeFileRule(void) { }

	bool LoadRule(LPCTSTR lpszFileName);
	int MergeTlkFile(CTlkFile &tlkFile, LPCTSTR lpszUpdateFile, const CNumbers &range);
	int ExportTlkFile(CTlkFile &tlkFile, LPCTSTR lpszOutputFile, const CNumbers &range);
	
	LPCTSTR getUpdatedResultFileName() { return m_lpszOutput; }
	void deleteUpdatedResultFile() { DeleteFile(m_lpszOutput); }
};

}