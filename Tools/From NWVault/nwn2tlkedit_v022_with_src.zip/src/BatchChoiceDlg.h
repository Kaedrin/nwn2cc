#pragma once


// CBatchChoiceDlg ��ȭ �����Դϴ�.

class CBatchChoiceDlg : public CDialog
{
	DECLARE_DYNAMIC(CBatchChoiceDlg)

public:
	CBatchChoiceDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CBatchChoiceDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_BATCH_CHOICE };

public:
	int m_nChoice;
	UINT m_nStart;
	UINT m_nEnd;
	CString m_strListFile;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedRAll();
	afx_msg void OnBnClickedRSelected();
	afx_msg void OnBnClickedRRange();
	afx_msg void OnBnClickedRSelNRange();
	virtual BOOL OnInitDialog();
protected:
	virtual void OnOK();
public:
	afx_msg void OnBnClickedCancel2();
	afx_msg void OnBnClickedBtnSelFile();
	afx_msg void OnBnClickedRListFile();
};
