// BatchChoiceDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NWN2TLKEdit.h"
#include "BatchChoiceDlg.h"


#include "TlkFile.h"


// CBatchChoiceDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CBatchChoiceDlg, CDialog)
CBatchChoiceDlg::CBatchChoiceDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBatchChoiceDlg::IDD, pParent)
{
	m_nChoice = 0;
}

CBatchChoiceDlg::~CBatchChoiceDlg()
{
}

void CBatchChoiceDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CBatchChoiceDlg, CDialog)
	ON_BN_CLICKED(IDC_R_ALL, OnBnClickedRAll)
	ON_BN_CLICKED(IDC_R_SELECTED, OnBnClickedRSelected)
	ON_BN_CLICKED(IDC_R_RANGE, OnBnClickedRRange)
	ON_BN_CLICKED(IDC_R_SEL_N_RANGE, OnBnClickedRSelNRange)
	ON_BN_CLICKED(IDC_BTN_SEL_FILE, OnBnClickedBtnSelFile)
	ON_BN_CLICKED(IDC_R_LIST_FILE, OnBnClickedRListFile)
END_MESSAGE_MAP()




BOOL CBatchChoiceDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	CheckRadioButton(IDC_R_ALL, IDC_R_LIST_FILE, IDC_R_ALL+m_nChoice);

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


void CBatchChoiceDlg::OnOK()
{
	int nID = GetCheckedRadioButton(IDC_R_ALL, IDC_R_LIST_FILE);
	m_nChoice = nID-IDC_R_ALL;


	if( (m_nChoice == 2) || (m_nChoice == 3) )
	{
		m_nStart = GetDlgItemInt(IDC_EDIT_START, NULL, 0);
		m_nEnd = GetDlgItemInt(IDC_EDIT_END, NULL, 0);

		if( m_nStart >= m_nEnd )
		{
			AfxMessageBox(L"Input Range Error !! ");
			GetDlgItem(IDC_EDIT_START)->SetFocus();
			return;
		}
	}
	else if( m_nChoice == 4 )
	{
		GetDlgItemText(IDC_EDIT_LIST_FILE, m_strListFile);
		if( m_strListFile.IsEmpty() || ! TLK30::FileExists(m_strListFile) )
		{
			AfxMessageBox(L"Select Valid List File ! ");
			return;
		}
	}

	CDialog::OnOK();
}


// CBatchChoiceDlg �޽��� ó�����Դϴ�.

void CBatchChoiceDlg::OnBnClickedRAll()
{
	GetDlgItem(IDC_BTN_SEL_FILE)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_LIST_FILE)->EnableWindow(FALSE);

	GetDlgItem(IDC_EDIT_START)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_END)->EnableWindow(FALSE);
}

void CBatchChoiceDlg::OnBnClickedRSelected()
{
	GetDlgItem(IDC_BTN_SEL_FILE)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_LIST_FILE)->EnableWindow(FALSE);

	GetDlgItem(IDC_EDIT_START)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_END)->EnableWindow(FALSE);
}

void CBatchChoiceDlg::OnBnClickedRRange()
{
	GetDlgItem(IDC_BTN_SEL_FILE)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_LIST_FILE)->EnableWindow(FALSE);

	GetDlgItem(IDC_EDIT_START)->EnableWindow(TRUE);
	GetDlgItem(IDC_EDIT_END)->EnableWindow(TRUE);
}

void CBatchChoiceDlg::OnBnClickedRSelNRange()
{
	GetDlgItem(IDC_BTN_SEL_FILE)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_LIST_FILE)->EnableWindow(FALSE);

	GetDlgItem(IDC_EDIT_START)->EnableWindow(TRUE);
	GetDlgItem(IDC_EDIT_END)->EnableWindow(TRUE);
}


void CBatchChoiceDlg::OnBnClickedRListFile()
{

	GetDlgItem(IDC_BTN_SEL_FILE)->EnableWindow(TRUE);
	GetDlgItem(IDC_EDIT_LIST_FILE)->EnableWindow(TRUE);

	GetDlgItem(IDC_EDIT_START)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_END)->EnableWindow(FALSE);

}


void CBatchChoiceDlg::OnBnClickedBtnSelFile()
{
	CFileDialog d(TRUE, L"txt", NULL, 0, L"StrRef List File (*.txt)|*.txt|All Files (*.*)|*.*||");
	if( d.DoModal() == IDOK )
	{
		SetDlgItemText(IDC_EDIT_LIST_FILE, d.GetPathName());
	}
}
