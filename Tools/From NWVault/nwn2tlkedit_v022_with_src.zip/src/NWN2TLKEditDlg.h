// NWN2TLKEditDlg.h : ��� ����
//

#pragma once
#include "afxcmn.h"
#include "afxwin.h"

#include "TlkFile.h"

#define VERSION_STRING L"v0.22"

// CNWN2TLKEditDlg ��ȭ ����
class CNWN2TLKEditDlg : public CDialog
{
// ����
public:
	CNWN2TLKEditDlg(CWnd* pParent = NULL);	// ǥ�� ������

// ��ȭ ���� ������
	enum { IDD = IDD_NWN2TLKEDIT_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ����

	void addBitmap(CImageList &imgList, UINT idBitmap, COLORREF crMask = RGB(255,255,255))
	{
		CBitmap bitmap;
		bitmap.LoadBitmap(idBitmap);
		imgList.Add(&bitmap, crMask);
	}

	CImageList			m_ilIcons;

	TLK30::CTlkFile 	m_tlkFile;
	CString				m_strCurrItem;
	DWORD				m_nCurrSelection;

	void	ChangeSelectStatus(int nStrRef, TLK30::CTlkElement *pE);	// 2007-01-14
	void	ResizeDlg(int cx, int cy);
	int		ChangedSelection();
	void	ChangeTitle()
	{
		if( m_tlkFile.getFileName().IsEmpty() )
		{
			CString sTitle;
			sTitle.Format(L"Simiy's Neverwinter Nights 2 TLK Editor %s %s",
				VERSION_STRING,
				m_tlkFile.GetTlkHeader()->getVersion() == TLK30::TLK_VER_10 ? L"(for TLK1)"
					: (	TLK30::TLK_CODE_PAGE == CP_UTF8 ? L"(for NWN2)" : L"(for NWN1)"	)
				);
			SetWindowText(sTitle);
		}
		else
		{
			CString sTitle;
			sTitle.Format(L"%sTLKEdit %s - %s%c",
				m_tlkFile.GetTlkHeader()->getVersion() == TLK30::TLK_VER_10 ? L"TLK1"
					: (	TLK30::TLK_CODE_PAGE == CP_UTF8 ? L"NWN2" : L"NWN1"	),
				VERSION_STRING,
				m_tlkFile.getFileName(), m_tlkFile.isModified() ? L'*' : L' ');
			SetWindowText(sTitle);
		}
	}
	void	ChangeStatus()
	{
		CString sStatus;
		sStatus.Format(L"%s, Strings: %u/%u (%02.1f%%), MaxSize: %d",
			m_tlkFile.GetTlkHeader()->getLanguageString(),
			m_tlkFile.GetValidStringCount(),
			m_tlkFile.GetElementCount(),
			(m_tlkFile.GetValidStringCount() == 0) ?
			0
			:
			m_tlkFile.GetValidStringCount() * 100.0 / m_tlkFile.GetElementCount(),
			m_tlkFile.GetMaxStringSize());
		SetDlgItemText(IDC_T_STATUS, sStatus);
	}
	void	RedrawDialog()
	{
		CRect rt;
		GetClientRect(rt);
		ResizeDlg(rt.Width(), rt.Height());
		m_listView.Invalidate();
	}

	void ShowFileByShellExecute(LPCTSTR lpszFileName)
	{
		ShellExecute(GetSafeHwnd(), NULL, lpszFileName, NULL, NULL, SW_SHOWNORMAL);
	}

	int ConfirmSave();	// 2007-01-03

public:
	CString					m_strRuleSetFileName;
	CFindReplaceDialog	*	m_pFindRepDlg;

protected:
	int strnistr(LPCTSTR string, LPCTSTR subString, int nLen);
	void SetSelection(DWORD nItem, bool bClear = true)
	{
		if( bClear )
		{
			POSITION pos = m_listView.GetFirstSelectedItemPosition();
			while (pos)
			{
				int item = m_listView.GetNextSelectedItem(pos);
				m_listView.SetItemState(item, 0, LVIS_SELECTED);
			}
		}
		m_listView.SetItemState(nItem, LVIS_SELECTED|LVIS_FOCUSED, LVIF_STATE|LVIF_TEXT|LVIF_IMAGE);
		m_listView.EnsureVisible(nItem, TRUE);
		m_listView.SetSelectionMark(nItem);
	}

	void DoEditSndRes(DWORD nStrRef);


	afx_msg LONG OnFindReplace(WPARAM wParam, LPARAM lParam);

// ����
protected:
	HICON m_hIcon;

	// �޽��� �� �Լ��� �����߽��ϴ�.
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CListCtrl m_listView;
	CEdit m_edtString;
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnGetMinMaxInfo(MINMAXINFO* lpMMI);
	afx_msg void OnLvnGetdispinfoListView(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnMnuOpen();
	afx_msg void OnMnuSave();
	afx_msg void OnMnuSaveAs();
	afx_msg void OnMnuExit();
	afx_msg void OnMnuAbout();
	afx_msg void OnNMClickListView(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMRclickListView(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnTimer(UINT nIDEvent);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
protected:
	virtual void OnOK();
	virtual void OnCancel();
public:
	CEdit m_edtSearch;
	afx_msg void OnBnClickedBtnSearch();
	afx_msg void OnEnChangeEditString();
	afx_msg void OnMnuViewtlksummary();
	afx_msg void OnMnuImportbatchtext();
	afx_msg void OnMnuExportbatchtext();
	afx_msg void OnBnClickedButton1();
	afx_msg void OnMnuSelLang();
	afx_msg void OnMnuShowreadme();
	afx_msg void OnMnuShowhistory();
	afx_msg void OnMnuFind();
	afx_msg void OnMnuComparetlkfile();
	afx_msg void OnMnuExportMbcs();
	afx_msg void OnMnuExtractDiffAdded();
	afx_msg void OnMnuExtractDiffDeleted();
	afx_msg void OnMnuExtractDiffUpdated();
	afx_msg void OnMnuFindText();
	virtual BOOL DestroyWindow();
	afx_msg void OnMnuInittlk();
	afx_msg void OnNMDblclkListView(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnMnuEditsndres();
	afx_msg void OnBnClickedBtnFindSnd();
};
