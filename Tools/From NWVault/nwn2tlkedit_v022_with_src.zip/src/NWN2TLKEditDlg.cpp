// NWN2TLKEditDlg.cpp : ���� ����
//

#include "stdafx.h"
#include "NWN2TLKEdit.h"
#include "NWN2TLKEditDlg.h"

#include "TlkFile.h"
#include "MergeFileRule.h"
#include "RegExp.h"

#include "BatchChoiceDlg.h"
#include "InitSizeDlg.h"
#include "SndResDlg.h"
#include ".\nwn2tlkeditdlg.h"


using namespace TLK30;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// ���� ���α׷� ������ ���Ǵ� CAboutDlg ��ȭ �����Դϴ�.

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// ��ȭ ���� ������
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ����

// ����
protected:
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


BOOL CAboutDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


// CSelLangDlg ��ȭ �����Դϴ�.

class CSelLangDlg : public CDialog
{
	DECLARE_DYNAMIC(CSelLangDlg)

public:
	CSelLangDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CSelLangDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_SELECT_LANG };

	CString m_strSelLang;
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
	virtual void OnOK();
public:
	virtual BOOL OnInitDialog();
};

// CSelLangDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CSelLangDlg, CDialog)
CSelLangDlg::CSelLangDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSelLangDlg::IDD, pParent)
{
}

CSelLangDlg::~CSelLangDlg()
{
}

void CSelLangDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CSelLangDlg, CDialog)
END_MESSAGE_MAP()


BOOL CSelLangDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	((CComboBox*)GetDlgItem(IDC_COMBO_LANG))->SelectString(0, m_strSelLang);

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CSelLangDlg::OnOK()
{
	GetDlgItemText(IDC_COMBO_LANG, m_strSelLang);
	if( m_strSelLang.IsEmpty() )
	{
		AfxMessageBox(L"Select Language ! ");
		return;
	}

	CDialog::OnOK();
}


// CNWN2TLKEditDlg ��ȭ ����



CNWN2TLKEditDlg::CNWN2TLKEditDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNWN2TLKEditDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_pFindRepDlg = NULL;
}

void CNWN2TLKEditDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_VIEW, m_listView);
	DDX_Control(pDX, IDC_EDIT_STRING, m_edtString);
	DDX_Control(pDX, IDC_EDIT_SEARCH, m_edtSearch);
}

static UINT WM_FINDREPLACE = ::RegisterWindowMessage(FINDMSGSTRING);


BEGIN_MESSAGE_MAP(CNWN2TLKEditDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_WM_SIZE()
	ON_WM_GETMINMAXINFO()
	ON_NOTIFY(LVN_GETDISPINFO, IDC_LIST_VIEW, OnLvnGetdispinfoListView)
	ON_COMMAND(ID_MNU_OPEN, OnMnuOpen)
	ON_COMMAND(ID_MNU_SAVE, OnMnuSave)
	ON_COMMAND(ID_MNU_SAVE_AS, OnMnuSaveAs)
	ON_COMMAND(ID_MNU_EXIT, OnMnuExit)
	ON_COMMAND(ID_MNU_ABOUT, OnMnuAbout)
	ON_NOTIFY(NM_CLICK, IDC_LIST_VIEW, OnNMClickListView)
	ON_NOTIFY(NM_RCLICK, IDC_LIST_VIEW, OnNMRclickListView)
	ON_WM_TIMER()
	ON_WM_HELPINFO()
	ON_BN_CLICKED(IDC_BTN_SEARCH, OnBnClickedBtnSearch)
	ON_EN_CHANGE(IDC_EDIT_STRING, OnEnChangeEditString)
	ON_COMMAND(ID_MNU_VIEWTLKSUMMARY, OnMnuViewtlksummary)
	ON_COMMAND(ID_MNU_IMPORTBATCHTEXT, OnMnuImportbatchtext)
	ON_COMMAND(ID_MNU_EXPORTBATCHTEXT, OnMnuExportbatchtext)
	ON_COMMAND(ID_MNU_SEL_LANG, OnMnuSelLang)
	ON_COMMAND(ID_MNU_SHOWREADME, OnMnuShowreadme)
	ON_COMMAND(ID_MNU_SHOWHISTORY, OnMnuShowhistory)
	ON_COMMAND(ID_MNU_FIND, OnMnuFind)
	ON_COMMAND(ID_MNU_COMPARETLKFILE, OnMnuComparetlkfile)
	ON_COMMAND(ID_MNU_EXPORT_MBCS, OnMnuExportMbcs)
	ON_COMMAND(ID_MNU_EXTRACT_DIFF_ADDED, OnMnuExtractDiffAdded)
	ON_COMMAND(ID_MNU_EXTRACT_DIFF_DELETED, OnMnuExtractDiffDeleted)
	ON_COMMAND(ID_MNU_EXTRACT_DIFF_UPDATED, OnMnuExtractDiffUpdated)
	ON_COMMAND(ID_MNU_FIND_TEXT, OnMnuFindText)
	ON_REGISTERED_MESSAGE( WM_FINDREPLACE, OnFindReplace )
	ON_COMMAND(ID_MNU_INITTLK, OnMnuInittlk)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_VIEW, OnNMDblclkListView)
	ON_COMMAND(ID_MNU_EDITSNDRES, OnMnuEditsndres)
	ON_BN_CLICKED(IDC_BTN_FIND_SND, OnBnClickedBtnFindSnd)
END_MESSAGE_MAP()


// CNWN2TLKEditDlg �޽��� ó����




BOOL CNWN2TLKEditDlg::DestroyWindow()
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	if( m_pFindRepDlg )
	{
		m_pFindRepDlg->DestroyWindow();
	}

	return CDialog::DestroyWindow();
}

void CNWN2TLKEditDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// ��ȭ ���ڿ� �ּ�ȭ ���߸� �߰��� ��� �������� �׸����� 
// �Ʒ� �ڵ尡 �ʿ��մϴ�. ����/�� ���� ����ϴ� MFC ���� ���α׷��� ��쿡��
// �����ӿ�ũ���� �� �۾��� �ڵ����� �����մϴ�.

void CNWN2TLKEditDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // �׸��⸦ ���� ����̽� ���ؽ�Ʈ

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Ŭ���̾�Ʈ �簢������ �������� ����� ����ϴ�.
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// �������� �׸��ϴ�.
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// ����ڰ� �ּ�ȭ�� â�� ���� ���ȿ� Ŀ���� ǥ�õǵ��� �ý��ۿ���
//  �� �Լ��� ȣ���մϴ�. 
HCURSOR CNWN2TLKEditDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

BOOL CNWN2TLKEditDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// �ý��� �޴��� "����..." �޴� �׸��� �߰��մϴ�.

	// IDM_ABOUTBOX�� �ý��� ���� ������ �־�� �մϴ�.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// �� ��ȭ ������ �������� �����մϴ�. ���� ���α׷��� �� â�� ��ȭ ���ڰ� �ƴ� ��쿡��
	// �����ӿ�ũ�� �� �۾��� �ڵ����� �����մϴ�.
	SetIcon(m_hIcon, TRUE);			// ū �������� �����մϴ�.
	SetIcon(m_hIcon, FALSE);		// ���� �������� �����մϴ�.

	// TODO: ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.

	int nArgs;
	LPWSTR * pArgs = CommandLineToArgvW(GetCommandLineW(), &nArgs);
	for( int i = 1; i<nArgs; i++)
	{
		if( _tcsicmp(pArgs[i], L"-c") == 0 )
		{
			if( (i+1) < nArgs )
			{
				m_strRuleSetFileName = pArgs[i+1];
			}
			i++;
		}
		else if( _tcsicmp(pArgs[i], L"-m") == 0 )
		{
			//TLK30::TLK_CODE_PAGE = CP_UTF8;	// is default
			if( (i+1) < nArgs )
			{
				if( _tcsicmp( pArgs[i+1], L"NWN1") == 0 )
				{
					TLK30::TLK_CODE_PAGE = CP_ACP;
					m_tlkFile.SetVersion(TLK_VER_30);
				}
				else if( _tcsicmp( pArgs[i+1], L"NWN2") == 0 )
				{
					TLK30::TLK_CODE_PAGE = CP_ACP;
					m_tlkFile.SetVersion(TLK_VER_30);
				}
				else if( _tcsicmp(pArgs[i+1], L"TLK1") == 0 )
				{
					TLK30::TLK_CODE_PAGE = CP_ACP;
					m_tlkFile.SetVersion(TLK_VER_10);
				}
			}
			i++;
		}
	}

	if( ! FileExists(m_strRuleSetFileName.GetString()) )
	{
		TCHAR path[512];
		GetModuleFileName(NULL, path, 512);
		ExtractDirectory(path, m_strRuleSetFileName);
		m_strRuleSetFileName += L"RuleSet.ini";
	}
	
	ChangeTitle( );
	
	CRect rt;
	m_listView.GetClientRect(rt);
	m_listView.SetExtendedStyle( m_listView.GetExtendedStyle() | LVS_EX_FULLROWSELECT /* | LVS_EX_GRIDLINES | LVS_EX_SUBITEMIMAGES */);
	m_listView.InsertColumn(0, L"StrRef", LVCFMT_LEFT, 90);
	m_listView.InsertColumn(1, L"String", LVCFMT_LEFT, 80);

	GetClientRect(rt);
	ResizeDlg(rt.Width(), rt.Height());

	SetTimer(5555, 500, NULL);	// ���� ��ȭ Ȯ��

	
	m_ilIcons.Create(16,16,ILC_COLORDDB|ILC_MASK,0,3);
	addBitmap(m_ilIcons, IDB_EMPTY);
	addBitmap(m_ilIcons, IDB_ONE);
	addBitmap(m_ilIcons, IDB_FULL);
	m_listView.SetImageList(&m_ilIcons, LVSIL_SMALL);

	return TRUE;  // ��Ʈ�ѿ� ���� ��Ŀ���� �������� ���� ��� TRUE�� ��ȯ�մϴ�.
}

void CNWN2TLKEditDlg::OnGetMinMaxInfo(MINMAXINFO* lpMMI)
{
	if( lpMMI->ptMinTrackSize.x < 480 || lpMMI->ptMinTrackSize.y < 400 )
	{
		lpMMI->ptMinTrackSize.x = 480;
		lpMMI->ptMinTrackSize.y = 400;
	}

	CDialog::OnGetMinMaxInfo(lpMMI);
}

void CNWN2TLKEditDlg::ResizeDlg(int cx, int cy)
{
	TRACE(L"ResizeDlg (%d, %d)\n", cx, cy);

	// Edit View
	CRect rtEdt;	m_edtString.GetWindowRect(rtEdt);
	m_edtString.MoveWindow( 8, cy - rtEdt.Height() - 8, cx - 16, rtEdt.Height(), 1);

	// List View
	CRect rtView;
	//m_listView.GetWindowRect(rtView); this->ScreenToClient(rtView);	// top == 60
	m_listView.MoveWindow(8, 60 /* ������ ������ ���� ���ϵ��� */, cx - 16, cy - rtEdt.Height() - 60 - 16, 1);
	m_listView.GetClientRect(rtView);
	m_listView.SetColumnWidth(1, rtView.Width() - 92);

	// Tlk Status View
	CWnd *pWnd = GetDlgItem(IDC_T_STATUS);
	CRect rt;
	pWnd->GetWindowRect(rt);
	this->ScreenToClient(rt);
	pWnd->MoveWindow( rt.left, rt.top, cx - rt.left - 8, rt.Height(), 1);
	pWnd->InvalidateRect(NULL);

	// Item Status View
	pWnd = GetDlgItem(IDC_EDIT_SEL_ITEM);
	pWnd->GetWindowRect(rt);
	this->ScreenToClient(rt);
	pWnd->MoveWindow( rt.left, rt.top, cx - rt.left - 12, rt.Height(), 1);
}

void CNWN2TLKEditDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	if( m_listView.GetSafeHwnd() && m_edtString.GetSafeHwnd() )
	{
		ResizeDlg(cx, cy);
	}
}


void CNWN2TLKEditDlg::OnLvnGetdispinfoListView(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);
	
	LV_ITEM* pItem= &(pDispInfo)->item;
	
	DWORD i = pItem->iItem;
	TLK30::CTlkElement *pE = m_tlkFile.GetElement(i);
	if(pItem->mask & LVIF_TEXT)
	{
		switch(pItem->iSubItem)
		{
		case 0:	// field 1
			// m_listView.InsertItem(LVIF_TEXT, i, s, 0, 0, 0, 0);
			m_strCurrItem.Format(L"%08u", i);
			pItem->pszText = (LPTSTR)m_strCurrItem.GetString();
			if(pItem->mask & LVIF_IMAGE)
			{
				pItem->iImage  =
						(!pE->isTextPresent() && !pE->isSndPresent()) ? 0 : ((pE->isTextPresent() && pE->isSndPresent()) ? 2 : 1);
			}
			//pItem->ccchTextMax = m_strCurrItem.GetLength();
			//m_listView.SetItemData(i, (DWORD_PTR) pE);
			break;
		case 1:
			if( pE->GetText(m_strCurrItem) > 0 )
			{
				pItem->pszText = (LPTSTR)m_strCurrItem.GetString();
				//pItem->ccchTextMax = m_strCurrItem.GetLength();
			}
			else
			{
				pItem->pszText = _T("");
			}
			break;
		default:
			break;
		}	// switch
	}
	
	*pResult = 0;
}


int CNWN2TLKEditDlg::ConfirmSave()
{
	int nResult = IDNO;
	if( m_tlkFile.isModified() )
	{
		nResult = AfxMessageBox(L"TalkTable is modified. Do you want to save? ", MB_YESNOCANCEL);
		if( nResult  == IDYES )
		{
			OnMnuSave();
		}
	}
	return nResult;
}

void CNWN2TLKEditDlg::OnMnuInittlk()
{
	if( ConfirmSave() == IDCANCEL )
		return;

	CInitSizeDlg d;
	if( d.DoModal() == IDOK )
	{
		CWaitCursor cur;
		m_tlkFile.InitFile(d.m_nInitSize);
		m_listView.SetItemCountEx(m_tlkFile.GetElementCount());
		cur.Restore();

		m_nCurrSelection = -1;

		ChangeTitle( );
		ChangeStatus( );
		RedrawDialog( );
	}
}


void CNWN2TLKEditDlg::OnMnuOpen()
{
	if( ConfirmSave() == IDCANCEL )
		return;

	CFileDialog d(TRUE, L"tlk", NULL, 0, L"Talk Table Files (*.tlk)|*.tlk|All Files (*.*)|*.*||");
	if( d.DoModal() == IDOK )
	{
		DWORD S = ::GetTickCount();
		
		CWaitCursor cur;
		bool bLoadSuccess = m_tlkFile.LoadFile( d.GetPathName() );
		m_listView.SetItemCountEx(m_tlkFile.GetElementCount());
		cur.Restore();

		DWORD E = ::GetTickCount();
		
		TRACE(L"Elapsed = [%f]\n", (E-S)/1000.0);

		m_nCurrSelection = -1;

		ChangeTitle( );
		ChangeStatus( );
		RedrawDialog( );
		if( ! bLoadSuccess )
		{
			// 2007-01-14
			CString msg;
			msg.Format(L"\"%s\" Load Failed...!! ", d.GetPathName());
			AfxMessageBox( msg, MB_OK | MB_ICONEXCLAMATION );
		}
	}
}


void CNWN2TLKEditDlg::OnMnuSave()
{
	if( m_tlkFile.getFileName().IsEmpty() )
	{
		OnMnuSaveAs();
		return;
	}

	if( ! m_tlkFile.SaveFile() )
	{
		AfxMessageBox(L"Failed to Save...!! ", MB_ICONSTOP);
	}
	ChangeTitle( );
}

void CNWN2TLKEditDlg::OnMnuSaveAs()
{
	CFileDialog d(FALSE, L"tlk", NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, L"Talk Table Files (*.tlk)|*.tlk|All Files (*.*)|*.*||");
	if( d.DoModal() == IDOK )
	{
		if( !m_tlkFile.SaveAsFile( d.GetPathName() ) )
		{
			AfxMessageBox(L"Failed to Save...!! ", MB_ICONSTOP);
		}
	}
	ChangeTitle( );
}

void CNWN2TLKEditDlg::OnOK()
{
	if( ConfirmSave() == IDCANCEL )
		return;

	CDialog::OnOK();
}


void CNWN2TLKEditDlg::OnCancel()
{
	OnOK();
	//CDialog::OnCancel();
}

void CNWN2TLKEditDlg::OnMnuExit()
{
	OnOK();
}

void CNWN2TLKEditDlg::OnMnuAbout()
{
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
}

void CNWN2TLKEditDlg::ChangeSelectStatus(int nStrRef, TLK30::CTlkElement *pE)	// added 2007-01-14
{
	CString rSndRes, rStatus;

	if( pE->isSndPresent() )
	{
		pE->GetSoundResRef(rSndRes);
		rSndRes.Trim();
	}
	if( rSndRes.GetLength() <= 0 )
		rSndRes = L"N/A";

	rStatus.Format(L"StrRef = %d 0x%0x %d 0x%0x, StrSize = %u, SndRes = %s",
			nStrRef,
			nStrRef,
			nStrRef + 0x01000000,
			nStrRef + 0x01000000,
			pE->DataStringSize(),
			rSndRes
			);
	SetDlgItemText(IDC_EDIT_SEL_ITEM, rStatus);
}

int CNWN2TLKEditDlg::ChangedSelection()
{
	POSITION pos = m_listView.GetFirstSelectedItemPosition();
	if (pos == NULL)
	{
		m_nCurrSelection = -1;
		m_edtString.SetWindowText(L"");
		SetDlgItemText(IDC_EDIT_SEL_ITEM, L"N/A");
		return -1;
	}
	else
	{
		int item = m_listView.GetNextSelectedItem(pos);
		if( item != m_nCurrSelection )
		{
			m_nCurrSelection = item;
			CTlkElement *pE = m_tlkFile.GetElement(m_nCurrSelection);
			CString rString;

			if( pE->GetText(rString) )
			{
				if( rString.Find(L'\n') >= 0 )
				{
					rString.Remove(L'\r');
					rString.Replace(L"\n", L"\r\n");
				}
				else if( rString.Find(L'\r') >= 0 )
				{
					// buggy tlk file (not use NL character!)
					rString.Replace(L"\r", L"\r\n");
				}
				m_edtString.SetWindowText(rString);
			}
			else	// 2007-01-03'2th added
			{
				m_edtString.SetWindowText(L"");
			}

			ChangeSelectStatus(item, pE);	// changed 2007-01-14
		}
		return item;
	}
}

void CNWN2TLKEditDlg::OnNMClickListView(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	ChangedSelection();
	*pResult = 0;
}

void CNWN2TLKEditDlg::OnNMRclickListView(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if( ChangedSelection() >= 0 )
	{
		POINT curScreenPt; // GetMessagePos()
		GetCursorPos(&curScreenPt);
		CMenu *pPopup = this->GetMenu()->GetSubMenu(1);

		/*
		pPopup->EnableMenuItem(ID_MNU_EDITSNDRES, MF_BYCOMMAND | MF_ENABLED);
		...
		*/
		DWORD nID = pPopup->TrackPopupMenuEx(TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RETURNCMD, curScreenPt.x, curScreenPt.y, this, NULL);
		switch( nID )
		{
		case ID_MNU_FIND:
			this->OnMnuFind();
			break;
		case ID_MNU_FIND_TEXT:
			this->OnMnuFindText();
			break;
		case ID_MNU_EDITSNDRES:
			this->DoEditSndRes(m_nCurrSelection);
			break;
		}
	}
	*pResult = 0;
}

void CNWN2TLKEditDlg::DoEditSndRes(DWORD nStrRef)
{
	CSndResDlg d;
	d.m_nStrRef		= nStrRef;
	d.m_pTlkElement = m_tlkFile.GetElement(nStrRef);
	if(d.DoModal() == IDOK)
	{
		if( d.m_bModified )
		{
			if( ! m_tlkFile.Modified() )
			{
				ChangeTitle();
				ChangeSelectStatus(nStrRef, d.m_pTlkElement);	// added 2007-01-14
			}
		}
	}
}

void CNWN2TLKEditDlg::OnNMDblclkListView(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	UINT nFlags;
	POINT curScreenPt; // GetMessagePos()
	GetCursorPos(&curScreenPt);
	CPoint curClientPoint = curScreenPt;
	m_listView.ScreenToClient(&curClientPoint);

	//int nItem = HitTestMine(curScreenPt);
	int nItem = m_listView.HitTest( curClientPoint, &nFlags );
	if ((nItem >= 0) && (TVHT_ONITEM & nFlags))
	{
		this->DoEditSndRes(nItem);
	}
	*pResult = 0;
}


void CNWN2TLKEditDlg::OnTimer(UINT nIDEvent)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	switch( nIDEvent )
	{
	case 5555:	// ���� Ȯ��
		if( m_listView.GetSafeHwnd() )
		{
			ChangedSelection();
		}
		break;
	default:
		;
	}
	CDialog::OnTimer(nIDEvent);
}

void CNWN2TLKEditDlg::OnEnChangeEditString()
{
	// TODO:  RICHEDIT ��Ʈ���� ��� �� ��Ʈ����
	// CDialog::����ũ�� OR �����Ͽ� ������ ENM_CHANGE �÷��׸� �����Ͽ�
	// CRichEditCtrl().SetEventMask()�� ȣ���ϵ��� OnInitDialog() �Լ��� ���������� ������
	// �� �˸��� ������ �ʽ��ϴ�.

	if( m_nCurrSelection <= 0x00ffffff )
	{
		CString /*rString1,*/ rString2;
		m_edtString.GetWindowText(rString2);
		
		CTlkElement *pE = m_tlkFile.GetElement(m_nCurrSelection);
		if( pE )
		{
			//pE->GetText(rString1);
			rString2.Remove(L'\r');

			bool bModified = m_tlkFile.isModified();

			pE->SetString(rString2, rString2.GetLength());
			m_tlkFile.Modified();
			
			m_listView.Update(m_nCurrSelection);

			if( ! bModified && m_tlkFile.isModified() )
			{
				ChangeTitle();
			}

			ChangeSelectStatus(m_nCurrSelection, pE);	// added 2007-01-14
		}
	}
}

BOOL CNWN2TLKEditDlg::PreTranslateMessage(MSG* pMsg)
{
	if( pMsg->message == WM_KEYDOWN )
	{
		if( pMsg->wParam == VK_RETURN )
		{
			if( pMsg->hwnd == m_edtString.GetSafeHwnd() )
				;
			else if( pMsg->hwnd == m_edtSearch.GetSafeHwnd() )
			{
				OnBnClickedBtnSearch();
				return TRUE;
			}
			else
				return TRUE;
		}
		else if ((pMsg->wParam == VK_ESCAPE) )
			return TRUE;
	}
	return CDialog::PreTranslateMessage(pMsg);
}

BOOL CNWN2TLKEditDlg::OnHelpInfo(HELPINFO* pHelpInfo)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	//this->OnMnuShowreadme();
	return TRUE;
	//return CDialog::OnHelpInfo(pHelpInfo);
}

void CNWN2TLKEditDlg::OnBnClickedBtnSearch()
{
	CString rString;
	m_edtSearch.GetWindowText(rString);

	TCHAR *pCh;
	DWORD nItem = _tcstoul(rString, &pCh, 10);
	if( (nItem == 0) && (rString.Left(2).Compare(L"0x") == 0) )
	{
		nItem = _tcstoul(rString, &pCh, 16);
	}

	nItem = m_tlkFile.RefToIndex(nItem);
	if( nItem < m_tlkFile.GetElementCount() )
	{
		SetSelection(nItem);
	}
	m_edtSearch.SetFocus();
}


void CNWN2TLKEditDlg::OnBnClickedBtnFindSnd()
{
	CString rString;
	m_edtSearch.GetWindowText(rString);

	DWORD nItem = m_tlkFile.GetElementCount();
	DWORD i = m_nCurrSelection+1;
	if( (i < 0) || (i >= m_tlkFile.GetElementCount()) )
		i = 0;

	CString rSndRes;
	for( ; i < m_tlkFile.GetElementCount(); i++)
	{
		if( m_tlkFile.GetElement(i)->isSndPresent() )
		{
			if( rString.GetLength() == 0 )
			{
				if( m_tlkFile.GetElement(i)->GetSoundResRef(rSndRes) > 0 )	// 2007-01-14
				{
					TRACE("SndRes Length = [%d]\n", rSndRes.GetLength());
					nItem = i;
					break;
				}
			}
			else if( (m_tlkFile.GetElement(i)->GetSoundResRef(rSndRes) > 0) && (rSndRes.Find(rString) >= 0) )
			{
				nItem = i;
				break;
			}
		}
	}
	if( nItem < m_tlkFile.GetElementCount() )
	{
		SetSelection(nItem);
	}
	else
	{
		CString msg;
		msg.Format(L"Not found \"%s\" SndRes", rString);
		AfxMessageBox(msg, MB_OK | MB_ICONINFORMATION);
	}
	m_edtSearch.SetFocus();
}

void CNWN2TLKEditDlg::OnMnuViewtlksummary()
{
	CString sFileName;
	m_tlkFile.GenerateSummary(sFileName);
	ShowFileByShellExecute( sFileName );
}

void CNWN2TLKEditDlg::OnMnuImportbatchtext()
{
	if( m_tlkFile.GetElementCount() == 0 )
	{
		AfxMessageBox(L"Current Talk Table is Empty. Execute after TLK file was loaded. ");
		return;
	}


	CMergeFileRule mergeRule;
	if( ! mergeRule.LoadRule(m_strRuleSetFileName) )
	{
		CString msg;
		msg.Format(L"Failed to Load RuleSet...\r\nPlease verify \"%s\" file. ", m_strRuleSetFileName);
		AfxMessageBox(msg);
		return;
	}

	CNumbers numbers;

	POSITION pos = NULL;
	CBatchChoiceDlg oDlg;
	if( oDlg.DoModal() != IDOK )
	{
		return;
	}

	switch(oDlg.m_nChoice)
	{
	case 1:	// select items
		pos = m_listView.GetFirstSelectedItemPosition();
		if (pos == NULL)
		{
			AfxMessageBox(L"Selected Count is Zero. Execute after you select list item(s). ");
			return;
		}
		else
		{
			while(pos)
				numbers.SetSelValue((UINT) m_listView.GetNextSelectedItem(pos));
		}
		break;
	case 2:
		numbers.SetRange(oDlg.m_nStart, oDlg.m_nEnd);
	case 3:
		pos = m_listView.GetFirstSelectedItemPosition();
		while(pos)
			numbers.SetSelValue((UINT) m_listView.GetNextSelectedItem(pos));
		break;
	case 4:
		numbers.SetListFile(oDlg.m_strListFile);
		break;
	case 0:
	default:
		break;
	}
	
	CFileDialog d(TRUE, L"txt", NULL, 0, L"Import Batch Text File (*.txt)|*.txt|All Files (*.*)|*.*||");
	if( d.DoModal() == IDOK )
	{
		DWORD S = ::GetTickCount();
		DWORD E = S;

		CWaitCursor cur;
		int nUpdated = mergeRule.MergeTlkFile(m_tlkFile, d.GetPathName(), numbers);

		if(nUpdated < 0)
		{
			E = ::GetTickCount();
			cur.Restore();
			AfxMessageBox(L"Upate Job Failed... ");
		}
		else if( nUpdated > 0 )
		{
			m_tlkFile.Modified(true);
			m_listView.SetItemCountEx(m_tlkFile.GetElementCount());
			E = ::GetTickCount();
			m_nCurrSelection = -1;

			ChangeTitle( );
			ChangeStatus( );
			RedrawDialog( );

			cur.Restore();
			ShowFileByShellExecute( mergeRule.getUpdatedResultFileName() );
		}
		else
		{
			E = ::GetTickCount();
			cur.Restore();
			ShowFileByShellExecute( mergeRule.getUpdatedResultFileName() );
		}
		TRACE(L"Elapsed = [%f]\n", (E-S) == 0 ? 0.0 : (E-S)/1000.0);
	}
}

void CNWN2TLKEditDlg::OnMnuExportbatchtext()
{
	if( m_tlkFile.GetElementCount() == 0 )
	{
		AfxMessageBox(L"Current Talk Table is Empty. Execute after TLK file was loaded. ");
		return;
	}

	CMergeFileRule mergeRule;
	if( ! mergeRule.LoadRule(m_strRuleSetFileName) )
	{
		CString msg;
		msg.Format(L"Failed to Load RuleSet...\r\nPlease verify \"%s\" file. ", m_strRuleSetFileName);
		AfxMessageBox(msg);
		return;
	}

	CNumbers numbers;

	POSITION pos = NULL;
	CBatchChoiceDlg oDlg;
	if( oDlg.DoModal() != IDOK )
	{
		return;
	}

	switch(oDlg.m_nChoice)
	{
	case 1:	// select items
		pos = m_listView.GetFirstSelectedItemPosition();
		if (pos == NULL)
		{
			AfxMessageBox(L"Selected Count is Zero. Execute after you select list item(s). ");
			return;
		}
		else
		{
			while(pos)
				numbers.SetSelValue((UINT) m_listView.GetNextSelectedItem(pos));
		}
		break;
	case 2:
		numbers.SetRange(oDlg.m_nStart, oDlg.m_nEnd);
	case 3:
		pos = m_listView.GetFirstSelectedItemPosition();
		while(pos)
			numbers.SetSelValue((UINT) m_listView.GetNextSelectedItem(pos));
		break;
	case 4:
		numbers.SetListFile(oDlg.m_strListFile);
		break;
	case 0:
	default:
		break;
	}

	CFileDialog d(FALSE, L"txt", NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, L"Export Batch Text File (*.txt)|*.txt|All Files (*.*)|*.*||");
	if( d.DoModal() == IDOK )
	{
		DWORD S = ::GetTickCount();
		DWORD E = S;

		CWaitCursor cur;
		int nUpdated = mergeRule.ExportTlkFile(m_tlkFile, d.GetPathName(), numbers);

		if(nUpdated < 0)
		{
			E = ::GetTickCount();
			cur.Restore();
			AfxMessageBox(L"Export Failed.. ");
		}
		else
		{
			cur.Restore();
			E = ::GetTickCount();

			CString msg;
			msg.Format(L"Exported [%d] item(s) to \"%s\".. \r\n* Elapsed = [%.2f] seconds ",
				nUpdated,
				d.GetPathName(),
				(E-S) == 0 ? 0.0 : (E-S)/1000.0
				 );
			AfxMessageBox(msg);
		}
		TRACE(L"Elapsed = [%f]\n", (E-S)/1000.0);
	}
}

void CNWN2TLKEditDlg::OnBnClickedButton1()
{
	CRegExp re;
	int n;
	if( re.RegComp(L"^([0-9]+)[ \\t]*:=[ \\t]+(.*);#$") )
	{
		n = re.RegFind(L"0:= �ٹٸ���;#");
		n = re.RegFind(L"0 := �ٹٸ���;#");
		n = re.RegFind(L"0  :=   �ٹٸ���;#");
		n = re.RegFind(L"0 := �ٹٸ���;#");
	}
	else
	{
		TRACE(L"...\n");

	}

}

void CNWN2TLKEditDlg::OnMnuSelLang()
{
	CSelLangDlg d;

	d.m_strSelLang.Format(L"%s (%u)", m_tlkFile.GetTlkHeader()->getLanguageString(), m_tlkFile.GetTlkHeader()->getLanguageId());
	if( d.DoModal() == IDOK )
	{
		int l = d.m_strSelLang.Find(L'(');
		int r = d.m_strSelLang.Find(L')');
		DWORD lang = _ttoi(d.m_strSelLang.Mid(l+1, r-l-1));
		if( m_tlkFile.GetTlkHeader()->getLanguageId() != lang )
		{
			m_tlkFile.GetTlkHeader()->LanguageID = lang;
			this->ChangeStatus();
			if( ! m_tlkFile.isModified() )
			{
				m_tlkFile.Modified(true);
				this->ChangeTitle();
			}
		}
	}
}

void CNWN2TLKEditDlg::OnMnuShowreadme()
{
	CString sFileName;
	TCHAR path[512];
	GetModuleFileName(NULL, path, 512);
	ExtractDirectory(path, sFileName);
	sFileName += L"readme.txt";
	ShowFileByShellExecute(sFileName);
}

void CNWN2TLKEditDlg::OnMnuShowhistory()
{
	CString sFileName;
	TCHAR path[512];
	GetModuleFileName(NULL, path, 512);
	ExtractDirectory(path, sFileName);
	sFileName += L"history.txt";
	ShowFileByShellExecute(sFileName);
}

void CNWN2TLKEditDlg::OnMnuFind()
{
	GetDlgItem(IDC_EDIT_SEARCH)->SetFocus();
}


void CNWN2TLKEditDlg::OnMnuEditsndres()
{
	if( m_nCurrSelection <= 0x00ffffff )
	{
		DoEditSndRes( m_nCurrSelection );
	}
	else
		AfxMessageBox(L"Select string item for editing ! ");
}


void CNWN2TLKEditDlg::OnMnuComparetlkfile()
{
	CFileDialog d(TRUE, L"tlk", NULL, 0, L"Talk Table Files (*.tlk)|*.tlk|All Files (*.*)|*.*||");
	if( d.DoModal() == IDOK )
	{
		DWORD S = ::GetTickCount();
		
		CString rResult;
		CWaitCursor cur;

		m_tlkFile.CompareTlkFile(d.GetPathName(), rResult);
		cur.Restore();

		DWORD E = ::GetTickCount();
		
		TRACE(L"Elapsed = [%f]\n", (E-S)/1000.0);

		ShowFileByShellExecute(rResult);
	}
	
}

void CNWN2TLKEditDlg::OnMnuExportMbcs()
{
	if( m_tlkFile.GetElementCount() == 0 )
	{
		AfxMessageBox(L"Current Talk Table is Empty. Execute after TLK file was loaded. ");
		return;
	}

	CMergeFileRule mergeRule;
	if( ! mergeRule.LoadRule(m_strRuleSetFileName) )
	{
		CString msg;
		msg.Format(L"Failed to Load RuleSet...\r\nPlease verify \"%s\" file. ", m_strRuleSetFileName);
		AfxMessageBox(msg);
		return;
	}

	CFileDialog d(FALSE, L"txt", NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, L"Export Text File (*.txt)|*.txt|All Files (*.*)|*.*||");
	if( d.DoModal() == IDOK )
	{
		CNumbers numbers;

		DWORD S = ::GetTickCount();
		DWORD E = S;

		CWaitCursor cur;

		m_tlkFile.CollectMultiBytesCharStrRef(numbers);
		int nUpdated = mergeRule.ExportTlkFile(m_tlkFile, d.GetPathName(), numbers);

		if(nUpdated < 0)
		{
			E = ::GetTickCount();
			cur.Restore();
			AfxMessageBox(L"Export Failed.. ");
		}
		else
		{
			cur.Restore();
			E = ::GetTickCount();

			CString msg;
			msg.Format(L"Exported [%d] item(s) to \"%s\".. \r\n* Elapsed = [%.2f] seconds ",
				nUpdated,
				d.GetPathName(),
				(E-S) == 0 ? 0.0 : (E-S)/1000.0
				 );
			AfxMessageBox(msg);
		}
		TRACE(L"Elapsed = [%f]\n", (E-S)/1000.0);
	}
	
}

void CNWN2TLKEditDlg::OnMnuExtractDiffAdded()
{
	if( m_tlkFile.GetElementCount() == 0 )
	{
		AfxMessageBox(L"Current Talk Table is Empty. Execute after TLK file was loaded. ");
		return;
	}

	CMergeFileRule mergeRule;
	if( ! mergeRule.LoadRule(m_strRuleSetFileName) )
	{
		CString msg;
		msg.Format(L"Failed to Load RuleSet...\r\nPlease verify \"%s\" file. ", m_strRuleSetFileName);
		AfxMessageBox(msg);
		return;
	}

	CFileDialog d(TRUE, L"tlk", NULL, 0, L"Talk Table Files (*.tlk)|*.tlk|All Files (*.*)|*.*||");
	if( d.DoModal() != IDOK )
	{
		return;
	}

	CFileDialog d2(FALSE, L"txt", NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, L"Export Text File (*.txt)|*.txt|All Files (*.*)|*.*||");
	if( d2.DoModal() == IDOK )
	{
		CNumbers numbers;

		DWORD S = ::GetTickCount();
		DWORD E = S;

		CWaitCursor cur;
		int nExtracted = m_tlkFile.CollectDiffStrRef(d.GetPathName(), &numbers, NULL, NULL);
		// 2007-01-14
		int nUpdated = ( nExtracted <= 0 ) ? 0 : mergeRule.ExportTlkFile(m_tlkFile, d2.GetPathName(), numbers);

		if(nUpdated < 0)
		{
			E = ::GetTickCount();
			cur.Restore();
			AfxMessageBox(L"Export Failed.. ");
		}
		else
		{
			cur.Restore();
			E = ::GetTickCount();

			CString msg;
			msg.Format(L"Extract & Exported [%d & %d] item(s) to \"%s\".. \r\n* Elapsed = [%.2f] seconds ",
				nExtracted,
				nUpdated,
				d2.GetPathName(),
				(E-S) == 0 ? 0.0 : (E-S)/1000.0
				 );
			AfxMessageBox(msg);
		}
		TRACE(L"Elapsed = [%f]\n", (E-S)/1000.0);
	}
	
}

void CNWN2TLKEditDlg::OnMnuExtractDiffDeleted()
{
	if( m_tlkFile.GetElementCount() == 0 )
	{
		AfxMessageBox(L"Current Talk Table is Empty. Execute after TLK file was loaded. ");
		return;
	}

	CMergeFileRule mergeRule;
	if( ! mergeRule.LoadRule(m_strRuleSetFileName) )
	{
		CString msg;
		msg.Format(L"Failed to Load RuleSet...\r\nPlease verify \"%s\" file. ", m_strRuleSetFileName);
		AfxMessageBox(msg);
		return;
	}

	CFileDialog d(TRUE, L"tlk", NULL, 0, L"Talk Table Files (*.tlk)|*.tlk|All Files (*.*)|*.*||");
	if( d.DoModal() != IDOK )
	{
		return;
	}

	CFileDialog d2(FALSE, L"txt", NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, L"Extrart StrRef List Text File (*.txt)|*.txt|All Files (*.*)|*.*||");
	if( d2.DoModal() == IDOK )
	{
		CUIntArray numbers;

		DWORD S = ::GetTickCount();
		DWORD E = S;

		CWaitCursor cur;
		m_tlkFile.CollectDiffStrRef(d.GetPathName(), NULL, NULL, &numbers);

		FILE *_of = _tfopen(d2.GetPathName(), L"wt");

		if( _of == NULL )
		{
			E = ::GetTickCount();
			cur.Restore();
			AfxMessageBox(L"Extract Failed.. ");
		}
		else
		{
			fprintf(_of, "Deleted StrRef List [%d] ...\n"
				"  From '%s'\n"
				"  To '%s'\n\n",
				numbers.GetCount(),
				(LPCSTR)CT2CA(d.GetPathName()),
				(LPCSTR)CT2CA(m_tlkFile.getFileName())
				);
				
			for(int i=0; i<numbers.GetCount(); i++)
			{
				fprintf(_of, "%u\n", numbers.GetAt(i));
			}
			fprintf(_of,"\n__ [%d] item(s) Extracted __\n", numbers.GetCount());
			fclose(_of);
		
			cur.Restore();
			E = ::GetTickCount();

			CString msg;
			msg.Format(L"Extracted [%d] item(s) to \"%s\".. \r\n* Elapsed = [%.2f] seconds ",
				numbers.GetCount(),
				d2.GetPathName(),
				(E-S) == 0 ? 0.0 : (E-S)/1000.0
				 );
			AfxMessageBox(msg);
		}
		TRACE(L"Elapsed = [%f]\n", (E-S)/1000.0);
	}
}

void CNWN2TLKEditDlg::OnMnuExtractDiffUpdated()
{
	if( m_tlkFile.GetElementCount() == 0 )
	{
		AfxMessageBox(L"Current Talk Table is Empty. Execute after TLK file was loaded. ");
		return;
	}

	CMergeFileRule mergeRule;
	if( ! mergeRule.LoadRule(m_strRuleSetFileName) )
	{
		CString msg;
		msg.Format(L"Failed to Load RuleSet...\r\nPlease verify \"%s\" file. ", m_strRuleSetFileName);
		AfxMessageBox(msg);
		return;
	}

	CFileDialog d(TRUE, L"tlk", NULL, 0, L"Talk Table Files (*.tlk)|*.tlk|All Files (*.*)|*.*||");
	if( d.DoModal() != IDOK )
	{
		return;
	}

	CFileDialog d2(FALSE, L"txt", NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, L"Export Text File (*.txt)|*.txt|All Files (*.*)|*.*||");
	if( d2.DoModal() == IDOK )
	{
		CNumbers numbers;

		DWORD S = ::GetTickCount();
		DWORD E = S;

		CWaitCursor cur;
		int nExtracted = m_tlkFile.CollectDiffStrRef(d.GetPathName(), NULL, &numbers, NULL);
		// 2007-01-14
		int nUpdated = ( nExtracted <= 0 ) ? 0 : mergeRule.ExportTlkFile(m_tlkFile, d2.GetPathName(), numbers);

		if(nUpdated < 0)
		{
			E = ::GetTickCount();
			cur.Restore();
			AfxMessageBox(L"Export Failed.. ");
		}
		else
		{
			cur.Restore();
			E = ::GetTickCount();

			CString msg;
			msg.Format(L"Extract & Exported [%d & %d] item(s) to \"%s\".. \r\n* Elapsed = [%.2f] seconds ",
				nExtracted,
				nUpdated,
				d2.GetPathName(),
				(E-S) == 0 ? 0.0 : (E-S)/1000.0
				 );
			AfxMessageBox(msg);
		}
		TRACE(L"Elapsed = [%f]\n", (E-S)/1000.0);
	}
}

void CNWN2TLKEditDlg::OnMnuFindText()
{
	if( m_pFindRepDlg )
	{
		m_pFindRepDlg->ShowWindow(SW_SHOW);
		m_pFindRepDlg->SetFocus();
	}
	else
	{
		m_pFindRepDlg = new CFindReplaceDialog();
		m_pFindRepDlg->Create( TRUE, L"", L"", FR_DOWN, this );
		m_pFindRepDlg->m_fr.lCustData = m_nCurrSelection;
		m_pFindRepDlg->ShowWindow(SW_SHOW);
	}
}

int CNWN2TLKEditDlg::strnistr(LPCTSTR string, LPCTSTR subString, int nLen)
{
	if ( *subString == _T('\0') )		// This is part of the _tcsstr definition
		return 0;

	int nStop=(int)_tcslen(string)-nLen;	// 2007-01-03'2th, rollback size_t -> int (size_t is unsigned)
	LPCTSTR p=string;

    while ( nStop >= 0 )
	{
		if ( _totupper(*p) == _totupper(*subString) )	// find the first matching character
	    {
		    if ( _tcsnicmp(p,subString,nLen) == 0 )
			return (int)(p-string);
	    }
		p++;
		nStop--;
	}
	return -1;
}

inline bool isWordDelim(TCHAR ch)
{
	return ((ch < 128) && !iswalnum(ch));
}
inline bool isWholeWord(const CString &rStr, int nStart, int nLen)
{
	return ( ((nStart+nLen)==rStr.GetLength()) || isWordDelim(rStr[nStart+nLen]) );
}

afx_msg LONG CNWN2TLKEditDlg::OnFindReplace(WPARAM wParam, LPARAM lParam)
{
	LPFINDREPLACE lpFindReplace = (LPFINDREPLACE) lParam;

	if( (lpFindReplace->Flags & FR_DIALOGTERM) )
	{
		// FR_DIALOGTERM  The dialog box is closing.
		//	After the owner window processes this message, a handle to the dialog box is no longer valid. 
		m_pFindRepDlg = NULL;

	}
	else if( (lpFindReplace->Flags & FR_FINDNEXT) )
	{
		// FR_FINDNEXT The user clicked the Find Next button in a Find or Replace dialog box.
		//	The lpstrFindWhat member specifies the string to search for.
		long nCurrentRow = (long) (lpFindReplace->lCustData);
		DWORD nFlags = lpFindReplace->Flags;
		bool bFound = false;
		int nLen = (int) _tcslen(lpFindReplace->lpstrFindWhat);
		CString rStr;

		if( nFlags & FR_DOWN )
		{
			DWORD nRow = (nCurrentRow < 0) ? 0 : nCurrentRow+1;
			int nPos = 0;
			for( ; nRow < m_tlkFile.GetElementCount(); nRow ++)
			{
				if( m_tlkFile.GetElement(nRow)->isValidText() && (m_tlkFile.GetElement(nRow)->GetText(rStr) > 0) )
				{
					if( nFlags&FR_MATCHCASE )
						nPos = rStr.Find(lpFindReplace->lpstrFindWhat);
					else
						nPos = strnistr(rStr, lpFindReplace->lpstrFindWhat, nLen);

					if( (nPos >= 0) && (!(nFlags&FR_WHOLEWORD) || isWholeWord(rStr, nPos, nLen)) )
					{
						SetSelection(nRow);
						lpFindReplace->lCustData = (long)nRow;
						bFound = true;
						break;
					}
				}
			}
		}
		else
		{
			DWORD nRow = (nCurrentRow < 0) ? -1 : nCurrentRow-1;
			int nPos = 0;
			for( ; (nRow <= 0x00ffffff) && (nRow >= 0); nRow -- )
			{
				if( m_tlkFile.GetElement(nRow)->isValidText() && (m_tlkFile.GetElement(nRow)->GetText(rStr) > 0) )
				{
					if( nFlags&FR_MATCHCASE )
						nPos = rStr.Find(lpFindReplace->lpstrFindWhat);
					else
						nPos = strnistr(rStr, lpFindReplace->lpstrFindWhat, nLen);

					if( (nPos >= 0) && (!(nFlags&FR_WHOLEWORD) || isWholeWord(rStr, nPos, nLen)) )
					{
						SetSelection(nRow);
						lpFindReplace->lCustData = (long)nRow;
						bFound = true;
						break;
					}
				}
			}
		}
		if( !bFound )
		{
			CString msg;
			msg.Format(L"Not found \"%s\" ", lpFindReplace->lpstrFindWhat);
			AfxMessageBox(msg, MB_OK | MB_ICONINFORMATION);
		}
	}
	else // Not used
	{
		// FR_REPLACE The user clicked the Replace button in a Replace dialog box.
		//	The lpstrFindWhat member specifies the string to replace and the lpstrReplaceWith member specifies the replacement string. 
		// FR_REPLACEALL  The user clicked the Replace All button in a Replace dialog box.
		//	The lpstrFindWhat member specifies the string to replace and the lpstrReplaceWith member specifies the replacement string. 
	}
	return 0;
}
