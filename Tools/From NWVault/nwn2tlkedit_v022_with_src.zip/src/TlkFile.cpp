#include "StdAfx.h"
#include "TlkFile.h"

namespace TLK30 {

UINT TLK_CODE_PAGE	= CP_UTF8;

void CNumbers::SetListFile(LPCTSTR lpszListFileName)
{
	FILE *f = _tfopen(lpszListFileName, L"rt");
	if( f == NULL )
		return;

	m_nType |= HASHED;

	char *pCh;
	char buf[1024];
	UINT nNum;
	while( fgets(buf, 1024, f) )
	{
		TrimRight(buf);
		if( ! *buf )
			continue;

		nNum = strtoul(buf, &pCh, 10);
		if( *pCh )
			continue;

		this->SetSelValue(nNum);
	}
	fclose(f);
}


#define _MIN(_a,_b) ((_a)>(_b)?(_b):(_a))

static TCHAR TmpStr1[128];
static TCHAR TmpStr2[128];

bool CTlkElement::CompareSummary( const CTlkElement *element, CString &rResult )
{
	bool bSame = true;
	rResult.Empty();
	if( this->isTextPresent() != element->isTextPresent() )
	{
		rResult.AppendFormat(L"Text Presence : %d -> %d",
			this->isTextPresent(), element->isTextPresent());
		bSame = false;
	}
	else if (this->isTextPresent() && element->isTextPresent())
	{
		if( this->DataStringSize() != element->DataStringSize() )
		{
			if(! bSame )
				rResult += L", ";
			rResult.AppendFormat(L"String Size : %u -> %u",
				this->DataStringSize(), element->DataStringSize());
			bSame = false;
		}
		else
		{
			if( memcmp(this->lpszString, element->lpszString, DataStringSize()) != 0 )
			{
				if(! bSame )
					rResult += L", ";

				toUTF32(lpszString, _MIN(32,DataStringSize()), TmpStr1, TLK_CODE_PAGE);
				toUTF32(element->lpszString, _MIN(32,DataStringSize()), TmpStr2, TLK_CODE_PAGE);

				rResult.AppendFormat(L"String Data : (%s.. -> %s..)",
					TmpStr1, TmpStr2);
				bSame = false;
			}
		}
	}

	if( this->isSndPresent() != element->isSndPresent() )
	{
		if(! bSame )
			rResult += L", ";
		rResult.AppendFormat(L"Snd Presence : %d -> %d",
			this->isSndPresent(), element->isSndPresent());
		bSame = false;
	}
	else if( this->isSndPresent() && element->isSndPresent() )
	{
		if( memcmp(this->DataSoundRef(), element->DataSoundRef(), 16) != 0 )
		{
			if(! bSame )
				rResult += L", ";

			toUTF32(DataSoundRef(), 16, TmpStr1, CP_ACP);
			toUTF32(element->DataSoundRef(), 16, TmpStr2, CP_ACP);

			rResult.AppendFormat(L"Snd ResRef : %s -> %s",
				TmpStr1, TmpStr2);
			bSame = false;
		}
		if( this->DataVolumeVariance() != element->DataVolumeVariance() )
		{
			if(! bSame )
				rResult += L", ";
			rResult.AppendFormat(L"Snd Volume : %u -> %u",
				DataVolumeVariance(), DataVolumeVariance() );
			bSame = false;
		}
		if( this->DataPitchVariance() != element->DataPitchVariance() )
		{
			if(! bSame )
				rResult += L", ";
			rResult.AppendFormat(L"Snd Pitch : %u -> %u",
				DataPitchVariance(), DataPitchVariance() );
			bSame = false;
		}
		if( this->isSndLengthPresent() != element->isSndLengthPresent() )
		{
			if(! bSame )
				rResult += L", ";
			rResult.AppendFormat(L"Snd Length Presence : %d -> %d",
				this->isSndLengthPresent(), element->isSndLengthPresent());
			bSame = false;
		}
	}
	return bSame;
}


CTlkFile::~CTlkFile(void)
{
	if(pDataTable)
	{
		for(DWORD i=0; i<m_pTlkHeader->StringCount; i++)
		{
			if( pDataTable[i] )
				delete pDataTable[i];
		}
		free(pDataTable);
	}
	delete m_pTlkHeader;	// 2007-01-14
}


bool CTlkFile::InitFile(DWORD nInitSize)
{
	m_bModified = false;
	nValidStringCount = 0;
	nMaxString = 0;

	// destroy previous table
	if( pDataTable )
	{
		for(DWORD i=0; i<m_pTlkHeader->StringCount; i++)
		{
			if( pDataTable[i] )
			{
				delete pDataTable[i];
				pDataTable[i] = NULL;
			}
		}
		m_pTlkHeader->StringCount = 0;
	}

	// allocation Table
	m_pTlkHeader->StringCount = nInitSize;
	size_t nTblLen = sizeof(CTlkElement *) * m_pTlkHeader->StringCount;
	if( nInitSize == 0 )
	{
		if( pDataTable )
		{
			free(pDataTable);
			pDataTable = NULL;
		}
	}
	else
	{
		pDataTable = (CTlkElement **) realloc(pDataTable, nTblLen);
		memset(pDataTable, 0, nTblLen);
	}

	// init Elements
	if( m_pTlkHeader->getVersion() == TLK_VER_10 )
	{
		for(DWORD i = 0; i<m_pTlkHeader->StringCount; i++)
		{
			pDataTable[i] = new CTlk10Element();
		}
	}
	else
	{
		for(DWORD i = 0; i<m_pTlkHeader->StringCount; i++)
		{
			pDataTable[i] = new CTlk30Element();
		}
	}

	m_strTlkFileName.Empty();	// added 2007-01-03
	return true;
}

// 1. File Open
// 2. Load Header & Validation
// 3. Allocation Table
// 4. Load Element
// 5. Load Strings
//
bool CTlkFile::LoadFile(LPCTSTR lpszFileName)
{
	// 1. File Open
	FILE *f = _tfopen(lpszFileName, L"rb");
	if( f == NULL )
		return false;

	m_bModified = false;
	nValidStringCount = 0;
	nMaxString = 0;

	m_strTlkFileName.Empty();	// 2007-01-14

	// 2. Load Header & Validation

	if( pDataTable )
	{
		for(DWORD i=0; i<m_pTlkHeader->StringCount; i++)
		{
			if( pDataTable[i] )
			{
				delete pDataTable[i];
				pDataTable[i] = NULL;
			}
		}
		m_pTlkHeader->StringCount = 0;
	}

	char buf[32768];
	if( fread(buf, 1, m_pTlkHeader->getHeaderSize(), f) != m_pTlkHeader->getHeaderSize() )
		goto ERROR_LOAD;

	if( ! m_pTlkHeader->LoadStream(buf) )
		goto ERROR_LOAD;

	// 3. Allocation Table
	size_t nTblLen = sizeof(CTlkElement *) * m_pTlkHeader->StringCount;
	pDataTable = (CTlkElement **) realloc(pDataTable, nTblLen);
	memset(pDataTable, 0, nTblLen);

	// 4. Load Element
	if( m_pTlkHeader->getVersion() == TLK_VER_10 )
	{
		for(DWORD i = 0; i<m_pTlkHeader->StringCount; i++)
		{
			pDataTable[i] = new CTlk10Element();
			if( fread(buf, 1, m_pTlkHeader->getElementSize(), f) != m_pTlkHeader->getElementSize() )
				goto ERROR_LOAD;
			pDataTable[i]->LoadElement(buf);
		}
	}
	else
	{
		for(DWORD i = 0; i<m_pTlkHeader->StringCount; i++)
		{
			pDataTable[i] = new CTlk30Element();
			if( fread(buf, 1, m_pTlkHeader->getElementSize(), f) != m_pTlkHeader->getElementSize() )
				goto ERROR_LOAD;
			pDataTable[i]->LoadElement(buf);
		}
	}

	// 2007-01-14,
	// buggy tlk file - tail elements has invalid string size
	// moved from 'for loop end'
	m_strTlkFileName = lpszFileName;

	// 5. Load Strings
	for(DWORD i = 0; i<m_pTlkHeader->StringCount; i++)
	{
		if( pDataTable[i] && pDataTable[i]->isTextPresent() )
		{
			
			if( pDataTable[i]->DataStringSize() == 0 )
			{
				/* TRACE(_T("%08u. (%05u) [%04u]\n"),
					i, nMaxString,
					pDataTable[i]->DataStringSize()
					); */
				continue;

			}

			if( fseek(f, (long)(m_pTlkHeader->StringEntriesOffset + pDataTable[i]->DataOffsetToString()), SEEK_SET) != 0 )
			{
				goto SKIP_LOAD;
			}
			
			nValidStringCount ++;

			if( nMaxString < pDataTable[i]->DataStringSize() )
			{
				nMaxString = pDataTable[i]->DataStringSize();
			}

			if( fread(buf, 1, pDataTable[i]->DataStringSize(), f) != pDataTable[i]->DataStringSize() )
			{
				goto SKIP_LOAD;
			}

#ifdef	_DEBUG
			buf[pDataTable[i]->DataStringSize()] = 0;
			if( i == 57859 || i == 84934 || i == 34017 )
			{
				int n = i;
				TRACE("%d", n);
			}
			char * p;
			if( (p=strstr(buf, "\r")) )
			{
				if( ! strstr(buf, "\n") )
				{
					int n = i;
					TRACE("!!!! %d NL not FOUND\n", n);
				}
				else
				{
					do
					{
						p++;
						if( *p != '\n' )
						{
							int n = i;
							TRACE("---> %d NL not FOUND\n", n);
						}
					} while ( (p = strstr(p, "\r")) );
				}
			}
#endif
			if( pDataTable[i]->LoadStrData(buf) <= 0 )
			{
				goto SKIP_LOAD;
			}

#ifdef _DEBUG1
			CString r;
			int nLen = pDataTable[i]->GetText(r);
			if( nLen <= 0 )
			{
				TRACE(_T("\n!! UTF8 Conversion Error...!!\n"));
			}
			TRACE(_T("%08u. (%05u) [%04u/%04d] %s\n"),
				i, nMaxString,
				pDataTable[i]->DataStringSize(),
				nLen,
				r.GetString()
				);
#endif
		}
	}

SKIP_LOAD:

	fclose(f);
	return true;

ERROR_LOAD:
	fclose(f);
	return false;
}


// 1. Table Fix Offset
// 2. Header Fix Offset
// 3. File Open
// 4. Write Header
// 5. Write Elements
// 6. Write Strings
//
bool CTlkFile::SaveAsFile(LPCTSTR lpszFileName)
{
	// 1. Table Fix Offset
	m_pTlkHeader->StringEntriesOffset = m_pTlkHeader->getHeaderSize() + m_pTlkHeader->getElementSize() * m_pTlkHeader->StringCount;

	// 2. Header Fix Offset
	DWORD nOffset = 0;
	for(DWORD i = 0; i<m_pTlkHeader->StringCount; i++)
	{
		if( pDataTable[i] )
		{
			pDataTable[i]->_FixOffset(nOffset);
		}
	}
	
	// 3. File Open
	FILE *f = _tfopen(lpszFileName, L"wb");
	if( f == NULL )
		return false;

	// 4. Write Header
	char buf[32768];
	m_pTlkHeader->MakeStream(buf);
	fwrite(buf, m_pTlkHeader->getHeaderSize(), 1, f);

	int nPos = 0;
	// 5. Write Elements
	for(DWORD i = 0; i<m_pTlkHeader->StringCount; i++)
	{
		pDataTable[i]->MakeStream(buf+nPos);
		nPos += m_pTlkHeader->getElementSize();
		if( nPos >= 8192 )
		{
			fwrite(buf, 1, nPos, f);
			nPos = 0;
		}
	}
	if( nPos > 0 )
	{
		fwrite(buf, 1, nPos, f);
	}

	// 6. Write Strings
	//
	for(DWORD i = 0; i<m_pTlkHeader->StringCount; i++)
	{
		if( pDataTable[i]->isTextPresent() && (pDataTable[i]->DataStringSize() > 0) )
		{
			fwrite(pDataTable[i]->GetStrData(), 1, pDataTable[i]->DataStringSize(), f);
		}
	}

	fclose(f);

	m_bModified = false;

	if( m_strTlkFileName.Compare( lpszFileName ) != 0 )	// added 2007-01-03
		m_strTlkFileName = lpszFileName;

	return true;
}

CString CTlkFile::GetSummary()
{
	CString rResult;

	rResult.Format(L"File Name = [%s]\n\n", m_strTlkFileName);

	rResult.AppendFormat( L"* Header Infomation\n\n"
		L"FileType       = [TLK]\n"
		L"FileVersion    = [%s]\n"
		L"Language       = [%s]\n"
		L"String Count   = [%u]\n"
		L"Entries Offset = [%u]\n",
		m_pTlkHeader->getVersion() == TLK_VER_10 ? L"V1  " : L"V3.0",	// 2007-01-14
		m_pTlkHeader->getLanguageString(),
		m_pTlkHeader->StringCount,
		m_pTlkHeader->StringEntriesOffset
		);

	if( this->GetElementCount() == 0 )	// Not loaded TLK File
	{
		rResult.AppendFormat( L"\nTalk Table is Empty.\n");
	}
	else
	{
		DWORD nTotal = GetElementCount();
		DWORD nStrPresent = 0;
		DWORD nSndPresent = 0;
		DWORD nStrEmpty   = 0;
		DWORD nStrNPresent= 0;
		DWORD nStrMaxLen  = 0;
		double nStrAvgLen  = 0.0;
		for(DWORD i = 0; i < nTotal; i++)
		{
			if( pDataTable[i]->isTextPresent() )
			{
				nStrPresent ++;
				if( pDataTable[i]->DataStringSize() != 0 )
				{
					if( nStrMaxLen < pDataTable[i]->DataStringSize() )
					{
						nStrMaxLen = pDataTable[i]->DataStringSize();
					}
					nStrAvgLen = (nStrAvgLen + pDataTable[i]->DataStringSize()) / 2.0;
				}
				else
					nStrEmpty ++;
			}
			else
				nStrNPresent ++;
			if( pDataTable[i]->isSndPresent() )
				nSndPresent ++;
		}
		rResult.AppendFormat( L"\n"
			L"* Talk Table Elements Infomation\n\n"
			L"Total Element         = [%u]\n"
			L"String Present        = [%u]\n"
			L"Sound Present         = [%u]\n"
			L"String Empty          = [%u]\n"
			L"String Not Present    = [%u]\n"
			L"Table Usages          = [%u/%u], [%02.1f%%]\n"
			L"\n"
			L"String Max Length     = [%u] Bytes\n"
			L"String Average Length = [%.2f] Bytes\n",
			nTotal,
			nStrPresent,
			nSndPresent,
			nStrEmpty,
			nStrNPresent,
			(nStrPresent - nStrEmpty),
			nTotal,
			(nStrPresent - nStrEmpty) == 0 ? 0.0 : (nStrPresent - nStrEmpty) * 100.0 / nTotal,
			nStrMaxLen,
			nStrAvgLen
			);
	}
	return rResult;
}


inline void ouputToMbcs(FILE *f, const wchar_t *buf, int nLen)
{
	static char cbuf[8192];
	if( nLen > 0 )
	{
		if( toMBCS(buf, nLen, cbuf)  > 0 )
		{
			fputs(cbuf, f);
		}
	}
}

void CTlkFile::GenerateSummary(CString &strFileName)
{
	TCHAR *m_lpszOutput = strFileName.GetBuffer(512);
	GetTempPath(512, m_lpszOutput);
	_tcscat(m_lpszOutput, L"_TLK_TMP.TXT");
	FILE * _of = _tfopen( m_lpszOutput, L"wt" );
	strFileName.ReleaseBuffer();
	if( _of == NULL )
		return;

	CString rResult = this->GetSummary();
	ouputToMbcs(_of, rResult.GetString(), rResult.GetLength());
	fclose(_of);
}


int CTlkFile::CompareTlkFile(LPCTSTR lpszTlkFileName, CString &rResult)
{
	TCHAR *lpszOutput = rResult.GetBuffer(512);
	GetTempPath(512, lpszOutput);
	_tcscat(lpszOutput, L"_TLK_TMP.TXT");
	FILE * _of = _tfopen( lpszOutput, L"wt" );	//	2006-01-08 wb -> wt
	rResult.ReleaseBuffer();
	if( _of == NULL )
		return -1;

	wchar_t _obuf[4096];

	DWORD StartTick = ::GetTickCount();

	//fwprintf(_of, L"* Compare Two TLK Files...\r\n\r\n");
	ouputToMbcs(_of, _obuf, swprintf(_obuf, L"* Compare Two TLK Files...\n\n"));
	ouputToMbcs(_of, _obuf, swprintf(_obuf, L"Master TLK FileName = [%ls]\n", m_strTlkFileName));
	ouputToMbcs(_of, _obuf, swprintf(_obuf, L"Second TLK FileName = [%ls]\n\n", lpszTlkFileName));


	CTlkFile tlkOther;
	tlkOther.SetVersion( this->GetTlkHeader()->getVersion() );	// 2007-01-14
	if( ! tlkOther.LoadFile(lpszTlkFileName) )
	{
		ouputToMbcs(_of, _obuf, swprintf(_obuf, L"* Second TLK File Loading Failed...\n"));
		fclose(_of);
		return -1;
	}

	CString rSum = this->GetSummary();
	rSum.Replace(L"\r\n", L"\n");
	//rSum.Replace(L"\n", L"\r\n");

	ouputToMbcs(_of, _obuf, swprintf(_obuf, L"* Master TLK File Summary\n"
		L"------------------------------------------------------------\n"
		L"%ls"
		L"------------------------------------------------------------\n",
		rSum
		));
	rSum = tlkOther.GetSummary();
	rSum.Replace(L"\r\n", L"\n");
	//rSum.Replace(L"\n", L"\r\n");
	ouputToMbcs(_of, _obuf, swprintf(_obuf, L"* Second TLK File Summary\n"
		L"------------------------------------------------------------\n"
		L"%ls"
		L"------------------------------------------------------------\n",
		rSum
		));

	ouputToMbcs(_of, _obuf, swprintf(_obuf, L"* Header Difference\n"
		L"------------------------------------------------------------\n"
		));
	int nFoundTotal = 0;
	int nFound = 0;
	if( m_pTlkHeader->getLanguageId() != tlkOther.GetTlkHeader()->getLanguageId() )
	{
		ouputToMbcs(_of, _obuf, swprintf(_obuf, L"<> Language : %ls (%u) -> %ls (%u)\n",
			m_pTlkHeader->getLanguageString(),
			m_pTlkHeader->getLanguageId(),
			tlkOther.GetTlkHeader()->getLanguageString(),
			tlkOther.GetTlkHeader()->getLanguageId()
			));
		nFound ++;
	}
	if( m_pTlkHeader->StringCount != tlkOther.GetTlkHeader()->StringCount )
	{
		ouputToMbcs(_of, _obuf, swprintf(_obuf, L"<> String Count : %u -> %u\n",
			m_pTlkHeader->StringCount,
			tlkOther.GetTlkHeader()->StringCount
			));
		nFound ++;
	}
	if( m_pTlkHeader->StringEntriesOffset != tlkOther.GetTlkHeader()->StringEntriesOffset )
	{
		ouputToMbcs(_of, _obuf, swprintf(_obuf, L"<> String Entries Offset : %u -> %u\n",
			m_pTlkHeader->StringEntriesOffset,
			tlkOther.GetTlkHeader()->StringEntriesOffset
			));
		nFound ++;
	}
	if( nFound == 0 )
	{
		ouputToMbcs(_of, _obuf, swprintf(_obuf, L"Same Header Values!\n"));
	}
	ouputToMbcs(_of, _obuf, swprintf(_obuf,
		L"------------------------------------------------------------\n"));

	nFoundTotal += nFound;
	nFound = 0;


	ouputToMbcs(_of, _obuf, swprintf(_obuf, L"* Elements Difference\n"
		L"------------------------------------------------------------\n"
		));
	DWORD nStrRef = 0;
	CString rDiff;
	for( ; (nStrRef < this->GetElementCount()) && (nStrRef < tlkOther.GetElementCount()); nStrRef++)
	{
		if( ! GetElement(nStrRef)->CompareSummary(tlkOther.GetElement(nStrRef), rDiff) )
		{
			/*fwprintf(_of, L"#%u := %ls\r\n",
				nStrRef,
				rDiff);*/
			/*fwprintf(_of, L"#%u := ", nStrRef);
			fwrite(rDiff.GetString(), sizeof(wchar_t), rDiff.GetLength(), _of);
			fwprintf(_of, L"\r\n");*/
			ouputToMbcs(_of, _obuf, swprintf(_obuf, L"#%u := ", nStrRef));
			ouputToMbcs(_of, rDiff.GetString(), rDiff.GetLength());
			ouputToMbcs(_of, L"\n", 1);
			nFound ++;
		}
	}
	if( nStrRef < this->GetElementCount() )
	{
		ouputToMbcs(_of, _obuf, swprintf(_obuf, L"\n<> Master's Elements exceeds than Second : [%d] = [%u ~ %u]\n",
			GetElementCount() - nStrRef,
			nStrRef,
			GetElementCount() - 1
			));
		nFound ++;
	}
	else if( nStrRef < tlkOther.GetElementCount() )
	{
		ouputToMbcs(_of, _obuf, swprintf(_obuf, L"\n<> Second Elements exceeds than Master's : [%d] = [%u ~ %u]\n",
			tlkOther.GetElementCount() - nStrRef,
			nStrRef,
			tlkOther.GetElementCount() - 1
			));
		nFound ++;
	}

	if( nFound == 0 )
	{
		ouputToMbcs(_of, _obuf, swprintf(_obuf, L"\nSame Elements!\n"));
	}
	ouputToMbcs(_of, _obuf, swprintf(_obuf,
		L"------------------------------------------------------------\n"));
	nFoundTotal += nFound;

	if( nFoundTotal == 0 )
	{
		ouputToMbcs(_of, _obuf, swprintf(_obuf, L"* Two TLK File is Same !\n\n"));
	}
	else
	{
		ouputToMbcs(_of, _obuf, swprintf(_obuf, L"* Two TLK File is different, Different Count = [%d]\n\n", nFoundTotal));
	}

	DWORD EndTick = ::GetTickCount();

	ouputToMbcs(_of, _obuf, swprintf(_obuf, L"___ END ___ [Elapsed = %.2f Seconds]\n",
		(EndTick-StartTick) == 0 ? 0.0 : (EndTick-StartTick) / 1000.0 ));


	fclose(_of);
	return nFoundTotal;
}


// Collect Multi Bytes Character (Ko,Ja,Ch ...) StrRefs
int CTlkFile::CollectMultiBytesCharStrRef(CNumbers &Numbers)
{
	int nFound = 0;
	DWORD nStrRef = 0;
	CString rString;
	int nChars = 0;
	TCHAR buf[32768];
	for( ; nStrRef < this->GetElementCount(); nStrRef++)
	{
		if( GetElement(nStrRef)->isValidText() )
		{
			nChars = toUTF32(GetElement(nStrRef)->GetStrData(), GetElement(nStrRef)->DataStringSize(), buf, TLK_CODE_PAGE);
			if( (nChars > 0) && ((DWORD)nChars < GetElement(nStrRef)->DataStringSize()) )
			{
				Numbers.SetSelValue(nStrRef);
				nFound ++;
			}
		}
	}
	return nFound;
}

// Different StrRefs
int CTlkFile::CollectDiffStrRef(LPCTSTR lpszTlkFileName,
								CNumbers *Numbers1,	// Numbers1 new
								CNumbers *Numbers2,	// Numbers2 updated
								CUIntArray *Deleted	// Numbers3 deleted
								)
{
	CTlkFile tlkOther;
	tlkOther.SetVersion( this->GetTlkHeader()->getVersion() );	// 2007-01-14
	if( ! tlkOther.LoadFile(lpszTlkFileName) )
	{
		return -1;
	}

	int nFound = 0;
	DWORD nStrRef = 0;
	CString rDiff;
	CTlkElement *pE1, *pE2;
	for( ; (nStrRef < this->GetElementCount()) && (nStrRef < tlkOther.GetElementCount()); nStrRef++)
	{
		pE1 = GetElement(nStrRef);
		pE2 = tlkOther.GetElement(nStrRef);

		if( Numbers1 && pE1->isTextPresent() && ! pE2->isTextPresent() )
		{
			nFound ++;
			Numbers1->SetSelValue(nStrRef);
		}
		else if( Deleted && ! pE1->isTextPresent() && pE2->isValidText() )
		{
			nFound ++;
			Deleted->Add(nStrRef);
		}
		else if( Numbers2 && pE1->isTextPresent() && pE2->isTextPresent() )
		{
			if( (pE1->DataStringSize() != pE2->DataStringSize()) ||
				(memcmp(pE1->GetStrData(), pE2->GetStrData(), pE1->DataStringSize()) != 0) )
			{
				nFound ++;
				Numbers2->SetSelValue(nStrRef);
			}
		}
	}
	if( Numbers1 && (nStrRef < this->GetElementCount()) )
	{
		for( ; nStrRef < this->GetElementCount(); nStrRef ++)
		{
			if( GetElement(nStrRef)->isTextPresent() )
			{
				nFound ++;
				Numbers1->SetSelValue(nStrRef);
			}
		}
	}
	else if( Deleted && (nStrRef < tlkOther.GetElementCount()) )
	{
		for( ; nStrRef < tlkOther.GetElementCount(); nStrRef ++)
		{
			if( tlkOther.GetElement(nStrRef)->isTextPresent() )
			{
				nFound ++;
				Deleted->Add(nStrRef);
			}
		}
	}
	return nFound;
}

//--------------------------------------------------------------------------------------
//

// unicode => utf8
int toUTF8(LPCWSTR lpszIn, int nInBuf, char **pBuf, UINT nCodePage/* = CP_UTF8*/)
{
	int nOutLen = 0;
    if( nInBuf > 0 )
    {
		nOutLen = WideCharToMultiByte(nCodePage, 0, lpszIn, nInBuf, NULL, 0, NULL, FALSE);
		if(nOutLen > 0)
		{
			*pBuf = (char *)realloc(*pBuf, nOutLen);
			WideCharToMultiByte(nCodePage, 0, lpszIn, nInBuf, *pBuf, nOutLen, NULL, FALSE);
		}
    }
    return nOutLen;
}

int toMBCS(LPCWSTR lpszIn, int nInBuf, char *pBuf)
{
	int nOutLen = 0;
    if( nInBuf > 0 )
    {
		nOutLen = WideCharToMultiByte(CP_ACP, 0, lpszIn, nInBuf, NULL, 0, NULL, FALSE);
		if(nOutLen > 0)
		{
			WideCharToMultiByte(CP_ACP, 0, lpszIn, nInBuf, pBuf, nOutLen, NULL, FALSE);
			pBuf[nOutLen] = 0;
		}
    }
    return nOutLen;
}

// utf8 => unicode
int toUTF32(LPCSTR lpszIn, int nInBuf, CString &strOut, UINT nCodePage)
{
	int nOutLen = 0;
	if( (nOutLen = MultiByteToWideChar(nCodePage, 0, lpszIn, nInBuf, NULL, 0)) > 0 )
    {
		MultiByteToWideChar(nCodePage, 0, lpszIn, nInBuf, strOut.GetBufferSetLength( nOutLen ), nOutLen);
	}
	return nOutLen;
}

int toUTF32(LPCSTR lpszIn, int nInBuf, wchar_t *szOut, UINT nCodePage)
{
	int nOutLen = 0;
	if( (nOutLen = MultiByteToWideChar(nCodePage, 0, lpszIn, nInBuf, NULL, 0)) > 0 )
    {
		MultiByteToWideChar(nCodePage, 0, lpszIn, nInBuf, szOut, nOutLen);
		szOut[nOutLen] = 0;
	}
	return nOutLen;
}

int ExtractDirectory(LPCTSTR lpszFilePath, CString &strOut)
{
	int nPos = (int)_tcslen(lpszFilePath) - 1;
	for(; (nPos >= 0) && (lpszFilePath[nPos] != _T('\\')) && (lpszFilePath[nPos] != _T('/')); -- nPos)
		;

	if( nPos < 0 )
	{
		strOut = _T(".\\");
	}
	else
	{
		++nPos;
		_tcsncpy(strOut.GetBufferSetLength((int)nPos), lpszFilePath, nPos);
	}
	return strOut.GetLength();
}

bool FileExists(LPCTSTR szFilePath)
{
	DWORD nAttr = GetFileAttributes(szFilePath);
	if( nAttr == 0xFFFFFFFF )
		return false;
	else if( !(nAttr & FILE_ATTRIBUTE_DIRECTORY) )
		return true;
	else
		return false;
}



void TrimCRLF(char *buf)
{
	size_t nLen = strlen(buf);
	if( nLen <= 0 ) return;
	char *tail = buf + nLen - 1;
	while( (*tail == '\r') || (*tail == '\n') ) -- tail;
	*(tail+1) = '\0';
}

void TrimRight(char *buf)
{
	size_t nLen = strlen(buf);
	if( nLen <= 0 ) return;
	char *tail = buf + nLen - 1;
	while( (*tail == ' ') || (*tail == '\t') || (*tail == '\r') || (*tail == '\n') ) -- tail;
	*(tail+1) = '\0';
}

void TrimCRLF(wchar_t *buf)
{
	size_t nLen = wcslen(buf);
	if( nLen <= 0 ) return;
	wchar_t *tail = buf + nLen - 1;
	while( (*tail == L'\r') || (*tail == L'\n') ) -- tail;
	*(tail+1) = L'\0';
}


}	// namespace TLK30