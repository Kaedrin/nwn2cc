using System;
using System.IO;
using System.Collections;
using System.Text;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using OEIShared;
using OEIShared.Utils;

namespace TaniTerrain
{
    // structs
    struct TaniPacketKey
    {
        public FourCC Type;
        public int Offset;
    }
    struct TaniColor
    {
        public byte X;
        public byte R;
        public byte G;
        public byte B;

        public void Read(BinaryReader cReader)
        {
            X = cReader.ReadByte();
            R = cReader.ReadByte();
            G = cReader.ReadByte();
            B = cReader.ReadByte();
        }
        public void Write(BinaryWriter cWriter)
        {
            cWriter.Write(X);
            cWriter.Write(R);
            cWriter.Write(G);
            cWriter.Write(B);
        }
    }
    struct TaniVertex
    {
        public float posX;
        public float posY;
        public float posZ;
        public float normX;
        public float normY;
        public float normZ;
        public TaniColor rgbx;
        public float data07;
        public float data08;
        public float data09;
        public float data10;
        public void Load(BinaryReader cReader)
        {
            posX = cReader.ReadSingle(); 
            posY = cReader.ReadSingle();
            posZ = cReader.ReadSingle();
            normX = cReader.ReadSingle();
            normY = cReader.ReadSingle();
            normZ = cReader.ReadSingle();
            rgbx.Read(cReader);
            data07 = cReader.ReadSingle();
            data08 = cReader.ReadSingle();
            data09 = cReader.ReadSingle();
            data10 = cReader.ReadSingle();
        }
        public void Save(BinaryWriter cWriter)
        {
            cWriter.Write(posX); 
            cWriter.Write(posY);
            cWriter.Write(posZ);
            cWriter.Write(normX);
            cWriter.Write(normY);
            cWriter.Write(normZ);
            rgbx.Write(cWriter);
            cWriter.Write(data07);
            cWriter.Write(data08);
            cWriter.Write(data09);
            cWriter.Write(data10);
        }
        public void From(TaniVertex Source, bool CopyXY, bool CopyZ, bool CopyNormal, bool CopyTint, bool CopyUnknown)
        {
            if (CopyXY)
            {
                posX = Source.posX;
                posY = Source.posY;
            }
            if (CopyZ)
                posZ = Source.posZ;
            if (CopyNormal)
            {
                normX = Source.normX;
                normY = Source.normY;
                normZ = Source.normZ;
            }
            if (CopyTint )
                rgbx = Source.rgbx;
            if (CopyUnknown )
            {
                data07 = Source.data07;
                data08 = Source.data08;
                data09 = Source.data09;
                data10 = Source.data10;
            }
        }
    }
    struct TaniWatrVertex
    {
        public float posX;
        public float posY;
        public float posZ;
        public float data3;
        public float data4;
        public float data5;
        public float data6;
        public void Load(BinaryReader cReader)
        {
            posX = cReader.ReadSingle();
            posY = cReader.ReadSingle();
            posZ = cReader.ReadSingle();
            data3 = cReader.ReadSingle();
            data4 = cReader.ReadSingle();
            data5 = cReader.ReadSingle();
            data6 = cReader.ReadSingle();
        }
        public void Save(BinaryWriter cWriter)
        {
            cWriter.Write(posX);
            cWriter.Write(posY);
            cWriter.Write(posZ);
            cWriter.Write(data3);
            cWriter.Write(data4);
            cWriter.Write(data5);
            cWriter.Write(data6);
        }
        public void From(TaniWatrVertex Source, bool CopyXY, bool CopyZ, bool CopyUnknown)
        {
            if (CopyXY)
            {
                posX = Source.posX;
                posY = Source.posY;
            }
            if (CopyZ)
                posZ = Source.posZ;
            if (CopyUnknown)
            {
                data3 = Source.data3;
                data4 = Source.data4;
                data5 = Source.data5;
                data6 = Source.data6;
            }
        }
    }
    struct TaniTriangle
    {
        public ushort A;
        public ushort B;
        public ushort C;
        public void Load(BinaryReader cReader)
        {
            A = cReader.ReadUInt16 ();
            B = cReader.ReadUInt16();
            C = cReader.ReadUInt16();
        }
        public void Save(BinaryWriter cWriter)
        {
            cWriter.Write(A);
            cWriter.Write(B);
            cWriter.Write(C);
        }
    }
    // helper classes
    class TaniBlade
    {
        public float posx, posy, posz;
        public float dirx, diry, dirz;
        public float dimx, dimy, dimz;
        public void Load(BinaryReader bReader)
        {
            posx = bReader.ReadSingle();
            posy = bReader.ReadSingle();
            posz = bReader.ReadSingle();
            dirx = bReader.ReadSingle();
            diry = bReader.ReadSingle();
            dirz = bReader.ReadSingle();
            dimx = bReader.ReadSingle();
            dimy = bReader.ReadSingle();
            dimz = bReader.ReadSingle();
        }
        public void Save(BinaryWriter bWriter)
        {
            bWriter.Write(posx);
            bWriter.Write(posy);
            bWriter.Write(posz);
            bWriter.Write(dirx);
            bWriter.Write(diry);
            bWriter.Write(dirz);
            bWriter.Write(dimx);
            bWriter.Write(dimy);
            bWriter.Write(dimz);
        }
    }
    class TaniGras
    {
        public string GrasName;
        public string TextureName;
        private int m_x, m_y;
        public Int32 BladeCount { get { return Blade.Count; } }
        public List<TaniBlade> Blade = new List<TaniBlade>();
        public TaniGras(int coordinateX, int coordinateY)
        {
            m_x = coordinateX;
            m_y = coordinateY;
        }
        public void Load(BinaryReader cReader)
        {
            GrasName = CommonUtils.ConvertZeroTerminatedBytesToString(cReader.ReadBytes(32)).TrimEnd(new char[1]);
            TextureName = CommonUtils.ConvertZeroTerminatedBytesToString(cReader.ReadBytes(32)).TrimEnd(new char[1]);
            int m_count = cReader.ReadInt32();
            if (m_count > 0)
                for (int n = 0; n < m_count; n++)
                {
                    TaniBlade b = new TaniBlade();
                    b.Load(cReader);
                    Blade.Add(b);
                }
            else Blade = null;
        }
        public void Save(BinaryWriter cWriter)
        {
            cWriter.Write(CommonUtils.ConvertStringToBytes(GrasName.PadRight(32, '\0')));
            cWriter.Write(CommonUtils.ConvertStringToBytes(TextureName.PadRight(32, '\0')));
            cWriter.Write(Blade.Count);
            foreach (TaniBlade b in Blade)
                b.Save(cWriter);
        }
        public int Size { get { return 68 + 36 * Blade.Count; } }
        public void From(TaniGras Source)
        {
            GrasName = Source.GrasName;
            TextureName = Source.TextureName;
            float dx = (this.m_x - Source.m_x) * 40f;
            float dy = (this.m_y - Source.m_y) * 40f;
            foreach (TaniBlade b in Source.Blade)
            {
                TaniBlade nb = new TaniBlade();
                nb.posx = b.posx+dx;
                nb.posy = b.posy+dy;
                nb.posz = b.posz;
                nb.dirx = b.dirx;
                nb.diry = b.diry;
                nb.dirz = b.dirz;
                nb.dimx = b.dimx;
                nb.dimy = b.dimy;
                nb.dimz = b.dimz;
                Blade.Add(nb);
            }
        }
    }
    class TaniDDS
    {
        private FourCC fcc_DDS = new FourCC("DDS ");
        private int header_size = 124;
        private int header_flags;
        private int header_height;
        private int header_width;
        public int Height { get { return header_height; } }
        public int Width { get { return header_width; } }
        private int header_pitchorsize;
        private int header_depth;
        private int header_mipmaps;
        private byte[] header_reserved = new byte[44];
        private int pxf_size = 32;
        private int pxf_flags;
        private FourCC pxf_fcc;
        private int pxf_rgbcount;
        public int Depth { get { return (int)(pxf_rgbcount / 8); } }
        private int pxf_r_mask;
        private int pxf_g_mask;
        private int pxf_b_mask;
        private int pxf_a_mask;
        private int ddscaps_1;
        private int ddscaps_2;
        private int ddscaps_res1;
        private int ddscaps_res2;
        private int header_reserved2;
        public byte[,,] Data;
        public TaniDDS(TaniDDS Source)
        {
            From(Source);
        }
        public TaniDDS(BinaryReader cReader)
        {
            Load(cReader);
        }
        public void From(TaniDDS Source)
        {
            header_flags = Source.header_flags ;
            header_height = Source.header_height ;
            header_width = Source.header_width ;
            header_pitchorsize = Source.header_pitchorsize ;
            header_depth=Source .header_depth ;
            header_mipmaps = Source.header_mipmaps ;
            Source.header_reserved .CopyTo (header_reserved ,0);
            pxf_flags = Source.pxf_flags ;
            pxf_fcc = Source.pxf_fcc ;
            pxf_rgbcount = Source.pxf_rgbcount ;
            pxf_r_mask =Source .pxf_r_mask ;
            pxf_g_mask =Source .pxf_g_mask ;
            pxf_b_mask =Source .pxf_b_mask ;
            pxf_a_mask =Source .pxf_a_mask ;
            ddscaps_1 = Source.ddscaps_1 ;
            ddscaps_2 = Source.ddscaps_2 ;
            ddscaps_res1=Source.ddscaps_res1 ;
            ddscaps_res2=Source.ddscaps_res2 ;
            header_reserved2=Source.header_reserved2 ;
            Data  = new byte[Width,Height ,Depth];
            for (int y = 0; y < Height; y++)
                for (int x = 0; x < Width; x++)
                    for (int i = 0; i < pxf_rgbcount / 8; i++)
                        Data[x, y, i] = Source.Data[x, y, i];
        }
        public int Size { get { return 128 + Width * Height * Depth ; } }
        public void Load(BinaryReader cReader)
        {
            if (cReader.ReadInt32() == fcc_DDS.IntValue )
            {
                header_size = cReader.ReadInt32();
                header_flags = cReader.ReadInt32();
                header_height = cReader.ReadInt32();
                header_width = cReader.ReadInt32();
                header_pitchorsize = cReader.ReadInt32();
                header_depth = cReader.ReadInt32();
                header_mipmaps = cReader.ReadInt32();
                header_reserved = cReader.ReadBytes(44);
                pxf_size = cReader.ReadInt32();
                pxf_flags = cReader.ReadInt32();
                pxf_fcc.IntValue = cReader.ReadInt32();
                pxf_rgbcount = cReader.ReadInt32();
                pxf_r_mask = cReader.ReadInt32();
                pxf_g_mask = cReader.ReadInt32();
                pxf_b_mask = cReader.ReadInt32();
                pxf_a_mask = cReader.ReadInt32();
                ddscaps_1 = cReader.ReadInt32();
                ddscaps_2 = cReader.ReadInt32();
                ddscaps_res1 = cReader.ReadInt32();
                ddscaps_res2 = cReader.ReadInt32();
                header_reserved2 = cReader.ReadInt32();
                Data = new byte[Width, Height, Depth];
                for (int y = 0; y < Height; y++)
                    for (int x = 0; x < Width; x++)
                        for (int i = 0; i < pxf_rgbcount / 8; i++)
                            Data[x, y, i] = cReader.ReadByte();
            }
            else throw new Exception("DDS expected, but signature not found!");
        }
        public void Save(BinaryWriter cWriter)
        {
            cWriter.Write(fcc_DDS.IntValue);
            cWriter.Write(header_size);
            cWriter.Write(header_flags);
            cWriter.Write(header_height);
            cWriter.Write(header_width);
            cWriter.Write(header_pitchorsize);
            cWriter.Write(header_depth);
            cWriter.Write(header_mipmaps);
            cWriter.Write(header_reserved);
            cWriter.Write(pxf_size);
            cWriter.Write(pxf_flags);
            cWriter.Write(pxf_fcc.IntValue);
            cWriter.Write(pxf_rgbcount);
            cWriter.Write(pxf_r_mask);
            cWriter.Write(pxf_g_mask);
            cWriter.Write(pxf_b_mask);
            cWriter.Write(pxf_a_mask);
            cWriter.Write(ddscaps_1);
            cWriter.Write(ddscaps_2);
            cWriter.Write(ddscaps_res1);
            cWriter.Write(ddscaps_res2);
            cWriter.Write(header_reserved2);
            for (int y = 0; y < Height; y++)
                for (int x = 0; x < Width; x++)
                    for (int i = 0; i < pxf_rgbcount / 8; i++)
                        cWriter.Write(Data[x, y, i]);
        }

    }
    // main classes
    public abstract class TaniPacket
    {
        public abstract void Load(BinaryReader cReader);
        public abstract void Save(BinaryWriter cWriter);
    }
    class TaniTRWH : TaniPacket 
    {
        private FourCC fcc_trwh = new FourCC("TRWH");
        public int Size { get { return 20; } }
        public int Width;
        public int Height;
        private int padding;
        public override void Load(BinaryReader cReader)
        {
            FourCC fcc = new FourCC();
            fcc.IntValue = cReader.ReadInt32();
            if (fcc.IntValue != fcc_trwh.IntValue)
            {
                throw new Exception("Type stored with packet is not the same as the type in the packet table");
            }
            cReader.ReadInt32();
            this.Width = cReader.ReadInt32();
            this.Height = cReader.ReadInt32();
            this.padding = cReader.ReadInt32();
        }
        public override void Save(BinaryWriter cWriter)
        {
            cWriter.Write(fcc_trwh.IntValue);
            cWriter.Write(12);
            cWriter.Write(Width);
            cWriter.Write(Height);
            cWriter.Write(padding);
        }
    }
    class TaniTRRN : TaniPacket 
    {
        private FourCC fcc_trrn = new FourCC("TRRN");
        public string Name;
        public string[] Texture = new string[6];
        public float[] TextureData = new float[18];
        private int m_x, m_y;
        public int posX { get { return m_x; } }
        public int posY { get { return m_y; } }
        public TaniTRRN(int coordinateX, int coordinateY)
        {
            m_x = coordinateX ;
            m_y = coordinateY ;
        }
        private int numverts;
        public int VertexCount { get { return numverts; } }
        private int numtris;
        public int TriangleCount { get { return numtris; } }
        public TaniVertex [] vertex;
        public TaniTriangle [] triangle;
        public List<TaniGras> gras = new List<TaniGras> ();
        public TaniDDS DDS1;
        public TaniDDS DDS2;
        private int datasize
        {
            get
            {
                int s = 400 + 625*44 + 1152*6;
                s += 4 + DDS1.Size + 4 + DDS2.Size;
                s += 4;
                foreach (TaniGras g in gras)
                    s += g.Size;
                return s;
            }
        }
        public int Size { get { return 8 + datasize; } }
        public float GetZ(int X, int Y)
        {
            if ((X + 25 * Y) < numverts)
                return vertex[X + 25 * Y].posZ;
            else
                return 0.0f;
        }
        public float GetZ(int N)
        {
            if (N < numverts)
                return vertex[N].posZ;
            else
                return 0.0f;
        }
        public void SetZ(int X, int Y, float Z)
        {
            if ((X + 25 * Y) < numverts)
                vertex[X + 25 * Y].posZ = Z;
        }
        public void SetZ(int N, float Z)
        {
            if (N < numverts)
                vertex[N].posZ = Z;
        }
        public float MinX
        {
            get
            {
                return vertex[0].posX;
            }
        }
        public float MinY
        {
            get
            {
                return vertex[0].posY;
            }
        }
        public float MinZ
        {
            get
            {
                float z = 0;
                for (int n = 0; n < 625; n++)
                    if (GetZ(n) < z) z = GetZ(n);
                return z;
            }
        }
        public float MaxX
        {
            get
            {
                return vertex[numverts -1].posX;
            }
        }
        public float MaxY
        {
            get
            {
                return vertex[numverts-1].posY;
            }
        }
        public float MaxZ
        {
            get
            {
                float z = 0;
                for (int n = 0; n < 625; n++)
                    if (GetZ(n) > z) z = GetZ(n);
                return z;
            }
        }
        public void Raise(float AddToZ)
        {
            for (int n = 0; n < 625; n++) SetZ(n,GetZ(n)+AddToZ);
        }
        public override void Load(BinaryReader cReader)
        {
            FourCC fcc = new FourCC();
            fcc.IntValue = cReader.ReadInt32();
            if (fcc.IntValue != this.fcc_trrn.IntValue)
            {
                throw new Exception("Type stored with packet is not the same as the type in the packet table");
            }
            int size = cReader.ReadInt32();
            Name = CommonUtils.ConvertZeroTerminatedBytesToString(cReader.ReadBytes(0x80)).TrimEnd(new char[1]);
            for (int n = 0; n < 6; n++)
                Texture[n] = CommonUtils.ConvertZeroTerminatedBytesToString(cReader.ReadBytes(0x20)).TrimEnd(new char[1]);
            for (int n = 0; n < 18; n++)
                TextureData[n] = cReader.ReadSingle();
            numverts = cReader.ReadInt32();
            numtris = cReader.ReadInt32();
            vertex = new TaniVertex[numverts];
            triangle = new TaniTriangle[numtris];
            for (int n = 0; n < numverts; n++)
                vertex[n].Load(cReader);
            for (int n = 0; n < numtris; n++)
                triangle[n].Load(cReader);
            int l = cReader.ReadInt32();
            DDS1 = new TaniDDS(cReader);
            l = cReader.ReadInt32();
            DDS2 = new TaniDDS(cReader);
            int numgrass = cReader.ReadInt32();
            for (int n = 0; n < numgrass; n++)
            {
                    TaniGras g = new TaniGras (m_x, m_y);
                    g.Load(cReader);
                    gras .Add(g);
            }
        }
        public override void Save(BinaryWriter cWriter)
        {
            cWriter.Write(fcc_trrn.IntValue);
            cWriter.Write(datasize );
            cWriter.Write(CommonUtils.ConvertStringToBytes(Name.PadRight(0x80, '\0')));
            for (int num1 = 0; num1 < 6; num1++)
                cWriter.Write(CommonUtils.ConvertStringToBytes(Texture [num1].PadRight(0x20, '\0')));
            for (int num1 = 0; num1 < 18; num1++)
                cWriter.Write(TextureData[num1]);
            cWriter.Write(numverts);
            cWriter.Write(numtris);
            for (int num1 = 0; num1 < numverts; num1++)
                vertex [num1].Save (cWriter);
            for (int num1 = 0; num1 < numtris; num1++)
                triangle[num1].Save(cWriter);
            cWriter.Write(DDS1.Size);
            DDS1.Save(cWriter);
            cWriter.Write(DDS2.Size);
            DDS2.Save(cWriter);
            cWriter.Write(gras.Count );
            foreach (TaniGras g in gras)
                g.Save(cWriter);
        }
        public void From(TaniTRRN Source, bool CopyHeightmap, bool CopyTexture, bool CopyTinting, bool CopyGras, bool CopyWater)
        {
                if (CopyTexture)
                {
                    for (int n = 0; n < 6; n++)
                        Texture[n] = Source.Texture[n];
                    for (int n = 0; n < 18; n++)
                        TextureData[n] = Source.TextureData[n];
                    DDS1 = new TaniDDS (Source.DDS1);
                    DDS2 = new TaniDDS (Source.DDS2);
                }
                for (int n = 0; n < numverts; n++)
                    vertex[n].From(Source.vertex[n], false,CopyHeightmap,false,CopyTinting ,false);
                if (CopyGras)
                {
                    gras.Clear();
                    foreach (TaniGras g in Source.gras)
                    {
                        TaniGras ng = new TaniGras(m_x, m_y);
                        ng.From(g);
                        ng.GrasName = Name.Substring(6, 6) + ng.GrasName.Substring(6);
                        gras.Add(ng);
                    }
                }
            
        }
    }
    class TaniWATR : TaniPacket
    {
        private FourCC fcc_watr = new FourCC("WATR");
        private byte[] unknown = new byte[128];
        public float ColorRed;
        public float ColorGreen;
        public float ColorBlue;
        public float RippleX;
        public float RippleY;
        public float Smoothness;
        public float ReflectionBias;
        public float ReflectionPower;
        public float unknown_180 = 180f;
        public float unknown_05f = 0.5f;
        public string[] Texture = new string[3];
        public float[] TextureDirX = new float[3];
        public float[] TextureDirY = new float[3];
        public float[] TextureRate = new float[3];
        public float[] TextureAngle = new float[3];
        private float OffsetX;
        private float OffsetY;
        private int m_x, m_y;
        public int posX { get { return m_x; } }
        public int posY { get { return m_y; } }
        private int numverts;
        public int VertexCount { get { return numverts; } }
        private int numtris;
        public int TriangleCount { get { return numtris; } }
        public TaniWatrVertex[] vertex;
        public TaniTriangle[] triangle;
        public int[] TriFlag;
        public TaniDDS DDS;

        private int datasize
        {
            get
            {
                int s = 328 + numverts * 28 + numtris * 6;
                s += numtris * 4;
                s += 4 + DDS.Size;
                s += 2 * 4;
                return s;
            }
        }
        public int Size { get { return 8 + datasize; } }
        public float GetZ(int X, int Y)
        {
            if ((X + 25 * Y) < numverts)
                return vertex[X + 25 * Y].posZ;
            else
                return 0.0f;
        }
        public float GetZ(int N)
        {
            if (N < numverts)
                return vertex[N].posZ;
            else
                return 0.0f;
        }
        public void SetZ(int X, int Y, float Z)
        {
            if ((X + 25 * Y) < numverts)
                vertex[X + 25 * Y].posZ = Z;
        }
        public void SetZ(int N, float Z)
        {
            if (N < numverts)
                vertex[N].posZ = Z;
        }
        public float MinX
        {
            get
            {
                return vertex[0].posX;
            }
        }
        public float MinY
        {
            get
            {
                return vertex[0].posY;
            }
        }
        public float MinZ
        {
            get
            {
                float z = 0;
                for (int n = 0; n < 625; n++)
                    if (GetZ(n) < z) z = GetZ(n);
                return z;
            }
        }
        public float MaxX
        {
            get
            {
                return vertex[numverts - 1].posX;
            }
        }
        public float MaxY
        {
            get
            {
                return vertex[numverts - 1].posY;
            }
        }
        public float MaxZ
        {
            get
            {
                float z = 0;
                for (int n = 0; n < 625; n++)
                    if (GetZ(n) > z) z = GetZ(n);
                return z;
            }
        }
        public void Raise(float AddToZ)
        {
            for (int n = 0; n < 625; n++) SetZ(n, GetZ(n) + AddToZ);
        }
        public void Move(float dx, float dy, float dz)
        {
            for (int n = 0; n < 625; n++)
            {
                vertex[n].posX += dx;
                vertex[n].posY += dy;
                vertex[n].posZ += dz;
            }
        }
        public TaniWATR(BinaryReader cReader)
        {
            Load(cReader);
        }
        public TaniWATR(TaniWATR srcWater, int X, int Y)
        {
            this.Clone(srcWater);
            float dx = (X - srcWater.posX) * 40f;
            float dy = (Y - srcWater.posY) * 40f;
            m_x = X;
            m_y = Y;
            this.OffsetX = X * 8f;
            this.OffsetY = Y * 8f;
            for (int n = 0; n < numverts; n++)
            {
                vertex[n].posX += dx;
                vertex[n].posY += dy;
            }
        }
        public override void Load(BinaryReader cReader)
        {
            FourCC fcc = new FourCC();
            fcc.IntValue = cReader.ReadInt32();
            if (fcc.IntValue != this.fcc_watr.IntValue)
            {
                throw new Exception("Type stored with packet is not the same as the type in the packet table");
            }
            int size = cReader.ReadInt32();
            unknown = cReader.ReadBytes(128);
            ColorRed = cReader.ReadSingle();
            ColorGreen = cReader.ReadSingle();
            ColorBlue = cReader.ReadSingle();
            RippleX  = cReader.ReadSingle();
            RippleY = cReader.ReadSingle();
            Smoothness = cReader.ReadSingle();
            ReflectionBias = cReader.ReadSingle();
            ReflectionPower = cReader.ReadSingle();
            unknown_180 = cReader.ReadSingle();
            unknown_05f = cReader.ReadSingle();
            for (int n = 0; n < 3; n++)
            {
                Texture[n] = CommonUtils.ConvertZeroTerminatedBytesToString(cReader.ReadBytes(0x20)).TrimEnd(new char[1]);
                TextureDirX[n] = cReader.ReadSingle();
                TextureDirY[n] = cReader.ReadSingle();
                TextureRate[n] = cReader.ReadSingle();
                TextureAngle[n] = cReader.ReadSingle();
            }
            OffsetX = cReader.ReadSingle();
            OffsetY = cReader.ReadSingle();
            numverts = cReader.ReadInt32();
            numtris = cReader.ReadInt32();
            vertex = new TaniWatrVertex[numverts];
            triangle = new TaniTriangle[numtris];
            TriFlag = new Int32[numtris];
            for (int n = 0; n < numverts; n++)
                vertex[n].Load(cReader);
            for (int n = 0; n < numtris; n++)
                triangle[n].Load(cReader);
            for (int n = 0; n < numtris; n++)
                TriFlag [n]=cReader .ReadInt32 ();
            int l = cReader.ReadInt32();
            DDS = new TaniDDS(cReader);
            m_x = cReader.ReadInt32();
            m_y = cReader.ReadInt32();
        }
        public override void Save(BinaryWriter cWriter)
        {
            cWriter.Write(fcc_watr.IntValue);
            cWriter.Write(datasize);
            cWriter.Write(unknown);
            cWriter.Write(ColorRed);
            cWriter.Write(ColorGreen);
            cWriter.Write(ColorBlue);
            cWriter.Write(RippleX);
            cWriter.Write(RippleY);
            cWriter.Write(Smoothness);
            cWriter.Write(ReflectionBias);
            cWriter.Write(ReflectionPower);
            cWriter.Write(unknown_180);
            cWriter.Write(unknown_05f);
            for (int n = 0; n < 3; n++)
            {
                cWriter.Write(CommonUtils.ConvertStringToBytes(Texture[n].PadRight(0x20, '\0')));
                cWriter.Write(TextureDirX[n]);
                cWriter.Write(TextureDirY[n]);
                cWriter.Write(TextureRate[n]);
                cWriter.Write(TextureAngle[n]);
            }
            cWriter.Write(OffsetX);
            cWriter.Write(OffsetY);
            cWriter.Write(numverts);
            cWriter.Write(numtris);
            for (int n = 0; n < numverts; n++)
                vertex[n].Save(cWriter);
            for (int n = 0; n < numtris; n++)
                triangle[n].Save(cWriter);
            for (int n = 0; n < numtris; n++)
                cWriter.Write(TriFlag [n]);
            cWriter.Write(DDS.Size);
            DDS.Save(cWriter);
            cWriter.Write(m_x);
            cWriter.Write(m_y);
        }
        public void From(TaniWATR Source, bool CopyHeightmap, bool CopyTexture, bool CopyUnknown)
        {
                if (CopyTexture)
                {
                    for (int n = 0; n < 3; n++)
                    {
                        Texture[n] = Source.Texture[n];
                        TextureDirX[n] = Source.TextureDirX[n];
                        TextureDirY[n] = Source.TextureDirY[n];
                        TextureRate[n] = Source.TextureRate[n];
                        TextureAngle[n] = Source.TextureAngle[n];
                    }
                    DDS = new TaniDDS (Source.DDS);
                }
                if (CopyHeightmap)
                {
                    for (int n = 0; n < numverts; n++)
                        vertex[n].From(Source.vertex[n], false, true, CopyUnknown );
                    for (int n = 0; n < numtris; n++)
                        TriFlag[n] = Source.TriFlag[n];
                }
                if (CopyUnknown)
                {
                    Source.unknown.CopyTo(unknown, 0);
                    unknown_180 = Source.unknown_180;
                    unknown_05f = Source.unknown_05f;
                }
                ColorRed = Source.ColorRed;
                ColorGreen = Source.ColorGreen;
                ColorBlue = Source.ColorBlue;
                RippleX = Source.RippleX;
                RippleY = Source.RippleY;
                Smoothness = Source.Smoothness;
                ReflectionBias = Source.ReflectionBias;
                ReflectionPower = Source.ReflectionPower;
        }
        public void Clone(TaniWATR Source)
        {
            Source.unknown.CopyTo(unknown, 0);
            ColorRed = Source.ColorRed;
            ColorGreen = Source.ColorGreen;
            ColorBlue = Source .ColorBlue ;
            RippleX = Source.RippleX;
            RippleY = Source.RippleY;
            Smoothness = Source.Smoothness;
            ReflectionBias = Source.ReflectionBias;
            ReflectionPower = Source.ReflectionPower;
            unknown_180 = Source.unknown_180;
            unknown_05f = Source.unknown_05f;
            for (int n = 0; n < 3; n++)
            {
                Texture[n] = Source.Texture[n];
                TextureDirX[n] = Source.TextureDirX[n];
                TextureDirY[n] = Source.TextureDirY[n];
                TextureRate[n] = Source.TextureRate[n];
                TextureAngle[n] = Source.TextureAngle[n];
            }
            OffsetX = Source.OffsetX;
            OffsetY = Source.OffsetY;
            numverts = Source.numverts;
            numtris = Source.numtris;
            vertex = new TaniWatrVertex[numverts];
            triangle = new TaniTriangle[numtris];
            TriFlag = new Int32[numtris];
            for (int n = 0; n < numverts; n++)
                vertex[n].From(Source.vertex[n], true, true, true);
            for (int n = 0; n < numtris; n++)
                triangle[n] = Source.triangle [n];
            for (int n = 0; n < numtris; n++)
                TriFlag[n] = Source.TriFlag [n];
            DDS = new TaniDDS(Source.DDS);
        }
        public bool AdjustFlagsToTreshold(byte treshold)
        {
            bool waterfound = false;
            for (int n = 0; n < TriangleCount; n++)
                TriFlag[n] = 1;
            for (int i = 0; i < 128; i++)
                for (int j = 0; j < 128; j++)
                    if (DDS.Data[i, j, 0] > treshold)
                    {
                        DDS.Data[i, j, 0] = 255;
                        TriFlag[TriangleFromDDS(i, j)] = 0;
                        TriFlag[TriangleFromDDS(i, j) + 1] = 0;
                        waterfound = true;
                    }
            return waterfound;
        }
        private int TriangleFromDDS(int x, int y)
        {
            x = (x * 24) / 128;
            y = (y * 24) / 128;
            return (x + y * 24) * 2;
        }
    }
    class TaniASWM : TaniPacket 
    {
        private FourCC fcc_aswm = new FourCC("ASWM");
        private byte[] data;
        private FourCC fcc_comp = new FourCC("COMP");
        public int len_comp = 0;
        public int len_uncomp = 0;
        public int Size { get { return data.GetLength(0) + 8 +12; } }
        public override void Load(BinaryReader cReader)
        {
            FourCC fcc = new FourCC();
            fcc.IntValue = cReader.ReadInt32();
            if (fcc.IntValue != fcc_aswm.IntValue)
            {
                throw new Exception("Type stored with packet is not the same as the type in the packet table");
            }
            int size = cReader.ReadInt32();
            fcc.IntValue = cReader.ReadInt32();
            if (fcc.IntValue != fcc_comp.IntValue)
            {
                throw new Exception("ASWM is not stored compressed... now that's unexpected, sorry!");
            }
            len_comp = cReader.ReadInt32();
            len_uncomp = cReader.ReadInt32();
            //data = new byte[size-12];
            data = cReader.ReadBytes(size-12);
        }
        public override void Save(BinaryWriter cWriter)
        {
            cWriter.Write(this.fcc_aswm.IntValue);
            cWriter.Write(this.data.GetLength (0)+12);
            cWriter.Write(this.fcc_comp.IntValue);
            cWriter.Write(this.len_comp);
            cWriter.Write(this.len_uncomp);
            cWriter.Write(this.data);
        }
        public void SaveData(BinaryWriter cWriter)
        {
            cWriter.Write(this.fcc_comp.IntValue);
            cWriter.Write(this.len_comp);
            cWriter.Write(this.len_uncomp);
            cWriter.Write(this.data);
        }
    }

    class TaniTRN
    {
        private string DiskFile;
        private FourCC c_TRN;
        private FourCC c_TRWH = new FourCC("TRWH");
        private FourCC c_TRRN = new FourCC("TRRN");
        private FourCC c_ASWM = new FourCC("ASWM");
        private FourCC c_WATR = new FourCC("WATR");
        private ushort VerMajor;
        private ushort VerMinor;
        private bool flag_loaded = false;
        private bool flag_trwhvalid = false;
        private bool flag_aswmfound = false;
        public TaniASWM m_cASWM = new TaniASWM();
        private TaniTRWH m_cTRWH = new TaniTRWH();
        private List<TaniWATR> m_lWATR = new List<TaniWATR>();
        public TaniWATR Water(int X, int Y)
        {
            return Water(X, Y, 0);
        }
        public TaniWATR Water(int X, int Y, int count)
        {
            TaniWATR result = null;
            foreach (TaniWATR w in m_lWATR)
                if (w.posX == X && w.posY == Y)
                    if (count-- == 0)
                        result = w;
            return result;
        }
        public int WaterLayers(int X, int Y)
        {
            int result = 0;
            foreach (TaniWATR w in m_lWATR)
                if (w.posX == X && w.posY == Y) result++;
            return result;
        }
        public void WaterAdd(TaniWATR w)
        {
            m_lWATR.Add(w);
        }
        public void WaterRemove(TaniWATR w)
        {
            m_lWATR.Remove(w);
        }
        public void WaterRemove(int X, int Y)
        {
            foreach (TaniWATR w in m_lWATR)
                if (w.posX == X && w.posY == Y)
                    m_lWATR.Remove(w);
        }
        public void WaterRemoveAll()
        {
            m_lWATR.Clear();
        }
        public int Width, Height;
        public TaniTRRN[,] Terrain;
        
        public bool Load(string FileName)
        {
            FileStream fs = new FileStream(FileName, FileMode.Open, FileAccess.Read, FileShare.Read);
            bool result = Load(fs);
            if (flag_loaded) DiskFile = FileName;
            return result;
        }
        public bool Load(Stream fs)
        {
            try
            {
                BinaryReader br = new BinaryReader(fs);
                c_TRN.IntValue = br.ReadInt32();
                VerMajor = br.ReadUInt16();
                VerMinor = br.ReadUInt16();
                int packetcount = br.ReadInt32();
                TaniPacketKey[] packets = new TaniPacketKey[packetcount];
                for (int n = 0; n < packetcount; n++)
                {
                    FourCC fcc = new FourCC();
                    fcc.IntValue = br.ReadInt32();
                    packets[n].Type = fcc;
                    packets[n].Offset = br.ReadInt32();
                }
                int x = 0, y = 0;
                for (int n = 0; n < packetcount; n++)
                {
                    fs.Seek((long)packets[n].Offset, SeekOrigin.Begin);
                    if (packets[n].Type.IntValue == c_TRWH.IntValue)
                    {
                        if (!flag_trwhvalid)
                        {
                            m_cTRWH.Load(br);
                            flag_trwhvalid = true;
                            Width = m_cTRWH.Width;
                            Height = m_cTRWH.Height;
                            Terrain = new TaniTRRN[Width, Height];
                        }
                        else throw new Exception("TRN-reader found duplicate TRWH information!");
                    }
                    else if (packets[n].Type.IntValue == c_TRRN.IntValue)
                    {
                        if (flag_trwhvalid)
                        {
                            TaniTRRN trn = new TaniTRRN(x,y);
                            trn.Load(br);
                            Terrain[x, y] = trn;
                            x++;
                            if (x >= Width)
                            {
                                x = 0;
                                y++;
                            }
                        }
                        else throw new Exception("TRN-reader missed TRWH information!");
                    }
                    else if (packets[n].Type.IntValue == c_ASWM.IntValue)
                    {
                        if (!flag_aswmfound)
                        {
                            m_cASWM.Load(br);
                            flag_aswmfound = true;
                        }
                        else throw new Exception("TRN-reader found duplicate ASWM information!");
                    }
                    else if (packets[n].Type.IntValue == c_WATR.IntValue)
                    {
                        TaniWATR w = new TaniWATR(br);
                        m_lWATR.Add(w);
                    }
                }
                br.Close();
                if (flag_trwhvalid && flag_aswmfound) flag_loaded = true;
            }
            catch { flag_loaded = false; }
            //if (flag_loaded) DiskFile = FileName;
            return flag_loaded;
        }
        public void Save()
        {
            if (flag_loaded) Save(DiskFile);
        }
        public void Save(string FileName)
        {
            if (flag_loaded)
            {
                FileStream fs = CommonUtils.CreateWriteStreamOverwriteReadOnly(FileName, FileMode.Create, FileAccess.Write, FileShare.None);
                BinaryWriter bw = new BinaryWriter(fs);
                Save(bw);
                bw.Close();
            }
        }
        public void Save(BinaryWriter bw)
        {
            if (flag_loaded)
            {
                bw.Write(c_TRN.IntValue);
                bw.Write(VerMajor);
                bw.Write(VerMinor);
                bw.Write(2 + Width * Height + m_lWATR .Count );
                int pos = 12 + 8 * (2 + Width * Height + m_lWATR.Count); 
                bw.Write(c_TRWH.IntValue);
                bw.Write(pos);
                pos += this.m_cTRWH.Size;
                for (int y = 0; y < Height; y++)
                    for (int x = 0; x < Width; x++)
                    {
                        bw.Write(c_TRRN.IntValue);
                        bw.Write(pos);
                        pos += Terrain[x, y].Size;
                    }
                foreach (TaniWATR w in m_lWATR )
                {
                    bw.Write(c_WATR.IntValue);
                    bw.Write(pos);
                    pos += w.Size;
                }
                bw.Write(c_ASWM.IntValue);
                bw.Write(pos);
                m_cTRWH.Save(bw);
                for (int y = 0; y < Height; y++)
                    for (int x = 0; x < Width; x++)
                        Terrain[x, y].Save(bw);
                foreach (TaniWATR w in m_lWATR)
                    w.Save(bw);
                m_cASWM.Save(bw);
            }
        }
        public void SaveStripped(BinaryWriter bw)
        {
            if (flag_loaded)
            {
                bw.Write(c_TRN.IntValue);
                bw.Write(VerMajor);
                bw.Write(VerMinor);
                bw.Write(2);
                int pos = 12 + 8 * (2);
                bw.Write(c_TRWH.IntValue);
                bw.Write(pos);
                pos += this.m_cTRWH.Size;
                bw.Write(c_ASWM.IntValue);
                bw.Write(pos);
                m_cTRWH.Save(bw);
                m_cASWM.Save(bw);
            }
        }
    }
}