﻿namespace ERFReader
{
    partial class ERFinder
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.BTN_Open = new System.Windows.Forms.Button();
            this.FileOpen = new System.Windows.Forms.OpenFileDialog();
            this.BTN_Export = new System.Windows.Forms.Button();
            this.BTN_Import = new System.Windows.Forms.Button();
            this.BTN_Save = new System.Windows.Forms.Button();
            this.BTN_SaveAs = new System.Windows.Forms.Button();
            this.BTN_Close = new System.Windows.Forms.Button();
            this.FileSave = new System.Windows.Forms.SaveFileDialog();
            this.BTN_Remove = new System.Windows.Forms.Button();
            this.Folder = new System.Windows.Forms.FolderBrowserDialog();
            this.FileImport = new System.Windows.Forms.OpenFileDialog();
            this.BTN_Exit = new System.Windows.Forms.Button();
            this.BTN_New = new System.Windows.Forms.Button();
            this.Status = new System.Windows.Forms.StatusStrip();
            this.LBL_Status = new System.Windows.Forms.ToolStripStatusLabel();
            this.BTN_ImportWater = new System.Windows.Forms.Button();
            this.FileTable = new System.Windows.Forms.ListView();
            this.NamePart = new System.Windows.Forms.ColumnHeader();
            this.ExtPart = new System.Windows.Forms.ColumnHeader();
            this.SizePart = new System.Windows.Forms.ColumnHeader();
            this.panel1 = new System.Windows.Forms.Panel();
            this.BTN_selinvert = new System.Windows.Forms.Button();
            this.BTN_selnone = new System.Windows.Forms.Button();
            this.BTN_selall = new System.Windows.Forms.Button();
            this.BTN_StripMod = new System.Windows.Forms.Button();
            this.cb_v10 = new System.Windows.Forms.CheckBox();
            this.Status.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // BTN_Open
            // 
            this.BTN_Open.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.BTN_Open.Location = new System.Drawing.Point(3, 3);
            this.BTN_Open.Name = "BTN_Open";
            this.BTN_Open.Size = new System.Drawing.Size(74, 24);
            this.BTN_Open.TabIndex = 0;
            this.BTN_Open.Text = "open";
            this.BTN_Open.UseVisualStyleBackColor = false;
            this.BTN_Open.Click += new System.EventHandler(this.BTN_Open_Click);
            // 
            // FileOpen
            // 
            this.FileOpen.DefaultExt = "erf";
            this.FileOpen.Filter = "ERF-files (*.ERF, *.MOD, *.PWC, *.HAK)|*.erf;*.mod;*.pwc;*.hak|all files (*.*)|*." +
                "*";
            // 
            // BTN_Export
            // 
            this.BTN_Export.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.BTN_Export.Location = new System.Drawing.Point(3, 201);
            this.BTN_Export.Name = "BTN_Export";
            this.BTN_Export.Size = new System.Drawing.Size(74, 24);
            this.BTN_Export.TabIndex = 2;
            this.BTN_Export.Text = "export";
            this.BTN_Export.UseVisualStyleBackColor = false;
            this.BTN_Export.Click += new System.EventHandler(this.BTN_Export_Click);
            // 
            // BTN_Import
            // 
            this.BTN_Import.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BTN_Import.Location = new System.Drawing.Point(3, 53);
            this.BTN_Import.Name = "BTN_Import";
            this.BTN_Import.Size = new System.Drawing.Size(74, 24);
            this.BTN_Import.TabIndex = 3;
            this.BTN_Import.Text = "import";
            this.BTN_Import.UseVisualStyleBackColor = false;
            this.BTN_Import.Click += new System.EventHandler(this.BTN_Import_Click);
            // 
            // BTN_Save
            // 
            this.BTN_Save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BTN_Save.Location = new System.Drawing.Point(3, 249);
            this.BTN_Save.Name = "BTN_Save";
            this.BTN_Save.Size = new System.Drawing.Size(74, 24);
            this.BTN_Save.TabIndex = 4;
            this.BTN_Save.Text = "save";
            this.BTN_Save.UseVisualStyleBackColor = false;
            this.BTN_Save.Click += new System.EventHandler(this.BTN_Save_Click);
            // 
            // BTN_SaveAs
            // 
            this.BTN_SaveAs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BTN_SaveAs.Location = new System.Drawing.Point(3, 273);
            this.BTN_SaveAs.Name = "BTN_SaveAs";
            this.BTN_SaveAs.Size = new System.Drawing.Size(74, 24);
            this.BTN_SaveAs.TabIndex = 5;
            this.BTN_SaveAs.Text = "save as";
            this.BTN_SaveAs.UseVisualStyleBackColor = false;
            this.BTN_SaveAs.Click += new System.EventHandler(this.BTN_SaveAs_Click);
            // 
            // BTN_Close
            // 
            this.BTN_Close.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BTN_Close.Location = new System.Drawing.Point(3, 298);
            this.BTN_Close.Name = "BTN_Close";
            this.BTN_Close.Size = new System.Drawing.Size(74, 24);
            this.BTN_Close.TabIndex = 6;
            this.BTN_Close.Text = "close";
            this.BTN_Close.UseVisualStyleBackColor = false;
            this.BTN_Close.Click += new System.EventHandler(this.BTN_Close_Click);
            // 
            // FileSave
            // 
            this.FileSave.DefaultExt = "erf";
            this.FileSave.Filter = "ERF-files (*.ERF, *.MOD, *.PWC, *.HAK)|*.erf;*.mod;*.pwc;*.hak|all files (*.*)|*." +
                "*";
            this.FileSave.SupportMultiDottedExtensions = true;
            // 
            // BTN_Remove
            // 
            this.BTN_Remove.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.BTN_Remove.Location = new System.Drawing.Point(3, 225);
            this.BTN_Remove.Name = "BTN_Remove";
            this.BTN_Remove.Size = new System.Drawing.Size(74, 24);
            this.BTN_Remove.TabIndex = 7;
            this.BTN_Remove.Text = "remove";
            this.BTN_Remove.UseVisualStyleBackColor = false;
            this.BTN_Remove.Click += new System.EventHandler(this.BTN_Remove_Click);
            // 
            // Folder
            // 
            this.Folder.Description = "Specify output folder:";
            this.Folder.RootFolder = System.Environment.SpecialFolder.MyComputer;
            // 
            // FileImport
            // 
            this.FileImport.Multiselect = true;
            // 
            // BTN_Exit
            // 
            this.BTN_Exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BTN_Exit.Location = new System.Drawing.Point(3, 345);
            this.BTN_Exit.Name = "BTN_Exit";
            this.BTN_Exit.Size = new System.Drawing.Size(74, 24);
            this.BTN_Exit.TabIndex = 8;
            this.BTN_Exit.Text = "exit";
            this.BTN_Exit.UseVisualStyleBackColor = false;
            this.BTN_Exit.Click += new System.EventHandler(this.BTN_exit_Click);
            // 
            // BTN_New
            // 
            this.BTN_New.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.BTN_New.Location = new System.Drawing.Point(3, 28);
            this.BTN_New.Name = "BTN_New";
            this.BTN_New.Size = new System.Drawing.Size(74, 24);
            this.BTN_New.TabIndex = 10;
            this.BTN_New.Text = "new";
            this.BTN_New.UseVisualStyleBackColor = false;
            this.BTN_New.Click += new System.EventHandler(this.BTN_NewHAK_Click);
            // 
            // Status
            // 
            this.Status.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.LBL_Status});
            this.Status.Location = new System.Drawing.Point(0, 374);
            this.Status.Name = "Status";
            this.Status.Size = new System.Drawing.Size(342, 22);
            this.Status.TabIndex = 11;
            this.Status.Text = "statusStrip1";
            // 
            // LBL_Status
            // 
            this.LBL_Status.AutoToolTip = true;
            this.LBL_Status.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.LBL_Status.Name = "LBL_Status";
            this.LBL_Status.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never;
            this.LBL_Status.Size = new System.Drawing.Size(327, 17);
            this.LBL_Status.Spring = true;
            this.LBL_Status.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // BTN_ImportWater
            // 
            this.BTN_ImportWater.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BTN_ImportWater.Location = new System.Drawing.Point(3, 77);
            this.BTN_ImportWater.Name = "BTN_ImportWater";
            this.BTN_ImportWater.Size = new System.Drawing.Size(74, 24);
            this.BTN_ImportWater.TabIndex = 12;
            this.BTN_ImportWater.Text = "import water";
            this.BTN_ImportWater.UseVisualStyleBackColor = false;
            this.BTN_ImportWater.Click += new System.EventHandler(this.BTN_ImportWater_Click);
            // 
            // FileTable
            // 
            this.FileTable.AllowColumnReorder = true;
            this.FileTable.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.NamePart,
            this.ExtPart,
            this.SizePart});
            this.FileTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FileTable.GridLines = true;
            this.FileTable.HideSelection = false;
            this.FileTable.Location = new System.Drawing.Point(81, 0);
            this.FileTable.Name = "FileTable";
            this.FileTable.ShowItemToolTips = true;
            this.FileTable.Size = new System.Drawing.Size(261, 374);
            this.FileTable.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.FileTable.TabIndex = 13;
            this.FileTable.UseCompatibleStateImageBehavior = false;
            this.FileTable.View = System.Windows.Forms.View.Details;
            this.FileTable.MouseClick += new System.Windows.Forms.MouseEventHandler(this.OnMouseClick);
            this.FileTable.SelectedIndexChanged += new System.EventHandler(this.FileTable_SelectedIndexChanged);
            this.FileTable.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.listView1_ColumnClick);
            this.FileTable.ItemDrag += new System.Windows.Forms.ItemDragEventHandler(this.OnItemDrag);
            // 
            // NamePart
            // 
            this.NamePart.Text = "Filename";
            this.NamePart.Width = 129;
            // 
            // ExtPart
            // 
            this.ExtPart.Text = "Type";
            this.ExtPart.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.ExtPart.Width = 44;
            // 
            // SizePart
            // 
            this.SizePart.Text = "Size";
            this.SizePart.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.SizePart.Width = 68;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.BTN_selinvert);
            this.panel1.Controls.Add(this.BTN_selnone);
            this.panel1.Controls.Add(this.BTN_selall);
            this.panel1.Controls.Add(this.BTN_StripMod);
            this.panel1.Controls.Add(this.cb_v10);
            this.panel1.Controls.Add(this.BTN_Open);
            this.panel1.Controls.Add(this.BTN_Export);
            this.panel1.Controls.Add(this.BTN_ImportWater);
            this.panel1.Controls.Add(this.BTN_Import);
            this.panel1.Controls.Add(this.BTN_Save);
            this.panel1.Controls.Add(this.BTN_New);
            this.panel1.Controls.Add(this.BTN_SaveAs);
            this.panel1.Controls.Add(this.BTN_Exit);
            this.panel1.Controls.Add(this.BTN_Close);
            this.panel1.Controls.Add(this.BTN_Remove);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(81, 374);
            this.panel1.TabIndex = 14;
            // 
            // BTN_selinvert
            // 
            this.BTN_selinvert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.BTN_selinvert.Location = new System.Drawing.Point(3, 176);
            this.BTN_selinvert.Name = "BTN_selinvert";
            this.BTN_selinvert.Size = new System.Drawing.Size(74, 24);
            this.BTN_selinvert.TabIndex = 17;
            this.BTN_selinvert.Text = "sel. invert";
            this.BTN_selinvert.UseVisualStyleBackColor = false;
            this.BTN_selinvert.Click += new System.EventHandler(this.BTN_selinvert_Click);
            // 
            // BTN_selnone
            // 
            this.BTN_selnone.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.BTN_selnone.Location = new System.Drawing.Point(3, 151);
            this.BTN_selnone.Name = "BTN_selnone";
            this.BTN_selnone.Size = new System.Drawing.Size(74, 24);
            this.BTN_selnone.TabIndex = 16;
            this.BTN_selnone.Text = "select none";
            this.BTN_selnone.UseVisualStyleBackColor = false;
            this.BTN_selnone.Click += new System.EventHandler(this.BTN_selnone_Click);
            // 
            // BTN_selall
            // 
            this.BTN_selall.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.BTN_selall.Location = new System.Drawing.Point(3, 127);
            this.BTN_selall.Name = "BTN_selall";
            this.BTN_selall.Size = new System.Drawing.Size(74, 24);
            this.BTN_selall.TabIndex = 15;
            this.BTN_selall.Text = "select all";
            this.BTN_selall.UseVisualStyleBackColor = false;
            this.BTN_selall.Click += new System.EventHandler(this.BTN_selall_Click);
            // 
            // BTN_StripMod
            // 
            this.BTN_StripMod.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BTN_StripMod.Location = new System.Drawing.Point(3, 102);
            this.BTN_StripMod.Name = "BTN_StripMod";
            this.BTN_StripMod.Size = new System.Drawing.Size(74, 24);
            this.BTN_StripMod.TabIndex = 14;
            this.BTN_StripMod.Text = "strip module";
            this.BTN_StripMod.UseVisualStyleBackColor = false;
            this.BTN_StripMod.Click += new System.EventHandler(this.BTN_StripMod_Click);
            // 
            // cb_v10
            // 
            this.cb_v10.AutoSize = true;
            this.cb_v10.Location = new System.Drawing.Point(7, 327);
            this.cb_v10.Name = "cb_v10";
            this.cb_v10.Size = new System.Drawing.Size(61, 17);
            this.cb_v10.TabIndex = 13;
            this.cb_v10.Text = "as v1.0";
            this.cb_v10.UseVisualStyleBackColor = true;
            // 
            // ERFinder
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(342, 396);
            this.Controls.Add(this.FileTable);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Status);
            this.MinimumSize = new System.Drawing.Size(350, 320);
            this.Name = "ERFinder";
            this.Text = "Tanita\'s NWN2Packer v1.9";
            this.QueryContinueDrag += new System.Windows.Forms.QueryContinueDragEventHandler(this.OnQueryContinueDrag);
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.OnDragDrop);
            this.DragEnter += new System.Windows.Forms.DragEventHandler(this.OnDragEnter);
            this.Load += new System.EventHandler(this.ERFinder_Load);
            this.Status.ResumeLayout(false);
            this.Status.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BTN_Open;
        private System.Windows.Forms.OpenFileDialog FileOpen;
        private System.Windows.Forms.Button BTN_Export;
        private System.Windows.Forms.Button BTN_Import;
        private System.Windows.Forms.Button BTN_Save;
        private System.Windows.Forms.Button BTN_SaveAs;
        private System.Windows.Forms.Button BTN_Close;
        private System.Windows.Forms.SaveFileDialog FileSave;
        private System.Windows.Forms.Button BTN_Remove;
        private System.Windows.Forms.FolderBrowserDialog Folder;
        private System.Windows.Forms.OpenFileDialog FileImport;
        private System.Windows.Forms.Button BTN_Exit;
        private System.Windows.Forms.Button BTN_New;
        private System.Windows.Forms.StatusStrip Status;
        private System.Windows.Forms.ToolStripStatusLabel LBL_Status;
        private System.Windows.Forms.Button BTN_ImportWater;
        private System.Windows.Forms.ListView FileTable;
        private System.Windows.Forms.ColumnHeader NamePart;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ColumnHeader ExtPart;
        private System.Windows.Forms.ColumnHeader SizePart;
        private System.Windows.Forms.CheckBox cb_v10;
        private System.Windows.Forms.Button BTN_StripMod;
        private System.Windows.Forms.Button BTN_selinvert;
        private System.Windows.Forms.Button BTN_selnone;
        private System.Windows.Forms.Button BTN_selall;
    }
}

