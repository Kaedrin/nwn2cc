using System;
using System.IO;
using System.Collections;
using System.Text;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using OEIShared;
using OEIShared.Utils;
using TaniTerrain;

namespace TaniWaterMill
{
    class WaterMillArea
    {
        public List<TaniWM> layers = new List<TaniWM>();
        public TaniTRN backup = null;
        public WaterMillArea(System.IO.Stream fs)
        {
            Load(fs);
        }
        public TaniWM GetLayer(string texture)
        {
            foreach (TaniWM wm in layers)
                if (wm.texture == texture)
                    return wm;
            return null;
        }
        public void RemoveLayer(string texture)
        {
            TaniWM wm = GetLayer(texture);
            if (wm != null)
                layers.Remove(wm);
        }
        public void Load(System.IO.Stream fs)
        {
            System.IO.BinaryReader br = new System.IO.BinaryReader(fs);
            string version = br.ReadString();
            if (version.StartsWith("watermill v1."))
            {
                int v = 1;
                if (version.EndsWith("v1.0"))
                    v = 0;
                if (br.ReadString() == "backup")
                {
                    int len = br.ReadInt32();
                    System.IO.MemoryStream ms = new System.IO.MemoryStream(br.ReadBytes(len));
                    backup = new TaniTRN();
                    backup.Load(ms);
                }
                else backup = null;
                if (br.ReadString() == "water")
                {
                    layers.Clear();
                    int len = br.ReadInt32();
                    for (int i = 0; i < len; i++)
                    {
                        TaniWM wm = new TaniWM("empty");
                        switch (v)
                        {
                            case 0:
                                wm.LoadV10(br);
                                break;
                            case 1:
                                wm.Load(br);
                                break;
                        }
                        layers.Add(wm);
                    }
                }
                else layers.Clear();
            }
            else throw new Exception("unsupported fileformat! either someone messed with my files, or this plugin is outdated...");
            br.Close();
        }
    }
    class TaniWM
    {
        public string texture;
        public bool wm_global_water = false;
        public bool wm_selected = true;
        public float wm_red = 0.65f;
        public float wm_green = 0.75f;
        public float wm_blue = 0.95f;
        public float wm_ripplex = 0.1f;
        public float wm_rippley = 0.1f;
        public float wm_smoothness = 0.5f;
        public float wm_refbias = 0.33f;
        public float wm_refpower = 1.0f;
        public float[] wm_scrollx = new float[3];
        public float[] wm_scrolly = new float[3];
        public float[] wm_scrollr = new float[3];
        public float[] wm_scrolla = new float[3];
        public string[] wm_texture = new string[3];
        public float wm_raisewater = 0f;
        public float wm_move_x = 0f;
        public float wm_move_y = 0f;
        public byte wm_treshold = 100;

        public List<TaniWATR> lwaters = new List<TaniWATR>();
        public int WaterCount { get { return lwaters.Count; } }
        public TaniWM(string Texture)
        {
            texture = Texture;
            for (int n = 0; n < 3; n++)
            {
                wm_scrollx[n] = 0.707f;
                wm_scrolly[n] = 0.707f;
                wm_scrollr[n] = 0.5f;
                wm_scrolla[n] = 0;
                wm_texture[n] = "WT_LAKE01_n";
            }
        }
        public TaniWM(TaniWM src)
        {
            texture = src.texture;
            wm_global_water = src.wm_global_water;
            wm_selected = src.wm_selected;
            wm_ripplex = src.wm_ripplex;
            wm_rippley = src.wm_rippley;
            wm_smoothness = src.wm_smoothness;
            wm_refbias = src.wm_refbias;
            wm_refpower = src.wm_refpower;
            for (int n = 0; n < 3; n++)
            {
                wm_texture[n] = src.wm_texture[n];
                wm_scrollx[n] = src.wm_scrollx[n];
                wm_scrolly[n] = src.wm_scrolly[n];
                wm_scrollr[n] = src.wm_scrollr[n];
                wm_scrolla[n] = src.wm_scrolla[n];
            }
            wm_raisewater = src.wm_raisewater;
            wm_treshold = src.wm_treshold;
        }
        public TaniWATR Water(int X, int Y)
        {
            return Water(X, Y, 0);
        }
        public TaniWATR Water(int X, int Y, int count)
        {
            foreach (TaniWATR w in lwaters)
                if (w.posX == X && w.posY == Y)
                    if (count-- == 0)
                        return w;
            return null;
        }
        public int CountWater(int X, int Y)
        {
            int count = 0;
            foreach (TaniWATR w in lwaters)
                if (w.posX == X && w.posY == Y)
                    count++;
            return count;
        }
        public void WaterAdd(TaniWATR w)
        {
            lwaters.Add(w);
        }
        public void Save(BinaryWriter bw)
        {
            bw.Write(texture);
            bw.Write(wm_global_water);
            bw.Write(wm_selected);
            bw.Write(wm_ripplex);
            bw.Write(wm_rippley);
            bw.Write(wm_smoothness);
            bw.Write(wm_refbias);
            bw.Write(wm_refpower);
            bw.Write(wm_raisewater);
            bw.Write(wm_treshold);
            for (int n = 0; n < 3; n++)
            {
                bw.Write(wm_texture[n]);
                bw.Write(wm_scrollx[n]);
                bw.Write(wm_scrolly[n]);
                bw.Write(wm_scrollr[n]);
                bw.Write(wm_scrolla[n]);
            }
            bw.Write(lwaters.Count);
            foreach (TaniWATR w in lwaters)
                w.Save(bw);
        }
        public void Load(BinaryReader br)
        {
            texture = br.ReadString();
            wm_global_water = br.ReadBoolean();
            wm_selected = br.ReadBoolean();
            wm_red = br.ReadSingle();
            wm_green = br.ReadSingle();
            wm_blue = br.ReadSingle();
            wm_ripplex = br.ReadSingle();
            wm_rippley = br.ReadSingle();
            wm_smoothness = br.ReadSingle();
            wm_refbias = br.ReadSingle();
            wm_refpower = br.ReadSingle();
            wm_raisewater = br.ReadSingle();
            wm_move_x = br.ReadSingle();
            wm_move_y = br.ReadSingle();
            wm_treshold = br.ReadByte();
            for (int n = 0; n < 3; n++)
            {
                wm_texture[n] = br.ReadString();
                wm_scrollx[n] = br.ReadSingle();
                wm_scrolly[n] = br.ReadSingle();
                wm_scrollr[n] = br.ReadSingle();
                wm_scrolla[n] = br.ReadSingle();
            }
            for (int n = br.ReadInt32(); n > 0; n--)
            {
                TaniWATR w = new TaniWATR(br);
                lwaters.Add(w);
            }
        }
        public void LoadV10(BinaryReader br)
        {
            texture = br.ReadString();
            wm_global_water = br.ReadBoolean();
            wm_selected = br.ReadBoolean();
            wm_red = br.ReadSingle();
            wm_green = br.ReadSingle();
            wm_blue = br.ReadSingle();
            wm_ripplex = br.ReadSingle();
            wm_rippley = br.ReadSingle();
            wm_smoothness = br.ReadSingle();
            wm_refbias = br.ReadSingle();
            wm_refpower = br.ReadSingle();
            wm_raisewater = br.ReadSingle();
            wm_treshold = br.ReadByte();
            for (int n = 0; n < 3; n++)
            {
                wm_texture[n] = br.ReadString();
                wm_scrollx[n] = br.ReadSingle();
                wm_scrolly[n] = br.ReadSingle();
                wm_scrollr[n] = br.ReadSingle();
                wm_scrolla[n] = br.ReadSingle();
            }
            for (int n = br.ReadInt32(); n > 0; n--)
            {
                TaniWATR w = new TaniWATR(br);
                lwaters.Add(w);
            }
        }
        public void ValuesFromWATR(TaniWATR w)
        {
            wm_red = w.ColorRed;
            wm_green = w.ColorGreen;
            wm_blue = w.ColorBlue;
            wm_ripplex = w.RippleX;
            wm_rippley = w.RippleY;
            wm_smoothness = w.Smoothness;
            wm_refbias = w.ReflectionBias;
            wm_refpower = w.ReflectionPower;
            for (int n = 0; n < 3; n++)
            {
                wm_texture[n] = w.Texture[n];
                wm_scrollx[n] = w.TextureDirX[n];
                wm_scrolly[n] = w.TextureDirY[n];
                wm_scrollr[n] = w.TextureRate[n];
                wm_scrolla[n] = w.TextureAngle[n];
            }
        }
        public void ValuesToWATR(TaniWATR w)
        {
            w.ColorRed = wm_red;
            w.ColorGreen = wm_green;
            w.ColorBlue = wm_blue;
            w.RippleX = wm_ripplex;
            w.RippleY = wm_rippley;
            w.Smoothness = wm_smoothness;
            w.ReflectionBias = wm_refbias;
            w.ReflectionPower = wm_refpower;
            for (int n = 0; n < 3; n++)
            {
                w.TextureDirX[n] = wm_scrollx[n];
                w.TextureDirY[n] = wm_scrolly[n];
                w.TextureRate[n] = wm_scrollr[n];
                w.TextureAngle[n] = wm_scrolla[n];
                w.Texture[n] = wm_texture[n];
            }
        }
    }
}
