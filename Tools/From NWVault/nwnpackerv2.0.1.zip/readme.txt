--------------------------------------------- 
Name	: NWN Packer V2.0.1 [10/07/2010]
OS   	: WIN32
Type	: FREEWARE
Author	: Zoligato (zoligato@hotmail.com)
URL     : 
--------------------------------------------- 

this tool unpack/pack mod,erf,hak,nwn,pwc files 

- pack/unpack all erf files format
- work with nwn1, nwn2, The Witcher(beta)
- import export file(s)
- drag&drop from explorer
- merge module  
- auto skip bad filename et bad file type
- no install needed, extract and run the exe
- now you can associate erf file to nwn Packer (Developer Silver idea) ;)
  (File/option)

Any bug or suggestion mail it to zoligato@hotmail.com

